/**
 * PFA Android Bridge v2.0.3 (Capacitor Native Runtime Adapter)
 * ------------------------------------------------------------
 * 1. API Bridge via CapacitorHttp + auto-attach sessionToken + auto logout saat SESSION_EXPIRED.
 * 2. Scanner Google ML Kit (@capacitor-mlkit/barcode-scanning) + fallback Html5Qrcode dengan tombol Senter (Flash).
 * 3. Kompresi Foto Adaptif (Mode Sinyal Lemah) + Indikator Live Jumlah & Ukuran Foto di Tombol Simpan.
 * 4. Layar Ringkasan Konfirmasi (Review Before Submit) untuk Gangguan, Pengukuran, dan P2TL.
 * 5. Peringatan Saat Keluar Formulir yang Belum Disimpan (ganti tab / tombol Back Android).
 * 6. Antrean Offline (IndexedDB) + Modal Perbandingan Duplikat + Tombol Hapus/Tunda.
 * 7. Update Otomatis OTA (Capgo) + aturan minNativeVersion + Tombol "Cek Update" & Info Versi di Menu ☰.
 */
(function () {
    'use strict';

    var OFFLINE_DB_NAME = 'pfa_offline_queue_db';
    var OFFLINE_STORE = 'pending_submissions';
    var QUEUEABLE_ACTIONS = ['simpan_gangguan', 'simpan_pengukuran', 'simpan_p2tl'];
    var WEAK_SIGNAL_PREF_KEY = 'pfa_weak_signal_mode_v1';
    var LAST_SESSION_TOKEN = '';

    function isCapacitorNative() {
        return typeof window.Capacitor !== 'undefined' &&
            typeof window.Capacitor.isNativePlatform === 'function' &&
            window.Capacitor.isNativePlatform();
    }

    function getApiUrl() {
        var customUrl = '';
        try {
            customUrl = String(localStorage.getItem('pfa_custom_api_url') || '').trim();
        } catch (e) { }
        if (customUrl) return customUrl;
        return (window.PFA_CONFIG && window.PFA_CONFIG.GAS_API_URL) ? String(window.PFA_CONFIG.GAS_API_URL).trim() : '';
    }

    function isApiUrlConfigured(url) {
        return Boolean(url && url.indexOf('https://script.google.com/macros/s/') === 0 && url.indexOf('PASTE_DEPLOYMENT_ID') === -1);
    }

    function getActiveSessionToken() {
        if (LAST_SESSION_TOKEN) return LAST_SESSION_TOKEN;
        try {
            var raw = localStorage.getItem('pfa_session_v1');
            if (raw) {
                var parsed = JSON.parse(raw);
                if (parsed && parsed.sessionToken) {
                    LAST_SESSION_TOKEN = String(parsed.sessionToken).trim();
                    return LAST_SESSION_TOKEN;
                }
            }
        } catch (e) { }
        return '';
    }

    function escText(v) {
        if (typeof window.escHtml === 'function') return window.escHtml(v);
        return String(v == null ? '' : v)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function formatGroupedDigits(val) {
        var s = String(val || '').trim();
        if (!s || !/^\d{8,16}$/.test(s)) return s || '-';
        return s.replace(/(\d{4})(?=\d)/g, '$1 ');
    }

    function formatBytesKB(bytes) {
        if (!bytes || bytes <= 0) return '0 KB';
        var kb = bytes / 1024;
        if (kb >= 1024) return (kb / 1024).toFixed(2) + ' MB';
        return Math.round(kb) + ' KB';
    }

    function estimateBase64Bytes(dataUrl) {
        if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image/') !== 0) return 0;
        var commaIdx = dataUrl.indexOf(',');
        var b64Len = commaIdx !== -1 ? (dataUrl.length - commaIdx - 1) : dataUrl.length;
        return Math.floor(b64Len * 0.75);
    }

    // --- Mode Sinyal Lemah & Kompresi Foto Adaptif ---
    function isAutoWeakNetwork() {
        if (navigator.onLine === false) return true;
        var conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
        if (conn) {
            var eff = String(conn.effectiveType || '').toLowerCase();
            if (eff === 'slow-2g' || eff === '2g' || eff === '3g' || conn.saveData) return true;
        }
        return false;
    }

    function isWeakSignalModeActive() {
        try {
            var pref = localStorage.getItem(WEAK_SIGNAL_PREF_KEY);
            if (pref === '1') return true;
            if (pref === '0') return false;
        } catch (e) { }
        return isAutoWeakNetwork();
    }

    function setWeakSignalPref(val) {
        try {
            if (val === null) localStorage.removeItem(WEAK_SIGNAL_PREF_KEY);
            else localStorage.setItem(WEAK_SIGNAL_PREF_KEY, val ? '1' : '0');
        } catch (e) { }
        renderWeakSignalBar();
        updateAllPhotoSizeIndicators();
    }

    function compressDataUrl(dataUrl, maxDim, quality) {
        return new Promise(function (resolve) {
            if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image/') !== 0) {
                resolve(dataUrl);
                return;
            }
            if (dataUrl.length < 120000) {
                resolve(dataUrl);
                return;
            }
            var img = new Image();
            img.onload = function () {
                try {
                    var w = img.naturalWidth || img.width;
                    var h = img.naturalHeight || img.height;
                    if (!w || !h) { resolve(dataUrl); return; }
                    var scale = Math.min(1, maxDim / Math.max(w, h));
                    var nw = Math.max(1, Math.round(w * scale));
                    var nh = Math.max(1, Math.round(h * scale));
                    var canvas = document.createElement('canvas');
                    canvas.width = nw;
                    canvas.height = nh;
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, nw, nh);
                    var out = canvas.toDataURL('image/jpeg', quality);
                    resolve(out && out.length < dataUrl.length ? out : dataUrl);
                } catch (e) {
                    resolve(dataUrl);
                }
            };
            img.onerror = function () { resolve(dataUrl); };
            img.src = dataUrl;
        });
    }

    function compressPayloadPhotos(payload) {
        if (!payload || !payload.fotos || typeof payload.fotos !== 'object') {
            return Promise.resolve(payload);
        }
        var weak = isWeakSignalModeActive();
        var maxDim = weak ? 800 : 1280;
        var quality = weak ? 0.55 : 0.78;
        var fotosCopy = Object.assign({}, payload.fotos);
        var keys = Object.keys(fotosCopy);
        var chain = Promise.resolve();

        keys.forEach(function (k) {
            var val = fotosCopy[k];
            if (typeof val === 'string' && val.indexOf('data:image/') === 0) {
                chain = chain.then(function () {
                    return compressDataUrl(val, maxDim, quality).then(function (res) {
                        fotosCopy[k] = res;
                    });
                });
            } else if (Array.isArray(val)) {
                chain = chain.then(function () {
                    var arrCopy = val.map(function (it) { return it && typeof it === 'object' ? Object.assign({}, it) : it; });
                    var inner = Promise.resolve();
                    arrCopy.forEach(function (item, idx) {
                        if (item && typeof item.base64 === 'string' && item.base64.indexOf('data:image/') === 0) {
                            inner = inner.then(function () {
                                return compressDataUrl(item.base64, maxDim, quality).then(function (res) {
                                    arrCopy[idx].base64 = res;
                                });
                            });
                        }
                    });
                    return inner.then(function () { fotosCopy[k] = arrCopy; });
                });
            }
        });

        return chain.then(function () {
            return Object.assign({}, payload, { fotos: fotosCopy });
        });
    }

    function countPayloadPhotos(fotos) {
        var count = 0;
        var bytes = 0;
        if (!fotos || typeof fotos !== 'object') return { count: 0, bytes: 0 };
        Object.keys(fotos).forEach(function (k) {
            var val = fotos[k];
            if (typeof val === 'string' && val.indexOf('data:image/') === 0) {
                count++;
                bytes += estimateBase64Bytes(val);
            } else if (Array.isArray(val)) {
                val.forEach(function (it) {
                    if (it && typeof it.base64 === 'string' && it.base64.indexOf('data:image/') === 0) {
                        count++;
                        bytes += estimateBase64Bytes(it.base64);
                    }
                });
            }
        });
        return { count: count, bytes: bytes };
    }

    function renderWeakSignalBar() {
        var container = document.querySelector('#appScreen .container');
        if (!container) return;
        var bar = document.getElementById('pfaWeakSignalBar');
        if (!bar) {
            bar = document.createElement('div');
            bar.id = 'pfaWeakSignalBar';
            bar.className = 'd-flex justify-content-between align-items-center mb-2 px-2 py-1 rounded-3 border bg-white';
            container.insertBefore(bar, container.firstChild);
        }
        var active = isWeakSignalModeActive();
        var offline = navigator.onLine === false;
        var badgeHtml = offline
            ? '<span class="badge text-bg-danger me-1">Offline</span>'
            : (active ? '<span class="badge text-bg-warning text-dark me-1">Hemat Sinyal</span>' : '<span class="badge text-bg-success me-1">Normal</span>');

        bar.innerHTML =
            '<div class="d-flex align-items-center text-truncate">' +
            badgeHtml +
            '<span class="text-muted text-truncate">' + (active ? 'Kompresi foto aktif (ringan)' : 'Kualitas foto standar') + '</span>' +
            '</div>' +
            '<button type="button" class="btn btn-sm py-0 px-2 ' + (active ? 'btn-warning' : 'btn-outline-secondary') + '" id="btnToggleWeakSignal">' +
            (active ? 'Matikan Hemat' : 'Mode Sinyal Lemah') +
            '</button>';

        var btn = document.getElementById('btnToggleWeakSignal');
        if (btn) {
            btn.onclick = function () {
                setWeakSignalPref(!active);
                if (typeof window.showToast === 'function') {
                    window.showToast(!active ? 'Mode Sinyal Lemah aktif: foto otomatis dikompres lebih ringan.' : 'Kembali ke mode kualitas foto standar.', 'info');
                }
            };
        }
    }

    // --- Indikator Live Total Ukuran Foto pada Tombol Simpan ---
    var PHOTO_BTN_TARGETS = [
        { tabId: 'tab-gangguan', btnSel: '#gangguanForm button[type="submit"]', baseLabel: 'Simpan Laporan Gangguan', badgeId: 'pfaSizeBadgeGangguan' },
        { tabId: 'tab-pengukuran', btnSel: 'button[onclick*="simpanHasilPengukuran"]', baseLabel: 'Simpan ke Sheet', badgeId: 'pfaSizeBadgeUkur' },
        { tabId: 'tab-p2tl', btnSel: '#p2tlForm button[type="submit"]', baseLabel: 'Simpan Data P2TL', badgeId: 'pfaSizeBadgeP2tl' }
    ];

    function scanTabPhotoStats(tabId) {
        var tabEl = document.getElementById(tabId);
        if (!tabEl) return { count: 0, bytes: 0 };
        var count = 0;
        var bytes = 0;
        var hiddenInputs = tabEl.querySelectorAll('input[type="hidden"]');
        for (var i = 0; i < hiddenInputs.length; i++) {
            var v = hiddenInputs[i].value || '';
            if (v.indexOf('data:image/') === 0) {
                count++;
                bytes += estimateBase64Bytes(v);
            }
        }
        return { count: count, bytes: bytes };
    }

    function updateAllPhotoSizeIndicators() {
        var weak = isWeakSignalModeActive();
        PHOTO_BTN_TARGETS.forEach(function (cfg) {
            var btn = document.querySelector(cfg.btnSel);
            if (!btn) return;
            var stats = scanTabPhotoStats(cfg.tabId);
            // Estimasi ukuran pasca kompresi adaptif
            var estBytes = weak ? Math.round(stats.bytes * 0.45) : Math.round(stats.bytes * 0.78);
            var suffix = stats.count > 0
                ? ' • ' + stats.count + ' foto (~' + formatBytesKB(estBytes) + ')'
                : '';

            var span = btn.querySelector('.pfa-upload-meta');
            if (!span) {
                span = document.createElement('span');
                span.className = 'pfa-upload-meta fw-normal';
                span.style.fontSize = '0.82em';
                btn.appendChild(span);
            }
            span.textContent = suffix;
        });
    }

    // --- Layar Ringkasan Konfirmasi (Review Before Submit) ---
    function buildReviewRowsHtml(action, dataObj, photoStats) {
        var d = dataObj || {};
        var rows = [];
        if (action === 'simpan_gangguan') {
            rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
            rows.push(['Nama Pelanggan', d.nama_pelanggan || d.nama || '-']);
            rows.push(['No. Form DG', d.no_form_dg || '-']);
            rows.push(['Status TL', d.status_tindak_lanjut || d.status_tl || '-']);
            rows.push(['No. Meter Lama', formatGroupedDigits(d.no_meter_lama)]);
            if (d.no_meter_baru) rows.push(['No. Meter Baru', formatGroupedDigits(d.no_meter_baru)]);
            if (d.no_segel_baru) rows.push(['No. Segel Baru', d.no_segel_baru]);
            if (d.sisa_kwh) rows.push(['Sisa kWh', d.sisa_kwh]);
            rows.push(['Sebab Kerusakan', d.sebab_kerusakan || '-']);
        } else if (action === 'simpan_pengukuran') {
            rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
            rows.push(['Nama Pelanggan', d.nama_pelanggan || d.nama || '-']);
            if (d.no_meter) rows.push(['No. Meter', formatGroupedDigits(d.no_meter)]);
            if (d.deviasi_kwh != null && d.deviasi_kwh !== '') rows.push(['Deviasi kWh', d.deviasi_kwh + ' %']);
            if (d.fkm) rows.push(['FKM', d.fkm]);
            if (d.petugas) rows.push(['Petugas', d.petugas]);
        } else if (action === 'simpan_p2tl') {
            rows.push(['Kategori', d.kategori_pelanggan || d.kategori || '-']);
            if (d.id_pelanggan || d.idpel) rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
            rows.push(['Nama', d.nama_pelanggan || d.nama || '-']);
            if (d.golongan_temuan || d.kode_pelanggaran) rows.push(['Temuan / Kode', d.golongan_temuan || d.kode_pelanggaran]);
            if (d.total_tagihan || d.tagihan_susulan) rows.push(['Estimasi TS', d.total_tagihan || d.tagihan_susulan]);
            if (d.status_penertiban) rows.push(['Penertiban', d.status_penertiban]);
        }

        var modeLbl = isWeakSignalModeActive() ? 'Mode Sinyal Lemah' : 'Standar';
        rows.push(['Lampiran Foto', photoStats.count + ' foto (' + formatBytesKB(photoStats.bytes) + ' • ' + modeLbl + ')']);

        return rows.map(function (r) {
            return '<div class="d-flex justify-content-between gap-2 py-1 border-bottom">' +
                '<span class="text-muted">' + escText(r[0]) + '</span>' +
                '<strong class="text-end text-dark" style="word-break:break-word;">' + escText(r[1]) + '</strong>' +
                '</div>';
        }).join('');
    }

    function showReviewBeforeSubmitModal(payload) {
        return new Promise(function (resolve) {
            var old = document.getElementById('pfaReviewSubmitModal');
            if (old) old.remove();

            var action = payload.action;
            var titleMap = {
                simpan_gangguan: 'Cek Ulang Laporan Gangguan',
                simpan_pengukuran: 'Cek Ulang Hasil Pengukuran',
                simpan_p2tl: 'Cek Ulang Data P2TL / K2'
            };
            var photoStats = countPayloadPhotos(payload.fotos);
            var rowsHtml = buildReviewRowsHtml(action, payload.data, photoStats);
            var offlineWarn = navigator.onLine === false
                ? '<div class="alert alert-warning py-1 px-2 small mt-2 mb-0"><i class="bi bi-wifi-off me-1"></i>Sedang offline: laporan akan disimpan ke <strong>Antrean Offline</strong>.</div>'
                : '';

            var wrap = document.createElement('div');
            wrap.innerHTML =
                '<div class="modal fade" id="pfaReviewSubmitModal" tabindex="-1" data-bs-backdrop="static">' +
                '  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
                '    <div class="modal-content rounded-4 border-0 shadow">' +
                '      <div class="modal-header bg-primary text-white py-2">' +
                '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-clipboard-check-fill me-1"></i> ' + escText(titleMap[action] || 'Konfirmasi Kirim Data') + '</h6>' +
                '        <button type="button" class="btn-close btn-close-white" id="btnRevCloseX" aria-label="Batal"></button>' +
                '      </div>' +
                '      <div class="modal-body small">' +
                '        <p class="text-muted mb-2">Pastikan angka IDPEL, nomor meter, dan foto sudah sesuai sebelum dikirim:</p>' +
                '        <div class="px-2 py-1 rounded-3 bg-light border">' + rowsHtml + '</div>' +
                offlineWarn +
                '      </div>' +
                '      <div class="modal-footer py-2 d-flex justify-content-between gap-2">' +
                '        <button type="button" class="btn btn-outline-secondary btn-sm flex-grow-1" id="btnRevCancel"><i class="bi bi-pencil-square me-1"></i> Kembali Edit</button>' +
                '        <button type="button" class="btn btn-success btn-sm fw-semibold flex-grow-1" id="btnRevConfirm"><i class="bi bi-send-check-fill me-1"></i> Ya, Kirim Sekarang</button>' +
                '      </div>' +
                '    </div>' +
                '  </div>' +
                '</div>';

            document.body.appendChild(wrap.firstChild);
            var modalEl = document.getElementById('pfaReviewSubmitModal');
            var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;

            function done(ok) {
                if (inst) inst.hide();
                modalEl.addEventListener('hidden.bs.modal', function () {
                    modalEl.remove();
                    resolve(ok);
                }, { once: true });
                if (!inst) {
                    modalEl.remove();
                    resolve(ok);
                }
            }

            document.getElementById('btnRevConfirm').onclick = function () { done(true); };
            document.getElementById('btnRevCancel').onclick = function () { done(false); };
            document.getElementById('btnRevCloseX').onclick = function () { done(false); };

            if (typeof window.setLoading === 'function') window.setLoading(false);
            if (inst) inst.show();
            else resolve(true);
        });
    }

    // --- Peringatan Saat Keluar Formulir yang Belum Disimpan ---
    var DIRTY_FORM_TABS = { gangguan: false, pengukuran: false, p2tl: false };

    function getActiveVisibleTabName() {
        var tabs = ['gangguan', 'pengukuran', 'p2tl', 'portal', 'kct', 'material', 'chatbot', 'tutorial', 'admin'];
        for (var i = 0; i < tabs.length; i++) {
            var el = document.getElementById('tab-' + tabs[i]);
            if (el && !el.classList.contains('d-none')) return tabs[i];
        }
        return 'portal';
    }

    function markTabDirty(tabName, isDirty) {
        if (Object.prototype.hasOwnProperty.call(DIRTY_FORM_TABS, tabName)) {
            DIRTY_FORM_TABS[tabName] = Boolean(isDirty);
        }
    }

    function bindDirtyFormTrackers() {
        ['gangguan', 'pengukuran', 'p2tl'].forEach(function (tabName) {
            var el = document.getElementById('tab-' + tabName);
            if (!el || el.dataset.pfaDirtyBound) return;
            el.dataset.pfaDirtyBound = '1';
            el.addEventListener('input', function () {
                markTabDirty(tabName, true);
                updateAllPhotoSizeIndicators();
            });
            el.addEventListener('change', function () {
                markTabDirty(tabName, true);
                setTimeout(updateAllPhotoSizeIndicators, 250);
            });
            el.addEventListener('reset', function () {
                markTabDirty(tabName, false);
                setTimeout(updateAllPhotoSizeIndicators, 150);
            });
        });
    }

    function confirmLeaveDirtyForm(currentTabName) {
        return new Promise(function (resolve) {
            var old = document.getElementById('pfaUnsavedLeaveModal');
            if (old) old.remove();
            var labelMap = { gangguan: 'Gangguan', pengukuran: 'Pengukuran', p2tl: 'P2TL / K2' };
            var wrap = document.createElement('div');
            wrap.innerHTML =
                '<div class="modal fade" id="pfaUnsavedLeaveModal" tabindex="-1">' +
                '  <div class="modal-dialog modal-dialog-centered">' +
                '    <div class="modal-content rounded-4 border-0 shadow">' +
                '      <div class="modal-header bg-warning text-dark py-2">' +
                '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-exclamation-circle-fill me-1"></i> Formulir Belum Disimpan</h6>' +
                '      </div>' +
                '      <div class="modal-body small">' +
                '        Anda memiliki isian pada formulir <strong>' + escText(labelMap[currentTabName] || currentTabName) + '</strong> yang belum dikirim. Tetap keluar dari halaman ini?' +
                '      </div>' +
                '      <div class="modal-footer py-2">' +
                '        <button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnStayForm">Tetap di Formulir</button>' +
                '        <button type="button" class="btn btn-outline-danger btn-sm" id="btnLeaveForm">Keluar</button>' +
                '      </div>' +
                '    </div>' +
                '  </div>' +
                '</div>';
            document.body.appendChild(wrap.firstChild);
            var modalEl = document.getElementById('pfaUnsavedLeaveModal');
            var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
            var resolved = false;
            function finish(leave) {
                if (resolved) return;
                resolved = true;
                if (inst) inst.hide();
                modalEl.addEventListener('hidden.bs.modal', function () {
                    modalEl.remove();
                    resolve(leave);
                }, { once: true });
                if (!inst) {
                    modalEl.remove();
                    resolve(leave);
                }
            }
            document.getElementById('btnStayForm').onclick = function () { finish(false); };
            document.getElementById('btnLeaveForm').onclick = function () { finish(true); };
            modalEl.addEventListener('hidden.bs.modal', function () {
                if (!resolved) { resolved = true; modalEl.remove(); resolve(false); }
            }, { once: true });
            if (inst) inst.show();
            else resolve(true);
        });
    }

    function wrapSwitchTabWithDirtyGuard() {
        if (typeof window.switchTab !== 'function' || window._pfaSwitchTabWrapped) return;
        window._pfaSwitchTabWrapped = true;
        var origSwitchTab = window.switchTab;
        window.switchTab = function (nextTab) {
            var curTab = getActiveVisibleTabName();
            if (curTab !== nextTab && DIRTY_FORM_TABS[curTab]) {
                confirmLeaveDirtyForm(curTab).then(function (leave) {
                    if (leave) {
                        markTabDirty(curTab, false);
                        origSwitchTab(nextTab);
                        setTimeout(updateAllPhotoSizeIndicators, 200);
                    }
                });
                return;
            }
            origSwitchTab(nextTab);
            setTimeout(updateAllPhotoSizeIndicators, 200);
        };
    }

    // --- IndexedDB Helper untuk Antrean Offline ---
    function openOfflineDb() {
        return new Promise(function (resolve, reject) {
            if (!window.indexedDB) {
                reject(new Error('IndexedDB tidak didukung perangkat ini.'));
                return;
            }
            var req = window.indexedDB.open(OFFLINE_DB_NAME, 1);
            req.onupgradeneeded = function (ev) {
                var db = ev.target.result;
                if (!db.objectStoreNames.contains(OFFLINE_STORE)) {
                    db.createObjectStore(OFFLINE_STORE, { keyPath: 'id', autoIncrement: true });
                }
            };
            req.onsuccess = function () { resolve(req.result); };
            req.onerror = function () { reject(req.error || new Error('Gagal membuka database offline.')); };
        });
    }

    function enqueueOfflineAction(payload) {
        return openOfflineDb().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(OFFLINE_STORE, 'readwrite');
                var store = tx.objectStore(OFFLINE_STORE);
                var item = {
                    createdAt: new Date().toISOString(),
                    action: payload.action,
                    payload: payload
                };
                var req = store.add(item);
                req.onsuccess = function () { resolve(req.result); };
                req.onerror = function () { reject(req.error); };
            });
        }).then(function (id) {
            refreshOfflineQueueBanner();
            return id;
        });
    }

    function listOfflineQueue() {
        return openOfflineDb().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(OFFLINE_STORE, 'readonly');
                var req = tx.objectStore(OFFLINE_STORE).getAll();
                req.onsuccess = function () { resolve(req.result || []); };
                req.onerror = function () { reject(req.error); };
            });
        }).catch(function () { return []; });
    }

    function removeOfflineItem(id) {
        return openOfflineDb().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(OFFLINE_STORE, 'readwrite');
                var req = tx.objectStore(OFFLINE_STORE).delete(id);
                req.onsuccess = function () { resolve(); };
                req.onerror = function () { reject(req.error); };
            });
        });
    }

    function clearOfflineQueueAll() {
        return openOfflineDb().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(OFFLINE_STORE, 'readwrite');
                var req = tx.objectStore(OFFLINE_STORE).clear();
                req.onsuccess = function () { resolve(); };
                req.onerror = function () { reject(req.error); };
            });
        }).then(function () {
            refreshOfflineQueueBanner();
        });
    }

    // --- Pengirim HTTP ke GAS doPost(e) ---
    function postToGas(url, payload) {
        var bodyStr = JSON.stringify(payload || {});
        var capHttp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp;

        var reqPromise = (capHttp && typeof capHttp.post === 'function')
            ? capHttp.post({
                url: url,
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                data: bodyStr,
                connectTimeout: (window.PFA_CONFIG && window.PFA_CONFIG.REQUEST_TIMEOUT_MS) || 60000,
                readTimeout: (window.PFA_CONFIG && window.PFA_CONFIG.REQUEST_TIMEOUT_MS) || 60000
            }).then(function (res) {
                var data = res && res.data;
                if (typeof data === 'string') {
                    try { data = JSON.parse(data); } catch (e) {
                        throw new Error('Respons server bukan JSON valid. Pastikan Deployment GAS sudah disetel ke "Anyone".');
                    }
                }
                return data;
            })
            : fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: bodyStr,
                redirect: 'follow'
            }).then(function (res) {
                return res.text().then(function (txt) {
                    try { return JSON.parse(txt); } catch (e) {
                        throw new Error('Respons server GAS tidak valid (HTTP ' + res.status + ').');
                    }
                });
            });

        return reqPromise.then(function (res) {
            if (payload && payload.action === 'login' && res && res.status === 'success' && res.sessionToken) {
                LAST_SESSION_TOKEN = String(res.sessionToken).trim();
            }
            if (res && res.code === 'SESSION_EXPIRED') {
                LAST_SESSION_TOKEN = '';
                if (typeof window.showToast === 'function') {
                    window.showToast('Sesi login telah berakhir. Silakan login kembali.', 'warning');
                }
                if (typeof window.logoutApp === 'function') {
                    setTimeout(function () { window.logoutApp(); }, 700);
                }
            }
            return res;
        });
    }

    // --- Override callApi(payload) dari ScriptCore.html ---
    var originalCallApi = typeof window.callApi === 'function' ? window.callApi : null;

    function clearDirtyForAction(action) {
        if (action === 'simpan_gangguan') markTabDirty('gangguan', false);
        else if (action === 'simpan_pengukuran') markTabDirty('pengukuran', false);
        else if (action === 'simpan_p2tl') markTabDirty('p2tl', false);
    }

    window.callApi = function (payload) {
        if (typeof google !== 'undefined' && google.script && google.script.run && originalCallApi) {
            return originalCallApi(payload);
        }

        var reqPayload = Object.assign({}, payload || {});
        if (!reqPayload.sessionToken) {
            var tok = getActiveSessionToken();
            if (tok) reqPayload.sessionToken = tok;
        }

        var apiUrl = getApiUrl();
        if (!isApiUrlConfigured(apiUrl)) {
            return Promise.reject(new Error('URL API GAS belum diisi. Atur GAS_API_URL pada file www/pfa-config.js terlebih dahulu.'));
        }

        var isQueueable = QUEUEABLE_ACTIONS.indexOf(reqPayload.action) !== -1;

        if (reqPayload.action === 'get_master_kerusakan') {
            return postToGas(apiUrl, reqPayload).then(function (res) {
                if (res && res.status === 'success' && Array.isArray(res.data) && res.data.length) {
                    try { localStorage.setItem('pfa_cache_master_kerusakan', JSON.stringify(res.data)); } catch (e) { }
                }
                return res;
            }).catch(function (err) {
                try {
                    var cached = JSON.parse(localStorage.getItem('pfa_cache_master_kerusakan') || '[]');
                    if (Array.isArray(cached) && cached.length) {
                        return { status: 'success', data: cached, fromCache: true };
                    }
                } catch (e) { }
                throw err;
            });
        }

        // Jika simpan laporan (Gangguan/Pengukuran/P2TL) & bukan retry allowDuplicate -> kompres dulu lalu tampilkan Layar Ringkasan Konfirmasi
        if (isQueueable && !reqPayload.allowDuplicate && !reqPayload._skipReview) {
            return compressPayloadPhotos(reqPayload).then(function (compressedPayload) {
                return showReviewBeforeSubmitModal(compressedPayload).then(function (confirmed) {
                    if (!confirmed) {
                        return { status: 'error', message: 'Pengiriman dibatalkan untuk dicek kembali.' };
                    }
                    if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengirim laporan ke server...');
                    return executeQueueableRequest(apiUrl, compressedPayload);
                });
            });
        }

        var prepPromise = isQueueable ? compressPayloadPhotos(reqPayload) : Promise.resolve(reqPayload);
        return prepPromise.then(function (finalPayload) {
            if (isQueueable) return executeQueueableRequest(apiUrl, finalPayload);
            return postToGas(apiUrl, finalPayload);
        });
    };

    function executeQueueableRequest(apiUrl, finalPayload) {
        if (navigator.onLine === false) {
            return enqueueOfflineAction(finalPayload).then(function () {
                clearDirtyForAction(finalPayload.action);
                setTimeout(updateAllPhotoSizeIndicators, 250);
                return {
                    status: 'success',
                    offlineQueued: true,
                    message: 'Sinyal terputus. Data & foto terkompresi diamankan ke Antrean Offline perangkat.'
                };
            });
        }

        return postToGas(apiUrl, finalPayload).then(function (res) {
            if (res && res.status === 'success') {
                clearDirtyForAction(finalPayload.action);
                setTimeout(updateAllPhotoSizeIndicators, 250);
            }
            return res;
        }).catch(function (err) {
            var msg = err && err.message ? err.message : String(err);
            var isNetworkErr = /network|failed to fetch|timeout|offline|unable to resolve host|socket/i.test(msg) || navigator.onLine === false;
            if (isNetworkErr) {
                return enqueueOfflineAction(finalPayload).then(function () {
                    clearDirtyForAction(finalPayload.action);
                    setTimeout(updateAllPhotoSizeIndicators, 250);
                    return {
                        status: 'success',
                        offlineQueued: true,
                        message: 'Koneksi tidak stabil. Laporan diamankan ke Antrean Offline dan siap dikirim ulang saat sinyal membaik.'
                    };
                });
            }
            throw err;
        });
    }

    // --- Update Otomatis OTA + Aturan minNativeVersion + Tombol Cek Update di Menu ☰ ---
    function compareSemver(a, b) {
        var pa = String(a || '0').split('.').map(function (n) { return parseInt(n, 10) || 0; });
        var pb = String(b || '0').split('.').map(function (n) { return parseInt(n, 10) || 0; });
        for (var i = 0; i < 3; i++) {
            if ((pa[i] || 0) > (pb[i] || 0)) return 1;
            if ((pa[i] || 0) < (pb[i] || 0)) return -1;
        }
        return 0;
    }

    function getNativeApkVersion() {
        try {
            var savedNative = localStorage.getItem('pfa_native_apk_version');
            if (savedNative) return savedNative;
        } catch (e) { }
        return '2.0.0';
    }

    function getCurrentInstalledVersion() {
        var baseVer = (window.PFA_CONFIG && window.PFA_CONFIG.APP_VERSION) || '2.0.0';
        try {
            var otaVer = String(localStorage.getItem('pfa_ota_version') || '').trim();
            if (otaVer && compareSemver(otaVer, baseVer) > 0) return otaVer;
        } catch (e) { }
        return baseVer;
    }

    function injectCheckUpdateMenuItem() {
        var menu = document.querySelector('#appScreen .topbar-pln .dropdown-menu');
        if (!menu || document.getElementById('pfaMenuCheckUpdate')) return;
        var ver = getCurrentInstalledVersion();
        var li = document.createElement('li');
        li.id = 'pfaMenuCheckUpdate';
        li.innerHTML =
            '<button type="button" class="dropdown-item small py-2" onclick="checkPfaUpdate()">' +
            '  <i class="bi bi-cloud-arrow-down-fill me-2 text-primary"></i> Cek Update <span class="badge text-bg-light border ms-1">v' + escText(ver) + '</span>' +
            '</button>';
        var divider = menu.querySelector('.dropdown-divider');
        if (divider && divider.parentNode) {
            menu.insertBefore(li, divider.parentNode);
        } else {
            menu.appendChild(li);
        }
    }

    function runOtaInAppUpdate(otaUrl, targetVer) {
        var updater = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater;
        if (!updater || typeof updater.download !== 'function') {
            if (typeof window.showToast === 'function') window.showToast('Plugin OTA belum aktif di perangkat ini.', 'warning');
            return;
        }
        if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengunduh update PFA v' + targetVer + '...');
        updater.download({ url: otaUrl, version: targetVer })
            .then(function (bundle) {
                if (!bundle || !bundle.id) throw new Error('Paket update tidak valid.');
                try { localStorage.setItem('pfa_ota_version', targetVer); } catch (e) { }
                if (typeof window.setLoading === 'function') window.setLoading(true, 'Menerapkan pembaruan & memuat ulang...');
                return updater.set({ id: bundle.id });
            })
            .catch(function (err) {
                if (typeof window.setLoading === 'function') window.setLoading(false);
                if (typeof window.showToast === 'function') {
                    window.showToast('Gagal update otomatis: ' + ((err && err.message) || err), 'danger');
                }
            });
    }

    function checkAppUpdateOnLaunch(manualTrigger) {
        if (navigator.onLine === false) {
            if (manualTrigger && typeof window.showToast === 'function') window.showToast('Tidak ada koneksi internet untuk cek update.', 'warning');
            return;
        }
        var apiUrl = getApiUrl();
        if (!isApiUrlConfigured(apiUrl)) return;
        var currentVer = getCurrentInstalledVersion();
        var nativeVer = getNativeApkVersion();

        if (manualTrigger && typeof window.setLoading === 'function') {
            window.setLoading(true, 'Memeriksa pembaruan PFA...');
        }

        postToGas(apiUrl, { action: 'check_app_update' }).then(function (res) {
            if (manualTrigger && typeof window.setLoading === 'function') window.setLoading(false);
            if (!res || res.status !== 'success' || !res.latestVersion) return;

            // Cek aturan minNativeVersion: jika APK dasar di HP terlalu lama, wajib unduh APK baru
            var mustUpdateApk = Boolean(res.minNativeVersion && compareSemver(res.minNativeVersion, nativeVer) > 0 && res.downloadUrl);
            var hasOta = Boolean(!mustUpdateApk && res.otaBundleUrl && isCapacitorNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater);
            var hasApk = Boolean(res.downloadUrl);
            if (!hasOta && !hasApk) {
                if (manualTrigger && typeof window.showToast === 'function') {
                    window.showToast('PFA Anda sudah versi terbaru (v' + currentVer + ').', 'success');
                }
                return;
            }

            if (!mustUpdateApk && compareSemver(res.latestVersion, currentVer) <= 0) {
                if (manualTrigger && typeof window.showToast === 'function') {
                    window.showToast('PFA Anda sudah versi terbaru (v' + currentVer + ').', 'success');
                }
                return;
            }

            var old = document.getElementById('pfaUpdateModal');
            if (old) old.remove();
            var actionBtnHtml = hasOta
                ? '<button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnPfaRunOta"><i class="bi bi-lightning-charge-fill me-1"></i> Update Sekarang (Otomatis)</button>'
                : '<a href="' + escText(res.downloadUrl) + '" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm fw-semibold"><i class="bi bi-download me-1"></i> Unduh Update APK</a>';

            var noteHtml = mustUpdateApk
                ? '<div class="alert alert-warning py-1 px-2 mt-2 mb-0" style="font-size:0.75rem;"><i class="bi bi-shield-exclamation me-1"></i>Pembaruan ini membutuhkan instalasi ulang file <strong>APK v' + escText(res.minNativeVersion) + '</strong> agar fitur perangkat keras baru berjalan normal.</div>'
                : (hasOta ? '<div class="text-muted mt-2" style="font-size:0.75rem;"><i class="bi bi-info-circle me-1"></i>Aplikasi akan mengunduh pembaruan kecil dan memuat ulang otomatis tanpa perlu instal ulang APK.</div>' : '');

            var wrap = document.createElement('div');
            wrap.innerHTML =
                '<div class="modal fade" id="pfaUpdateModal" tabindex="-1">' +
                '  <div class="modal-dialog modal-dialog-centered">' +
                '    <div class="modal-content rounded-4 border-0 shadow">' +
                '      <div class="modal-header bg-primary text-white py-2">' +
                '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-cloud-download-fill me-1"></i> Update PFA v' + escText(res.latestVersion) + ' Tersedia</h6>' +
                '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
                '      </div>' +
                '      <div class="modal-body small">' +
                '        <p class="mb-2">Versi terpasang: <strong>v' + escText(currentVer) + '</strong> → Terbaru: <strong class="text-primary">v' + escText(res.latestVersion) + '</strong></p>' +
                '        <div class="p-2 rounded-3 bg-light border">' + escText(res.releaseNotes || 'Perbaikan bug dan peningkatan performa.') + '</div>' +
                noteHtml +
                '      </div>' +
                '      <div class="modal-footer py-2">' +
                '        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Nanti Saja</button>' +
                actionBtnHtml +
                '      </div>' +
                '    </div>' +
                '  </div>' +
                '</div>';
            document.body.appendChild(wrap.firstChild);
            var modalEl = document.getElementById('pfaUpdateModal');
            var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
            var otaBtn = document.getElementById('btnPfaRunOta');
            if (otaBtn) {
                otaBtn.onclick = function () {
                    if (inst) inst.hide();
                    runOtaInAppUpdate(res.otaBundleUrl, res.latestVersion);
                };
            }
            if (inst) inst.show();
        }).catch(function () {
            if (manualTrigger && typeof window.setLoading === 'function') window.setLoading(false);
            if (manualTrigger && typeof window.showToast === 'function') window.showToast('Gagal memeriksa pembaruan. Periksa sinyal Anda.', 'warning');
        });
    }

    window.checkPfaUpdate = function () { checkAppUpdateOnLaunch(true); };

    // --- Banner & Sinkronisasi Antrean Offline ---
    function ensureOfflineBanner() {
        var existing = document.getElementById('pfaOfflineQueueBanner');
        if (existing) return existing;
        var container = document.querySelector('#appScreen .container');
        if (!container) return null;

        var banner = document.createElement('div');
        banner.id = 'pfaOfflineQueueBanner';
        banner.className = 'alert alert-info border-info d-none justify-content-between align-items-center flex-wrap gap-2 py-2 px-3 rounded-3 mb-3';
        banner.innerHTML =
            '<div class="small">' +
            '  <i class="bi bi-cloud-arrow-up-fill me-1 fw-bold"></i>' +
            '  Ada <strong id="pfaOfflineCount">0</strong> laporan di <strong>Antrean Offline</strong> siap dikirim.' +
            '</div>' +
            '<div class="d-flex gap-2">' +
            '  <button type="button" class="btn btn-sm btn-primary fw-semibold" id="btnSyncOfflineQueue">' +
            '    <i class="bi bi-arrow-repeat me-1"></i> Kirim Sekarang' +
            '  </button>' +
            '  <button type="button" class="btn btn-sm btn-outline-danger" id="btnClearOfflineQueue" title="Hapus antrean">' +
            '    Hapus' +
            '  </button>' +
            '</div>';

        var weakBar = document.getElementById('pfaWeakSignalBar');
        if (weakBar && weakBar.nextSibling) container.insertBefore(banner, weakBar.nextSibling);
        else container.insertBefore(banner, container.firstChild);

        var btn = banner.querySelector('#btnSyncOfflineQueue');
        if (btn) btn.addEventListener('click', syncOfflineQueueNow);
        var btnClr = banner.querySelector('#btnClearOfflineQueue');
        if (btnClr) {
            btnClr.addEventListener('click', function () {
                if (confirm('Hapus semua laporan di Antrean Offline perangkat ini?')) {
                    clearOfflineQueueAll().then(function () {
                        if (typeof window.showToast === 'function') window.showToast('Antrean offline dibersihkan.', 'secondary');
                    });
                }
            });
        }
        return banner;
    }

    function refreshOfflineQueueBanner() {
        listOfflineQueue().then(function (items) {
            var banner = ensureOfflineBanner();
            if (!banner) return;
            var countEl = document.getElementById('pfaOfflineCount');
            if (countEl) countEl.textContent = String(items.length);
            if (items.length > 0) {
                banner.classList.remove('d-none');
                banner.classList.add('d-flex');
            } else {
                banner.classList.add('d-none');
                banner.classList.remove('d-flex');
            }
        });
    }

    // --- Modal Perbandingan Data Duplikat saat Sinkronisasi Offline ---
    function askDuplicateResolutionModal(dupObj, offlineData) {
        return new Promise(function (resolve) {
            var oldModal = document.getElementById('pfaOfflineDupModal');
            if (oldModal) oldModal.remove();

            var latest = (dupObj && dupObj.latest) || {};
            var d = offlineData || {};
            var driveBtn = latest.link_folder
                ? '<a href="' + escText(latest.link_folder) + '" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary mt-2 w-100"><i class="bi bi-folder2-open me-1"></i> Lihat Foto Laporan Sebelumnya (Drive)</a>'
                : '';

            var wrap = document.createElement('div');
            wrap.innerHTML =
                '<div class="modal fade" id="pfaOfflineDupModal" tabindex="-1" data-bs-backdrop="static">' +
                '  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
                '    <div class="modal-content rounded-4 border-0 shadow">' +
                '      <div class="modal-header bg-warning text-dark py-2">' +
                '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-exclamation-triangle-fill me-1"></i> Data IDPEL ' + escText(d.id_pelanggan || latest.idpel || '-') + ' Sudah Ada</h6>' +
                '        <button type="button" class="btn-close" id="btnDupCloseX" aria-label="Tutup"></button>' +
                '      </div>' +
                '      <div class="modal-body small">' +
                '        <p class="mb-2">IDPEL ini tercatat sudah masuk <strong>' + escText(dupObj && dupObj.count ? dupObj.count : 1) + ' kali</strong> di server. Bandingkan datanya sebelum memilih:</p>' +
                '        <div class="p-2 rounded-3 bg-light border mb-2">' +
                '          <div class="fw-bold text-primary mb-1">1. Data Sebelumnya di Server</div>' +
                '          <div>• Waktu: <strong>' + escText(latest.timestamp || '-') + '</strong></div>' +
                '          <div>• No. Form DG: <strong>' + escText(latest.no_form_dg || '-') + '</strong></div>' +
                '          <div>• Status TL: <strong>' + escText(latest.status_tl || '-') + '</strong></div>' +
                '          <div>• Meter Baru: <strong>' + escText(latest.no_meter_baru || '-') + '</strong></div>' +
                '          <div>• Sebab: <strong>' + escText(latest.sebab_kerusakan || '-') + '</strong></div>' +
                '          <div>• Petugas: <strong>' + escText(latest.petugas || '-') + '</strong></div>' +
                driveBtn +
                '        </div>' +
                '        <div class="p-2 rounded-3 bg-info bg-opacity-10 border border-info">' +
                '          <div class="fw-bold text-dark mb-1">2. Data Offline yang Akan Dikirim</div>' +
                '          <div>• No. Form DG: <strong>' + escText(d.no_form_dg || '-') + '</strong></div>' +
                '          <div>• Status TL: <strong>' + escText(d.status_tindak_lanjut || '-') + '</strong></div>' +
                '          <div>• Meter Baru: <strong>' + escText(d.no_meter_baru || '-') + '</strong></div>' +
                '          <div>• Sebab: <strong>' + escText(d.sebab_kerusakan || '-') + '</strong></div>' +
                '          <div>• Petugas: <strong>' + escText(d.petugas || '-') + '</strong></div>' +
                '        </div>' +
                '      </div>' +
                '      <div class="modal-footer flex-column align-items-stretch gap-2 pt-1">' +
                '        <button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnDupSendForce">Tetap Kirim (Ini Data Berbeda)</button>' +
                '        <button type="button" class="btn btn-outline-danger btn-sm fw-semibold" id="btnDupDiscard">Hapus dari Antrean (Data Sama / Sudah Masuk)</button>' +
                '        <button type="button" class="btn btn-light btn-sm" id="btnDupLater">Tunda / Batal</button>' +
                '      </div>' +
                '    </div>' +
                '  </div>' +
                '</div>';

            document.body.appendChild(wrap.firstChild);
            var modalEl = document.getElementById('pfaOfflineDupModal');
            var inst = bootstrap.Modal.getOrCreateInstance(modalEl);

            function finish(choice) {
                inst.hide();
                modalEl.addEventListener('hidden.bs.modal', function () {
                    modalEl.remove();
                    resolve(choice);
                }, { once: true });
            }

            document.getElementById('btnDupSendForce').onclick = function () { finish('send'); };
            document.getElementById('btnDupDiscard').onclick = function () { finish('discard'); };
            document.getElementById('btnDupLater').onclick = function () { finish('cancel'); };
            document.getElementById('btnDupCloseX').onclick = function () { finish('cancel'); };

            if (typeof window.setLoading === 'function') window.setLoading(false);
            inst.show();
        });
    }

    var isSyncingQueue = false;
    function syncOfflineQueueNow() {
        if (isSyncingQueue) return;
        if (navigator.onLine === false) {
            if (typeof window.showToast === 'function') window.showToast('Perangkat masih offline. Tunggu sinyal kembali.', 'warning');
            return;
        }
        var apiUrl = getApiUrl();
        if (!isApiUrlConfigured(apiUrl)) return;

        isSyncingQueue = true;
        listOfflineQueue().then(function (items) {
            if (!items.length) {
                isSyncingQueue = false;
                refreshOfflineQueueBanner();
                return;
            }
            if (typeof window.setLoading === 'function') window.setLoading(true, 'Menyinkronkan ' + items.length + ' laporan offline...');

            var synced = 0;
            var failed = 0;
            var lastErrMsg = '';
            var chain = Promise.resolve();

            items.forEach(function (entry) {
                chain = chain.then(function () {
                    var payload = Object.assign({}, entry.payload || {});
                    var tok = getActiveSessionToken();
                    if (tok) payload.sessionToken = tok;

                    return postToGas(apiUrl, payload).then(function (res) {
                        if (res && res.status === 'success') {
                            synced++;
                            return removeOfflineItem(entry.id);
                        }
                        if (res && res.status === 'duplicate' && payload.action === 'simpan_gangguan') {
                            return askDuplicateResolutionModal(res.duplicate, payload.data).then(function (choice) {
                                if (choice === 'send') {
                                    if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengirim laporan offline...');
                                    payload.allowDuplicate = true;
                                    return postToGas(apiUrl, payload).then(function (res2) {
                                        if (res2 && res2.status === 'success') {
                                            synced++;
                                            return removeOfflineItem(entry.id);
                                        }
                                        failed++;
                                        lastErrMsg = (res2 && res2.message) || 'Gagal simpan ulang.';
                                    });
                                }
                                if (choice === 'discard') {
                                    synced++;
                                    return removeOfflineItem(entry.id);
                                }
                                failed++;
                                lastErrMsg = 'Sinkronisasi ditunda oleh petugas.';
                            });
                        }
                        failed++;
                        lastErrMsg = (res && res.message) || ('Status server: ' + (res && res.status ? res.status : 'tidak diketahui'));
                    }).catch(function (err) {
                        failed++;
                        lastErrMsg = (err && err.message) ? err.message : String(err);
                    });
                });
            });

            return chain.finally(function () {
                isSyncingQueue = false;
                if (typeof window.setLoading === 'function') window.setLoading(false);
                refreshOfflineQueueBanner();
                if (typeof window.showToast === 'function') {
                    if (synced > 0 && failed === 0) {
                        window.showToast(synced + ' laporan offline selesai diproses!', 'success');
                    } else if (synced > 0 && failed > 0) {
                        window.showToast(synced + ' selesai, ' + failed + ' belum terkirim: ' + lastErrMsg, 'warning');
                    } else {
                        window.showToast('Sinkronisasi gagal: ' + (lastErrMsg || 'Periksa koneksi internet Anda.'), 'danger');
                    }
                }
            });
        });
    }

    window.syncPfaOfflineQueue = syncOfflineQueueNow;

    // --- Scanner Google ML Kit + Fallback Html5Qrcode dengan Tombol Senter ---
    function applyScannedBarcode(targetId, rawCode) {
        var cleanCode = String(rawCode || '').trim();
        if (!cleanCode) return;
        var inp = targetId ? document.getElementById(targetId) : null;
        if (inp) {
            inp.value = cleanCode;
            inp.dispatchEvent(new Event('input', { bubbles: true }));
            inp.dispatchEvent(new Event('change', { bubbles: true }));
        }
        if (typeof window.showToast === 'function') {
            window.showToast('Barcode terbaca: ' + cleanCode, 'success');
        }
    }

    var nativeModalQr = null;
    var originalOpenBarcode = typeof window.openBarcodeScanner === 'function' ? window.openBarcodeScanner : null;

    function openHtml5QrcodeFallback(targetId) {
        var modalEl = document.getElementById('barcodeScannerModal');
        if (!modalEl || typeof bootstrap === 'undefined') {
            if (originalOpenBarcode) return originalOpenBarcode(targetId);
            return;
        }

        var statusEl = document.getElementById('qrScanStatus');
        if (statusEl) {
            statusEl.textContent = 'Mengaktifkan kamera belakang...';
            statusEl.classList.remove('d-none');
        }

        var torchOn = false;
        var torchBtn = document.getElementById('pfaBtnTorchModal');
        if (!torchBtn) {
            var bodyEl = modalEl.querySelector('.modal-body');
            if (bodyEl) {
                var wrapBtn = document.createElement('div');
                wrapBtn.className = 'd-flex justify-content-center mb-2';
                wrapBtn.innerHTML = '<button type="button" id="pfaBtnTorchModal" class="btn btn-sm btn-warning fw-semibold d-none"><i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter</button>';
                bodyEl.insertBefore(wrapBtn, bodyEl.firstChild);
                torchBtn = document.getElementById('pfaBtnTorchModal');
            }
        }
        if (torchBtn) {
            torchBtn.className = 'btn btn-sm btn-warning fw-semibold d-none';
            torchBtn.innerHTML = '<i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter';
            torchBtn.onclick = function () {
                if (!nativeModalQr) return;
                torchOn = !torchOn;
                nativeModalQr.applyVideoConstraints({ advanced: [{ torch: torchOn }] })
                    .then(function () {
                        torchBtn.className = 'btn btn-sm fw-semibold ' + (torchOn ? 'btn-dark' : 'btn-warning');
                        torchBtn.innerHTML = torchOn
                            ? '<i class="bi bi-lightbulb-off-fill me-1"></i> Matikan Senter'
                            : '<i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter';
                    })
                    .catch(function () {
                        torchOn = false;
                        if (typeof window.showToast === 'function') window.showToast('Senter tidak didukung kamera pada mode ini.', 'warning');
                    });
            };
        }

        var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        function stopInlineScanner() {
            if (!nativeModalQr) return Promise.resolve();
            var ref = nativeModalQr;
            nativeModalQr = null;
            return ref.stop().catch(function () { }).then(function () {
                try { ref.clear(); } catch (e) { }
            });
        }

        modalEl.addEventListener('hidden.bs.modal', function onHide() {
            modalEl.removeEventListener('hidden.bs.modal', onHide);
            torchOn = false;
            stopInlineScanner();
        });

        setTimeout(function () {
            if (typeof Html5Qrcode === 'undefined') {
                if (statusEl) statusEl.textContent = 'Library scanner belum termuat. Gunakan opsi Scan dari Foto di bawah.';
                return;
            }

            stopInlineScanner().then(function () {
                var formats = (typeof Html5QrcodeSupportedFormats !== 'undefined') ? [
                    Html5QrcodeSupportedFormats.CODE_128,
                    Html5QrcodeSupportedFormats.CODE_39,
                    Html5QrcodeSupportedFormats.ITF,
                    Html5QrcodeSupportedFormats.EAN_13,
                    Html5QrcodeSupportedFormats.CODABAR,
                    Html5QrcodeSupportedFormats.QR_CODE
                ] : undefined;

                nativeModalQr = new Html5Qrcode('qrReaderBox', {
                    formatsToSupport: formats,
                    experimentalFeatures: { useBarCodeDetectorIfSupported: true },
                    verbose: false
                });

                var done = false;
                nativeModalQr.start(
                    { facingMode: 'environment' },
                    {
                        fps: 20,
                        qrbox: function (viewW, viewH) {
                            return {
                                width: Math.min(320, Math.floor(viewW * 0.88)),
                                height: Math.min(140, Math.floor(viewH * 0.38))
                            };
                        },
                        videoConstraints: {
                            facingMode: 'environment',
                            width: { ideal: 1280 },
                            height: { ideal: 720 }
                        }
                    },
                    function (decodedText) {
                        if (done) return;
                        done = true;
                        stopInlineScanner().finally(function () {
                            modal.hide();
                            applyScannedBarcode(targetId, decodedText);
                        });
                    },
                    function () { }
                ).then(function () {
                    if (statusEl) statusEl.textContent = 'Arahkan garis barcode / QR meter sejajar kotak...';
                    if (torchBtn) torchBtn.classList.remove('d-none');
                }).catch(function (err) {
                    if (statusEl) {
                        statusEl.textContent = 'Kamera langsung belum diizinkan (' + (err && err.message ? err.message : err) + '). Gunakan Scan dari Foto di bawah.';
                    }
                });
            });
        }, 250);
    }

    window.openBarcodeScanner = function (targetInputId) {
        if (typeof google !== 'undefined' && google.script && google.script.run && originalOpenBarcode) {
            return originalOpenBarcode(targetInputId);
        }

        var targetId = targetInputId || '';
        var mlkit = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.BarcodeScanner;

        if (isCapacitorNative() && mlkit && typeof mlkit.scan === 'function') {
            var checkMod = (typeof mlkit.isGoogleBarcodeScannerModuleAvailable === 'function')
                ? mlkit.isGoogleBarcodeScannerModuleAvailable()
                : Promise.resolve({ available: true });

            checkMod.then(function (modRes) {
                if (modRes && modRes.available === false) {
                    if (typeof mlkit.installGoogleBarcodeScannerModule === 'function') {
                        mlkit.installGoogleBarcodeScannerModule().catch(function () { });
                    }
                    if (typeof window.showToast === 'function') {
                        window.showToast('Menyiapkan modul scanner Google di latar belakang...', 'info');
                    }
                    openHtml5QrcodeFallback(targetId);
                    return null;
                }
                return mlkit.scan();
            }).then(function (result) {
                if (!result) return;
                var list = (result && result.barcodes) || [];
                if (list.length > 0 && (list[0].rawValue || list[0].displayValue)) {
                    applyScannedBarcode(targetId, list[0].rawValue || list[0].displayValue);
                }
            }).catch(function (err) {
                var msg = String((err && err.message) || err || '');
                if (/cancel/i.test(msg)) return;
                openHtml5QrcodeFallback(targetId);
            });
            return;
        }

        openHtml5QrcodeFallback(targetId);
    };

    // --- Cache & Auto-Reload Sebab Kerusakan ---
    function ensureMasterKerusakanLoaded() {
        var sel = document.getElementById('f_sebab_kerusakan');
        if (!sel || sel.options.length > 1) return;
        try {
            var cached = JSON.parse(localStorage.getItem('pfa_cache_master_kerusakan') || '[]');
            if (Array.isArray(cached) && cached.length) {
                var prevVal = sel.value;
                sel.innerHTML = '<option value="">-- Pilih Sebab Kerusakan --</option>';
                cached.forEach(function (item) {
                    var opt = document.createElement('option');
                    opt.value = item;
                    opt.textContent = item;
                    sel.appendChild(opt);
                });
                if (prevVal) sel.value = prevVal;
            }
        } catch (e) { }
        if (typeof window.loadMasterKerusakan === 'function' && getActiveSessionToken()) {
            window.loadMasterKerusakan();
        }
    }

    // --- Lifecycle Events ---
    window.addEventListener('online', function () {
        renderWeakSignalBar();
        refreshOfflineQueueBanner();
        listOfflineQueue().then(function (items) {
            if (items.length > 0 && typeof window.showToast === 'function') {
                window.showToast('Sinyal kembali! Ketuk "Kirim Sekarang" untuk menyinkronkan ' + items.length + ' laporan offline.', 'info');
            }
        });
    });

    window.addEventListener('offline', function () {
        renderWeakSignalBar();
    });

    window.addEventListener('load', function () {
        if (isCapacitorNative()) {
            document.body.classList.add('pfa-native-apk');
            try {
                if (window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater && typeof window.Capacitor.Plugins.CapacitorUpdater.notifyAppReady === 'function') {
                    window.Capacitor.Plugins.CapacitorUpdater.notifyAppReady();
                }
            } catch (eOta) { }
            try {
                if (window.Capacitor.Plugins && window.Capacitor.Plugins.App && typeof window.Capacitor.Plugins.App.getInfo === 'function') {
                    window.Capacitor.Plugins.App.getInfo().then(function (info) {
                        if (info && info.version) localStorage.setItem('pfa_native_apk_version', String(info.version).trim());
                    }).catch(function () { });
                }
            } catch (eInfo) { }
        }

        renderWeakSignalBar();
        refreshOfflineQueueBanner();
        injectCheckUpdateMenuItem();
        bindDirtyFormTrackers();
        wrapSwitchTabWithDirtyGuard();
        setTimeout(ensureMasterKerusakanLoaded, 450);
        setTimeout(updateAllPhotoSizeIndicators, 600);
        setInterval(updateAllPhotoSizeIndicators, 2000);
        setTimeout(function () { checkAppUpdateOnLaunch(false); }, 1800);

        if (isCapacitorNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
            window.Capacitor.Plugins.App.addListener('backButton', function (ev) {
                var openModal = document.querySelector('.modal.show');
                if (openModal && typeof bootstrap !== 'undefined') {
                    var inst = bootstrap.Modal.getInstance(openModal);
                    if (inst) { inst.hide(); return; }
                }
                var portalEl = document.getElementById('tab-portal');
                if (!portalEl && ev && ev.canGoBack) {
                    window.history.back();
                    return;
                }
                var curTab = getActiveVisibleTabName();
                if (curTab !== 'portal' && typeof window.switchTab === 'function') {
                    window.switchTab('portal');
                    return;
                }
                window.Capacitor.Plugins.App.exitApp();
            });
        }
    });
})();