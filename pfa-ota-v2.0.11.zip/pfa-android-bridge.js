/**
 * PFA Android Bridge v2.0.4 (29-Feature Field UX & Reliability Engine)
 * Pengembang: JODI SETIAWAN — PLN ULP Pelabuhan Ratu
 * Arsitektur: Event-driven (tanpa polling berat / anti-lag), modular, dan bebas bentrok antar-fitur.
 */
(function () {
  'use strict';

  var DEV_NAME = 'JODI SETIAWAN';
  var UNIT_NAME = 'PLN ULP Pelabuhan Ratu';
  var OFFLINE_DB_NAME = 'pfa_offline_queue_db';
  var OFFLINE_STORE = 'pending_submissions';
  var QUEUEABLE_ACTIONS = ['simpan_gangguan', 'simpan_pengukuran', 'simpan_p2tl'];
  var WEAK_SIGNAL_PREF_KEY = 'pfa_weak_signal_mode_v1';
  var FONT_LARGE_PREF_KEY = 'pfa_font_large_v1';
  var LAST_SEEN_CHANGELOG_KEY = 'pfa_last_changelog_ver_v1';
  var LAST_SESSION_TOKEN = '';
  var IN_FLIGHT_KEYS = {};
  var LAST_BACK_TS = 0;
  var LOADING_SLOW_TIMER = null;
  var LAST_FAILED_RETRY_FN = null;
  var HAS_PENDING_UPDATE_BADGE = false;

  var CHANGELOG_NOTES = {
    '2.0.5': [
      'PFA AI Neon: Auto-lookup 3 sumber data sekaligus (DIL + Riwayat Gangguan + Cek KCT + MCB standar).',
      'Smart Model Router (Mode Auto / Cepat / Pro) + Cache instan untuk respon jauh lebih cepat.',
      'Tombol Mikrofon (Voice-to-Text Bahasa Indonesia), riwayat chat AI tersimpan di HP, & tombol Salin/Share WA di tiap jawaban AI.',
      'Tombol pintasan AI otomatis mengisi IDPEL ke modul Gangguan, Pengukuran, P2TL, atau Cek KCT.'
    ],
    '2.0.4': [
      'Menu Kirim Masukan / Lapor Kendala langsung ke Admin & Modal Tentang Aplikasi.',
      'Tombol Urungkan (Undo 5 detik) saat tidak sengaja menekan Reset formulir.',
      'Info Sisa Masa Sesi + tombol Segarkan Sesi & Pengaturan Ukuran Teks (Normal/Besar) di Menu ☰.',
      'Getar halus & bunyi bip saat scan barcode, ikon mata (👁️) password, & keyboard angka otomatis.',
      'Double-Back untuk keluar, tombol hapus cepat (×), auto-bersih paste IDPEL, & Enter langsung cari.',
      'Tap-to-Zoom semua foto, konfirmasi hapus foto, auto-tutup keyboard, & tombol Batalkan jika sinyal hang >20 detik.'
    ]
  };

  function isCapacitorNative() {
    return typeof window.Capacitor !== 'undefined' &&
      typeof window.Capacitor.isNativePlatform === 'function' &&
      window.Capacitor.isNativePlatform();
  }

  function getApiUrl() {
    var customUrl = '';
    try { customUrl = String(localStorage.getItem('pfa_custom_api_url') || '').trim(); } catch (e) {}
    if (customUrl) return customUrl;
    return (window.PFA_CONFIG && window.PFA_CONFIG.GAS_API_URL) ? String(window.PFA_CONFIG.GAS_API_URL).trim() : '';
  }

  function isApiUrlConfigured(url) {
    return Boolean(url && url.indexOf('https://script.google.com/macros/s/') === 0 && url.indexOf('PASTE_DEPLOYMENT_ID') === -1);
  }

  function getSessionObj() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return null;
  }

  function getActiveSessionToken() {
    if (LAST_SESSION_TOKEN) return LAST_SESSION_TOKEN;
    var s = getSessionObj();
    if (s && s.sessionToken) {
      LAST_SESSION_TOKEN = String(s.sessionToken).trim();
      return LAST_SESSION_TOKEN;
    }
    return '';
  }

  function escText(v) {
    if (typeof window.escHtml === 'function') return window.escHtml(v);
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatGroupedDigits(val) {
    var s = String(val || '').trim();
    if (!s || !/^\d{8,16}$/.test(s)) return s || '-';
    return s.replace(/(\d{4})(?=\d)/g, '$1 ');
  }

  function formatBytesKB(bytes) {
    if (!bytes || bytes <= 0) return '0 KB';
    var kb = bytes / 1024;
    return kb >= 1024 ? (kb / 1024).toFixed(2) + ' MB' : Math.round(kb) + ' KB';
  }

  function estimateBase64Bytes(dataUrl) {
    if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image/') !== 0) return 0;
    var commaIdx = dataUrl.indexOf(',');
    var b64Len = commaIdx !== -1 ? (dataUrl.length - commaIdx - 1) : dataUrl.length;
    return Math.floor(b64Len * 0.75);
  }

  function hideMobileKeyboard() {
    try {
      if (document.activeElement && typeof document.activeElement.blur === 'function') {
        document.activeElement.blur();
      }
    } catch (e) {}
  }

  // --- [Fitur] Haptic Feedback (Getar Halus) & Bunyi Bip Barcode ---
  function triggerHaptic(pattern) {
    try {
      if (navigator.vibrate) navigator.vibrate(pattern || 45);
    } catch (e) {}
  }

  function playBarcodeBeep() {
    try {
      var AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      var ctx = new AudioCtx();
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1320, ctx.currentTime);
      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.09);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.095);
      setTimeout(function () { try { ctx.close(); } catch (e2) {} }, 180);
    } catch (e) {}
  }

  // --- [Fitur] Pengaturan Ukuran Teks (Normal / Besar) ---
  function applyFontScalePref() {
    var isLarge = false;
    try { isLarge = localStorage.getItem(FONT_LARGE_PREF_KEY) === '1'; } catch (e) {}
    document.documentElement.classList.toggle('pfa-font-large', isLarge);
    var lbl = document.getElementById('pfaFontScaleBadge');
    if (lbl) lbl.textContent = isLarge ? 'Besar' : 'Normal';
  }

  window.togglePfaFontScale = function () {
    var next = !document.documentElement.classList.contains('pfa-font-large');
    try { localStorage.setItem(FONT_LARGE_PREF_KEY, next ? '1' : '0'); } catch (e) {}
    applyFontScalePref();
    if (typeof window.showToast === 'function') {
      window.showToast(next ? 'Ukuran teks diubah ke mode Besar.' : 'Ukuran teks kembali ke Normal.', 'info');
    }
  };

  // --- [Fitur] Mode Sinyal Lemah & Kompresi Foto Adaptif ---
  function isAutoWeakNetwork() {
    if (navigator.onLine === false) return true;
    var conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if (conn) {
      var eff = String(conn.effectiveType || '').toLowerCase();
      if (eff === 'slow-2g' || eff === '2g' || eff === '3g' || conn.saveData) return true;
    }
    return false;
  }

  function isWeakSignalModeActive() {
    try {
      var pref = localStorage.getItem(WEAK_SIGNAL_PREF_KEY);
      if (pref === '1') return true;
      if (pref === '0') return false;
    } catch (e) {}
    return isAutoWeakNetwork();
  }

  function setWeakSignalPref(val) {
    try {
      if (val === null) localStorage.removeItem(WEAK_SIGNAL_PREF_KEY);
      else localStorage.setItem(WEAK_SIGNAL_PREF_KEY, val ? '1' : '0');
    } catch (e) {}
    renderWeakSignalBar();
    schedulePhotoSizeUpdate();
  }

  function compressDataUrl(dataUrl, maxDim, quality) {
    return new Promise(function (resolve) {
      if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image/') !== 0 || dataUrl.length < 120000) {
        resolve(dataUrl);
        return;
      }
      var img = new Image();
      img.onload = function () {
        try {
          var w = img.naturalWidth || img.width;
          var h = img.naturalHeight || img.height;
          if (!w || !h) { resolve(dataUrl); return; }
          var scale = Math.min(1, maxDim / Math.max(w, h));
          var nw = Math.max(1, Math.round(w * scale));
          var nh = Math.max(1, Math.round(h * scale));
          var canvas = document.createElement('canvas');
          canvas.width = nw;
          canvas.height = nh;
          canvas.getContext('2d').drawImage(img, 0, 0, nw, nh);
          var out = canvas.toDataURL('image/jpeg', quality);
          resolve(out && out.length < dataUrl.length ? out : dataUrl);
        } catch (e) { resolve(dataUrl); }
      };
      img.onerror = function () { resolve(dataUrl); };
      img.src = dataUrl;
    });
  }

  function compressPayloadPhotos(payload) {
    if (!payload || !payload.fotos || typeof payload.fotos !== 'object') return Promise.resolve(payload);
    var weak = isWeakSignalModeActive();
    var maxDim = weak ? 800 : 1280;
    var quality = weak ? 0.55 : 0.78;
    var fotosCopy = Object.assign({}, payload.fotos);
    var chain = Promise.resolve();

    Object.keys(fotosCopy).forEach(function (k) {
      var val = fotosCopy[k];
      if (typeof val === 'string' && val.indexOf('data:image/') === 0) {
        chain = chain.then(function () {
          return compressDataUrl(val, maxDim, quality).then(function (res) { fotosCopy[k] = res; });
        });
      } else if (Array.isArray(val)) {
        chain = chain.then(function () {
          var arrCopy = val.map(function (it) { return it && typeof it === 'object' ? Object.assign({}, it) : it; });
          var inner = Promise.resolve();
          arrCopy.forEach(function (item, idx) {
            if (item && typeof item.base64 === 'string' && item.base64.indexOf('data:image/') === 0) {
              inner = inner.then(function () {
                return compressDataUrl(item.base64, maxDim, quality).then(function (res) { arrCopy[idx].base64 = res; });
              });
            }
          });
          return inner.then(function () { fotosCopy[k] = arrCopy; });
        });
      }
    });

    return chain.then(function () { return Object.assign({}, payload, { fotos: fotosCopy }); });
  }

  function countPayloadPhotos(fotos) {
    var count = 0;
    var bytes = 0;
    if (!fotos || typeof fotos !== 'object') return { count: 0, bytes: 0 };
    Object.keys(fotos).forEach(function (k) {
      var val = fotos[k];
      if (typeof val === 'string' && val.indexOf('data:image/') === 0) {
        count++; bytes += estimateBase64Bytes(val);
      } else if (Array.isArray(val)) {
        val.forEach(function (it) {
          if (it && typeof it.base64 === 'string' && it.base64.indexOf('data:image/') === 0) {
            count++; bytes += estimateBase64Bytes(it.base64);
          }
        });
      }
    });
    return { count: count, bytes: bytes };
  }

  function renderWeakSignalBar() {
    var container = document.querySelector('#appScreen .container');
    if (!container) return;
    var bar = document.getElementById('pfaWeakSignalBar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'pfaWeakSignalBar';
      bar.className = 'd-flex justify-content-between align-items-center mb-2 px-2 py-1 rounded-3 border bg-white';
      container.insertBefore(bar, container.firstChild);
    }
    var active = isWeakSignalModeActive();
    var offline = navigator.onLine === false;
    var badgeHtml = offline
      ? '<span class="badge text-bg-danger me-1">Offline</span>'
      : (active ? '<span class="badge text-bg-warning text-dark me-1">Hemat Sinyal</span>' : '<span class="badge text-bg-success me-1">Normal</span>');

    bar.innerHTML =
      '<div class="d-flex align-items-center text-truncate">' +
      badgeHtml +
      '<span class="text-muted text-truncate">' + (active ? 'Kompresi foto aktif (ringan)' : 'Kualitas foto standar') + '</span>' +
      '</div>' +
      '<button type="button" class="btn btn-sm py-0 px-2 ' + (active ? 'btn-warning' : 'btn-outline-secondary') + '" id="btnToggleWeakSignal">' +
      (active ? 'Matikan Hemat' : 'Mode Sinyal Lemah') +
      '</button>';

    var btn = document.getElementById('btnToggleWeakSignal');
    if (btn) {
      btn.onclick = function () {
        setWeakSignalPref(!active);
        if (typeof window.showToast === 'function') {
          window.showToast(!active ? 'Mode Sinyal Lemah aktif: foto otomatis dikompres lebih ringan.' : 'Kembali ke kualitas foto standar.', 'info');
        }
      };
    }
  }

  // --- [Fitur] Indikator Offline di Halaman Login ---
  function renderLoginOfflineBanner() {
    var loginScreen = document.getElementById('loginScreen');
    if (!loginScreen) return;
    var form = loginScreen.querySelector('form');
    if (!form) return;
    var el = document.getElementById('pfaLoginOfflineAlert');
    if (!el) {
      el = document.createElement('div');
      el.id = 'pfaLoginOfflineAlert';
      el.className = 'alert alert-danger py-2 px-3 small rounded-3 mb-3 d-none';
      el.innerHTML = '<i class="bi bi-wifi-off me-1 fw-bold"></i> Perangkat sedang <strong>offline</strong>. Aktifkan data seluler atau Wi-Fi untuk login.';
      form.parentNode.insertBefore(el, form);
    }
    el.classList.toggle('d-none', navigator.onLine !== false);
  }

  // --- [Fitur] Indikator Live Total Ukuran Foto (Debounced, Tanpa Polling!) ---
  var PHOTO_BTN_TARGETS = [
    { tabId: 'tab-gangguan', btnSel: '#gangguanForm button[type="submit"]' },
    { tabId: 'tab-pengukuran', btnSel: 'button[onclick*="simpanHasilPengukuran"]' },
    { tabId: 'tab-p2tl', btnSel: '#p2tlForm button[type="submit"]' }
  ];
  var photoSizeDebounceTimer = null;

  function updateAllPhotoSizeIndicators() {
    var weak = isWeakSignalModeActive();
    PHOTO_BTN_TARGETS.forEach(function (cfg) {
      var btn = document.querySelector(cfg.btnSel);
      var tabEl = document.getElementById(cfg.tabId);
      if (!btn || !tabEl) return;
      var count = 0;
      var bytes = 0;
      var hiddenInputs = tabEl.querySelectorAll('input[type="hidden"]');
      for (var i = 0; i < hiddenInputs.length; i++) {
        var v = hiddenInputs[i].value || '';
        if (v.indexOf('data:image/') === 0) {
          count++;
          bytes += estimateBase64Bytes(v);
        }
      }
      var estBytes = weak ? Math.round(bytes * 0.45) : Math.round(bytes * 0.78);
      var suffix = count > 0 ? ' • ' + count + ' foto (~' + formatBytesKB(estBytes) + ')' : '';
      var span = btn.querySelector('.pfa-upload-meta');
      if (!span) {
        span = document.createElement('span');
        span.className = 'pfa-upload-meta fw-normal';
        span.style.fontSize = '0.82em';
        btn.appendChild(span);
      }
      span.textContent = suffix;
    });
  }

  function schedulePhotoSizeUpdate() {
    clearTimeout(photoSizeDebounceTimer);
    photoSizeDebounceTimer = setTimeout(updateAllPhotoSizeIndicators, 220);
  }

  // --- [Fitur] Layar Ringkasan Konfirmasi (Review Before Submit) ---
  function buildReviewRowsHtml(action, dataObj, photoStats) {
    var d = dataObj || {};
    var rows = [];
    if (action === 'simpan_gangguan') {
      rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
      rows.push(['Nama Pelanggan', d.nama_pelanggan || d.nama || '-']);
      rows.push(['No. Form DG', d.no_form_dg || '-']);
      rows.push(['Status TL', d.status_tindak_lanjut || d.status_tl || '-']);
      rows.push(['No. Meter Lama', formatGroupedDigits(d.no_meter_lama)]);
      if (d.no_meter_baru) rows.push(['No. Meter Baru', formatGroupedDigits(d.no_meter_baru)]);
      if (d.no_segel_baru) rows.push(['No. Segel Baru', d.no_segel_baru]);
      if (d.sisa_kwh) rows.push(['Sisa kWh', d.sisa_kwh]);
      rows.push(['Sebab Kerusakan', d.sebab_kerusakan || '-']);
    } else if (action === 'simpan_pengukuran') {
      rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
      rows.push(['Nama Pelanggan', d.nama_pelanggan || d.nama || '-']);
      if (d.no_meter) rows.push(['No. Meter', formatGroupedDigits(d.no_meter)]);
      if (d.deviasi_kwh != null && d.deviasi_kwh !== '') rows.push(['Deviasi kWh', d.deviasi_kwh + ' %']);
      if (d.fkm) rows.push(['FKM', d.fkm]);
      if (d.petugas) rows.push(['Petugas', d.petugas]);
    } else if (action === 'simpan_p2tl') {
      rows.push(['Kategori', d.kategori_pelanggan || d.kategori || '-']);
      if (d.id_pelanggan || d.idpel) rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
      rows.push(['Nama', d.nama_pelanggan || d.nama || '-']);
      if (d.golongan_temuan || d.kode_pelanggaran) rows.push(['Temuan / Kode', d.golongan_temuan || d.kode_pelanggaran]);
      if (d.total_tagihan || d.tagihan_susulan) rows.push(['Estimasi TS', d.total_tagihan || d.tagihan_susulan]);
      if (d.status_penertiban) rows.push(['Penertiban', d.status_penertiban]);
    }
    var modeLbl = isWeakSignalModeActive() ? 'Mode Sinyal Lemah' : 'Standar';
    rows.push(['Lampiran Foto', photoStats.count + ' foto (' + formatBytesKB(photoStats.bytes) + ' • ' + modeLbl + ')']);

    return rows.map(function (r) {
      return '<div class="d-flex justify-content-between gap-2 py-1 border-bottom">' +
        '<span class="text-muted">' + escText(r[0]) + '</span>' +
        '<strong class="text-end text-dark" style="word-break:break-word;">' + escText(r[1]) + '</strong>' +
      '</div>';
    }).join('');
  }

  function showReviewBeforeSubmitModal(payload) {
    return new Promise(function (resolve) {
      var old = document.getElementById('pfaReviewSubmitModal');
      if (old) old.remove();
      var titleMap = {
        simpan_gangguan: 'Cek Ulang Laporan Gangguan',
        simpan_pengukuran: 'Cek Ulang Hasil Pengukuran',
        simpan_p2tl: 'Cek Ulang Data P2TL / K2'
      };
      var photoStats = countPayloadPhotos(payload.fotos);
      var rowsHtml = buildReviewRowsHtml(payload.action, payload.data, photoStats);
      var offlineWarn = navigator.onLine === false
        ? '<div class="alert alert-warning py-1 px-2 small mt-2 mb-0"><i class="bi bi-wifi-off me-1"></i>Sedang offline: laporan akan disimpan ke <strong>Antrean Offline</strong>.</div>'
        : '';

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="pfaReviewSubmitModal" tabindex="-1" data-bs-backdrop="static">' +
        '  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
        '    <div class="modal-content rounded-4 border-0 shadow">' +
        '      <div class="modal-header bg-primary text-white py-2">' +
        '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-clipboard-check-fill me-1"></i> ' + escText(titleMap[payload.action] || 'Konfirmasi Kirim Data') + '</h6>' +
        '        <button type="button" class="btn-close btn-close-white" id="btnRevCloseX" aria-label="Batal"></button>' +
        '      </div>' +
        '      <div class="modal-body small">' +
        '        <p class="text-muted mb-2">Pastikan IDPEL, nomor meter, dan foto sudah sesuai sebelum dikirim:</p>' +
        '        <div class="px-2 py-1 rounded-3 bg-light border">' + rowsHtml + '</div>' +
                 offlineWarn +
        '      </div>' +
        '      <div class="modal-footer py-2 d-flex justify-content-between gap-2">' +
        '        <button type="button" class="btn btn-outline-secondary btn-sm flex-grow-1" id="btnRevCancel"><i class="bi bi-pencil-square me-1"></i> Kembali Edit</button>' +
        '        <button type="button" class="btn btn-success btn-sm fw-semibold flex-grow-1" id="btnRevConfirm"><i class="bi bi-send-check-fill me-1"></i> Ya, Kirim Sekarang</button>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>';

      document.body.appendChild(wrap.firstChild);
      var modalEl = document.getElementById('pfaReviewSubmitModal');
      var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
      function done(ok) {
        if (inst) inst.hide();
        modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); resolve(ok); }, { once: true });
        if (!inst) { modalEl.remove(); resolve(ok); }
      }
      document.getElementById('btnRevConfirm').onclick = function () { done(true); };
      document.getElementById('btnRevCancel').onclick = function () { done(false); };
      document.getElementById('btnRevCloseX').onclick = function () { done(false); };
      if (typeof window.setLoading === 'function') window.setLoading(false);
      if (inst) inst.show(); else resolve(true);
    });
  }

  // --- [Fitur] Peringatan Keluar Form Belum Disimpan + Lencana Draft Bottom Nav + Auto-Scroll Atas + Animasi Tab ---
  var DIRTY_FORM_TABS = { gangguan: false, pengukuran: false, p2tl: false };

  function getActiveVisibleTabName() {
    var tabs = ['gangguan', 'pengukuran', 'p2tl', 'portal', 'kct', 'material', 'chatbot', 'tutorial', 'admin'];
    for (var i = 0; i < tabs.length; i++) {
      var el = document.getElementById('tab-' + tabs[i]);
      if (el && !el.classList.contains('d-none')) return tabs[i];
    }
    return 'portal';
  }

  function updateBottomNavDraftDots() {
    ['gangguan', 'pengukuran'].forEach(function (t) {
      var nav = document.getElementById('nav-' + t);
      if (!nav) return;
      var hasDraft = Boolean(DIRTY_FORM_TABS[t]);
      if (t === 'gangguan') {
        try { if (localStorage.getItem('pfa_gangguan_draft_v1')) hasDraft = true; } catch (e) {}
      }
      nav.classList.toggle('pfa-has-draft', hasDraft);
    });
  }

  function markTabDirty(tabName, isDirty) {
    if (Object.prototype.hasOwnProperty.call(DIRTY_FORM_TABS, tabName)) {
      DIRTY_FORM_TABS[tabName] = Boolean(isDirty);
      updateBottomNavDraftDots();
    }
  }

  function confirmLeaveDirtyForm(currentTabName) {
    return new Promise(function (resolve) {
      var old = document.getElementById('pfaUnsavedLeaveModal');
      if (old) old.remove();
      var labelMap = { gangguan: 'Gangguan', pengukuran: 'Pengukuran', p2tl: 'P2TL / K2' };
      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="pfaUnsavedLeaveModal" tabindex="-1">' +
        '  <div class="modal-dialog modal-dialog-centered">' +
        '    <div class="modal-content rounded-4 border-0 shadow">' +
        '      <div class="modal-header bg-warning text-dark py-2">' +
        '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-exclamation-circle-fill me-1"></i> Formulir Belum Disimpan</h6>' +
        '      </div>' +
        '      <div class="modal-body small">' +
        '        Anda memiliki isian pada formulir <strong>' + escText(labelMap[currentTabName] || currentTabName) + '</strong> yang belum dikirim. Tetap keluar dari halaman ini?' +
        '      </div>' +
        '      <div class="modal-footer py-2">' +
        '        <button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnStayForm">Tetap di Formulir</button>' +
        '        <button type="button" class="btn btn-outline-danger btn-sm" id="btnLeaveForm">Keluar</button>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>';
      document.body.appendChild(wrap.firstChild);
      var modalEl = document.getElementById('pfaUnsavedLeaveModal');
      var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
      var resolved = false;
      function finish(leave) {
        if (resolved) return;
        resolved = true;
        if (inst) inst.hide();
        modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); resolve(leave); }, { once: true });
        if (!inst) { modalEl.remove(); resolve(leave); }
      }
      document.getElementById('btnStayForm').onclick = function () { finish(false); };
      document.getElementById('btnLeaveForm').onclick = function () { finish(true); };
      modalEl.addEventListener('hidden.bs.modal', function () {
        if (!resolved) { resolved = true; modalEl.remove(); resolve(false); }
      }, { once: true });
      if (inst) inst.show(); else resolve(true);
    });
  }

  function wrapSwitchTabWithEnhancements() {
    if (typeof window.switchTab !== 'function' || window._pfaSwitchTabWrapped) return;
    window._pfaSwitchTabWrapped = true;
    var origSwitchTab = window.switchTab;
    window.switchTab = function (nextTab) {
      hideMobileKeyboard();
      var curTab = getActiveVisibleTabName();
      function proceed() {
        origSwitchTab(nextTab);
        // Auto-scroll halus ke atas & animasi masuk tab
        try { window.scrollTo({ top: 0, behavior: 'instant' }); } catch (e) { window.scrollTo(0, 0); }
        var targetEl = document.getElementById('tab-' + nextTab);
        if (targetEl) {
          targetEl.classList.remove('pfa-tab-enter');
          void targetEl.offsetWidth;
          targetEl.classList.add('pfa-tab-enter');
        }
        schedulePhotoSizeUpdate();
      }
      if (curTab !== nextTab && DIRTY_FORM_TABS[curTab]) {
        confirmLeaveDirtyForm(curTab).then(function (leave) {
          if (leave) {
            markTabDirty(curTab, false);
            proceed();
          }
        });
        return;
      }
      proceed();
    };
  }

  // --- [Fitur] Tombol Urungkan (Undo 5 Detik) Saat Reset Formulir ---
  var undoResetTimer = null;
  function captureFormSnapshot(container) {
    var snap = [];
    if (!container) return snap;
    var fields = container.querySelectorAll('input, select, textarea');
    for (var i = 0; i < fields.length; i++) {
      var f = fields[i];
      if (!f.id || f.type === 'file') continue;
      snap.push({ id: f.id, type: f.type, value: f.value, checked: f.checked });
    }
    return snap;
  }

  function showUndoResetToast(snapshot, tabName) {
    if (!snapshot || !snapshot.length) return;
    var hasAnyVal = snapshot.some(function (it) { return it.value && String(it.value).trim() !== ''; });
    if (!hasAnyVal) return;

    var old = document.getElementById('pfaUndoResetBar');
    if (old) old.remove();
    clearTimeout(undoResetTimer);

    var bar = document.createElement('div');
    bar.id = 'pfaUndoResetBar';
    bar.className = 'alert alert-dark d-flex justify-content-between align-items-center py-2 px-3 rounded-4 shadow-lg mb-0';
    bar.innerHTML =
      '<span class="small"><i class="bi bi-arrow-counterclockwise me-1"></i> Formulir direset.</span>' +
      '<button type="button" class="btn btn-warning btn-sm fw-bold py-0 px-2" id="btnPfaUndoReset">Urungkan</button>';
    document.body.appendChild(bar);

    document.getElementById('btnPfaUndoReset').onclick = function () {
      clearTimeout(undoResetTimer);
      snapshot.forEach(function (it) {
        var el = document.getElementById(it.id);
        if (!el) return;
        if (it.type === 'checkbox' || it.type === 'radio') el.checked = it.checked;
        else el.value = it.value;
      });
      if (tabName) markTabDirty(tabName, true);
      schedulePhotoSizeUpdate();
      bar.remove();
      if (typeof window.showToast === 'function') window.showToast('Isian formulir dikembalikan.', 'success');
    };

    undoResetTimer = setTimeout(function () { if (bar.parentNode) bar.remove(); }, 5500);
  }

  // --- [Fitur] Hook Loading Overlay: Tombol Batalkan Jika Sinyal Hang >20 Detik ---
  function wrapSetLoadingWithSlowCancel() {
    if (typeof window.setLoading !== 'function' || window._pfaLoadingWrapped) return;
    window._pfaLoadingWrapped = true;
    var origSetLoading = window.setLoading;
    window.setLoading = function (show, text) {
      origSetLoading(show, text);
      clearTimeout(LOADING_SLOW_TIMER);
      var cancelBtn = document.getElementById('pfaSlowCancelBtn');
      if (!show) {
        if (cancelBtn) cancelBtn.classList.add('d-none');
        return;
      }
      var overlay = document.getElementById('loadingOverlay');
      if (overlay && !cancelBtn) {
        cancelBtn = document.createElement('button');
        cancelBtn.id = 'pfaSlowCancelBtn';
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn btn-sm btn-outline-light mt-3 d-none';
        cancelBtn.innerHTML = '<i class="bi bi-x-circle me-1"></i> Sinyal lambat — Batalkan Tunggu';
        cancelBtn.onclick = function () {
          origSetLoading(false);
          cancelBtn.classList.add('d-none');
          if (typeof window.showToast === 'function') {
            window.showToast('Layar tunggu ditutup. Anda bisa coba lagi atau aktifkan Mode Sinyal Lemah.', 'warning');
          }
        };
        var box = overlay.querySelector('.text-center') || overlay;
        box.appendChild(cancelBtn);
      }
      LOADING_SLOW_TIMER = setTimeout(function () {
        var btnNow = document.getElementById('pfaSlowCancelBtn');
        if (btnNow && overlay && overlay.style.display !== 'none') {
          btnNow.classList.remove('d-none');
        }
      }, 20000);
    };
  }

  // --- [Fitur] Tap-to-Zoom Lightbox Universal untuk Semua Foto ---
  function openPhotoZoomLightbox(imgSrc) {
    if (!imgSrc) return;
    var old = document.getElementById('pfaPhotoZoomModal');
    if (old) old.remove();
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaPhotoZoomModal" tabindex="-1">' +
      '  <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">' +
      '    <div class="modal-content bg-dark text-white border-0">' +
      '      <div class="modal-header border-0 py-2">' +
      '        <h6 class="modal-title small mb-0"><i class="bi bi-zoom-in me-1"></i> Pratinjau Foto</h6>' +
      '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
      '      </div>' +
      '      <div class="modal-body d-flex align-items-center justify-content-center p-2" style="overflow:auto;">' +
      '        <img src="' + escText(imgSrc) + '" style="max-width:100%; max-height:80vh; object-fit:contain; border-radius:8px;" alt="Zoom Foto">' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var modalEl = document.getElementById('pfaPhotoZoomModal');
    var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
    modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); }, { once: true });
    if (inst) inst.show();
  }

  // --- [Fitur] Sapaan Otomatis Sesuai Jam di Portal ---
  function injectPortalGreeting() {
    var portal = document.getElementById('tab-portal');
    if (!portal || document.getElementById('pfaPortalGreeting')) return;
    var h = new Date().getHours();
    var salam = h < 11 ? 'Selamat Pagi' : (h < 15 ? 'Selamat Siang' : (h < 18 ? 'Selamat Sore' : 'Selamat Malam'));
    var s = getSessionObj();
    var nama = (s && s.user && s.user.nama) ? s.user.nama : 'Petugas';
    var tgl = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    var box = document.createElement('div');
    box.id = 'pfaPortalGreeting';
    box.className = 'd-flex justify-content-between align-items-center flex-wrap gap-1 px-3 py-2 mb-2 rounded-3 bg-white border';
    box.innerHTML =
      '<div class="small fw-semibold text-dark">' + escText(salam) + ', <span class="text-primary">' + escText(nama) + '</span></div>' +
      '<div class="text-muted" style="font-size:0.74rem;">' + escText(tgl) + '</div>';
    portal.insertBefore(box, portal.firstChild);
  }

  // --- [Fitur] Kartu Panduan Khusus Android di Tab Tutorial ---
  function injectAndroidTutorialCard() {
    var tut = document.getElementById('tab-tutorial');
    if (!tut || document.getElementById('pfaAndroidTutCard')) return;
    var card = document.createElement('div');
    card.id = 'pfaAndroidTutCard';
    card.className = 'card card-modern border-primary border-opacity-25 mb-3';
    card.innerHTML =
      '<div class="card-body py-3">' +
      '  <div class="d-flex align-items-center gap-2 mb-2">' +
      '    <span class="badge text-bg-primary">Khusus Aplikasi Android</span>' +
      '    <strong class="small text-dark">Panduan Cepat Fitur Lapangan</strong>' +
      '  </div>' +
      '  <ul class="small text-muted ps-3 mb-0">' +
      '    <li class="mb-1"><strong>Antrean Offline:</strong> Saat blankspot, tetap tekan Simpan—data &amp; foto aman di HP lalu kirim lewat banner biru saat sinyal kembali.</li>' +
      '    <li class="mb-1"><strong>Mode Sinyal Lemah:</strong> Aktifkan tombol di atas layar agar foto otomatis dikompres lebih ringan dan cepat terunggah.</li>' +
      '    <li class="mb-1"><strong>Update Otomatis &amp; Lapor Kendala:</strong> Buka menu <strong>☰</strong> di pojok kanan atas untuk Cek Update, perpanjang sesi, atau kirim masukan ke pengembang.</li>' +
      '    <li><strong>Ketuk Foto untuk Zoom:</strong> Ketuk foto pratinjau mana saja untuk memperbesar dan memeriksa kejelasan angka meter.</li>' +
      '  </ul>' +
      '</div>';
    tut.insertBefore(card, tut.firstChild);
  }

  // --- [Fitur] Ikon Mata Password, Keyboard Angka Otomatis, Tombol Clear (x), & Enter Langsung Cari ---
  function enhanceInputsUniversal() {
    // 1. Ikon Mata (👁️) pada semua input password (Login & Ganti Password)
    var passInputs = document.querySelectorAll('input[type="password"]');
    for (var i = 0; i < passInputs.length; i++) {
      (function (inp) {
        if (inp.dataset.pfaEyeBound) return;
        inp.dataset.pfaEyeBound = '1';
        var parent = inp.parentElement;
        if (!parent) return;
        if (!parent.classList.contains('input-group')) {
          var grp = document.createElement('div');
          grp.className = 'input-group';
          parent.insertBefore(grp, inp);
          grp.appendChild(inp);
          parent = grp;
        }
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-outline-secondary';
        btn.title = 'Tampilkan/Sembunyikan Password';
        btn.innerHTML = '<i class="bi bi-eye"></i>';
        btn.onclick = function () {
          var show = inp.type === 'password';
          inp.type = show ? 'text' : 'password';
          btn.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
        };
        parent.appendChild(btn);
      })(passInputs[i]);
    }

    // 2. Keyboard Angka Besar Otomatis (inputmode="numeric") pada kolom angka IDPEL / Meter / HP / Stand
    var numericIds = [
      'cariPelangganInput', 'f_id_pelanggan', 'f_no_telepon', 'f_no_meter_lama',
      'f_no_meter_baru', 'f_no_pelapor', 'kctSearchInput', 'u_cari_pelanggan',
      'p2tl_cari_pelanggan', 'p2tl_idpel'
    ];
    numericIds.forEach(function (id) {
      var el = document.getElementById(id);
      if (el && el.tagName === 'INPUT') {
        el.setAttribute('inputmode', 'numeric');
        el.setAttribute('enterkeyhint', /cari|search/i.test(id) ? 'search' : 'next');
      }
    });

    // 3. Tombol Hapus Cepat (x) + Enter Langsung Cari pada kolom pencarian DIL & KCT
    var searchMap = [
      { id: 'cariPelangganInput', fnName: 'cariPelanggan' },
      { id: 'kctSearchInput', fnName: 'cariKct' },
      { id: 'u_cari_pelanggan', fnName: 'cariPelangganPengukuran' },
      { id: 'p2tl_cari_pelanggan', fnName: 'cariPelangganP2tl' }
    ];
    searchMap.forEach(function (cfg) {
      var inp = document.getElementById(cfg.id);
      if (!inp || inp.dataset.pfaSearchBound) return;
      inp.dataset.pfaSearchBound = '1';

      // Enter di keyboard HP langsung cari
      inp.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          hideMobileKeyboard();
          if (typeof window[cfg.fnName] === 'function') window[cfg.fnName]();
        }
      });

      // Tombol (x) di dalam input-group
      var grp = inp.closest('.input-group');
      if (grp) {
        var clrBtn = document.createElement('button');
        clrBtn.type = 'button';
        clrBtn.className = 'btn btn-outline-secondary pfa-clear-btn d-none';
        clrBtn.title = 'Hapus teks';
        clrBtn.innerHTML = '<i class="bi bi-x-lg"></i>';
        clrBtn.onclick = function () {
          inp.value = '';
          clrBtn.classList.add('d-none');
          inp.focus();
        };
        inp.addEventListener('input', function () {
          clrBtn.classList.toggle('d-none', !inp.value);
        });
        inp.parentNode.insertBefore(clrBtn, inp.nextSibling);
      }
    });
  }

  // --- [Fitur] Menu ☰ Lengkap (Cek Update, Sisa Sesi + Segarkan, Ukuran Teks, Lapor Kendala, Tentang Aplikasi + Badge Dot) ---
  function getSessionRemainingMinutes() {
    var s = getSessionObj();
    if (!s || !s.expiresAt) return 0;
    return Math.max(0, Math.round((Number(s.expiresAt) - Date.now()) / 60000));
  }

  function updateMenuNotificationDot() {
    var mins = getSessionRemainingMinutes();
    var sessionLow = mins > 0 && mins <= 45;
    var showDot = HAS_PENDING_UPDATE_BADGE || sessionLow;
    var menuBtn = document.querySelector('#appScreen .topbar-pln .dropdown > button');
    if (!menuBtn) return;
    menuBtn.classList.add('pfa-menu-btn-wrap');
    var dot = document.getElementById('pfaMenuAlertDot');
    if (showDot && !dot) {
      dot = document.createElement('span');
      dot.id = 'pfaMenuAlertDot';
      dot.className = 'pfa-menu-dot';
      menuBtn.appendChild(dot);
    } else if (!showDot && dot) {
      dot.remove();
    }
    var sessEl = document.getElementById('pfaSessionRemLabel');
    if (sessEl) {
      if (mins >= 60) sessEl.textContent = Math.floor(mins / 60) + 'j ' + (mins % 60) + 'm';
      else sessEl.textContent = mins + ' mnt';
      sessEl.className = 'badge ms-1 ' + (sessionLow ? 'text-bg-warning text-dark' : 'text-bg-light border');
    }
  }

  window.refreshPfaSessionNow = function () {
    var apiUrl = getApiUrl();
    if (!isApiUrlConfigured(apiUrl)) return;
    if (typeof window.setLoading === 'function') window.setLoading(true, 'Menyegarkan sesi login...');
    postToGas(apiUrl, { action: 'get_module_permissions', sessionToken: getActiveSessionToken() })
      .then(function (res) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (res && res.status === 'success') {
          var s = getSessionObj();
          if (s) {
            s.expiresAt = Date.now() + (6 * 60 * 60 * 1000);
            localStorage.setItem('pfa_session_v1', JSON.stringify(s));
          }
          updateMenuNotificationDot();
          if (typeof window.showToast === 'function') window.showToast('Sesi login diperpanjang (aktif 6 jam ke depan).', 'success');
        }
      })
      .catch(function (err) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (typeof window.showToast === 'function') window.showToast('Gagal segarkan sesi: ' + ((err && err.message) || err), 'danger');
      });
  };

  window.openPfaFeedbackModal = function () {
    var old = document.getElementById('pfaFeedbackModal');
    if (old) old.remove();
    var ver = getCurrentInstalledVersion();
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaFeedbackModal" tabindex="-1">' +
      '  <div class="modal-dialog modal-dialog-centered">' +
      '    <div class="modal-content rounded-4 border-0 shadow">' +
      '      <div class="modal-header bg-primary text-white py-2">' +
      '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-chat-square-heart-fill me-1"></i> Kirim Masukan / Lapor Kendala</h6>' +
      '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
      '      </div>' +
      '      <div class="modal-body small">' +
      '        <div class="mb-2">' +
      '          <label class="form-label fw-semibold mb-1">Kategori</label>' +
      '          <select id="pfaFbKat" class="form-select form-select-sm">' +
      '            <option value="Kendala / Bug">Kendala / Bug Aplikasi</option>' +
      '            <option value="Saran Fitur">Saran Fitur Baru</option>' +
      '            <option value="Data DIL / KCT">Masalah Data DIL / KCT</option>' +
      '          </select>' +
      '        </div>' +
      '        <div class="mb-2">' +
      '          <label class="form-label fw-semibold mb-1">Detail Kendala / Saran</label>' +
      '          <textarea id="pfaFbMsg" class="form-control form-control-sm" rows="4" placeholder="Jelaskan kendala atau saran fitur yang diinginkan..."></textarea>' +
      '        </div>' +
      '        <div class="text-muted" style="font-size:0.74rem;">Versi terlampir otomatis: <strong>v' + escText(ver) + '</strong></div>' +
      '      </div>' +
      '      <div class="modal-footer py-2">' +
      '        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Batal</button>' +
      '        <button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnSendPfaFeedback"><i class="bi bi-send-fill me-1"></i> Kirim ke Admin</button>' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var modalEl = document.getElementById('pfaFeedbackModal');
    var inst = bootstrap.Modal.getOrCreateInstance(modalEl);
    modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); }, { once: true });

    document.getElementById('btnSendPfaFeedback').onclick = function () {
      var msg = String(document.getElementById('pfaFbMsg').value || '').trim();
      var kat = document.getElementById('pfaFbKat').value;
      if (!msg) {
        if (typeof window.showToast === 'function') window.showToast('Tulis dulu detail masukan atau kendala.', 'warning');
        return;
      }
      var s = getSessionObj();
      var u = (s && s.user) || {};
      if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengirim masukan...');
      window.callApi({
        action: 'kirim_masukan_pfa',
        kategori: kat,
        pesan: msg,
        versi: ver,
        petugasNama: u.nama || '-',
        username: u.username || '-'
      }).then(function (res) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (res && res.status === 'success') {
          inst.hide();
          triggerHaptic(50);
          if (typeof window.showToast === 'function') window.showToast('Terima kasih! Masukan berhasil dikirim ke pengembang.', 'success');
        } else {
          if (typeof window.showToast === 'function') window.showToast((res && res.message) || 'Gagal mengirim masukan.', 'danger');
        }
      }).catch(function (err) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (typeof window.showToast === 'function') window.showToast('Gagal kirim masukan: ' + ((err && err.message) || err), 'danger');
      });
    };
    inst.show();
  };

  window.openPfaAboutModal = function () {
    var old = document.getElementById('pfaAboutModal');
    if (old) old.remove();
    var ver = getCurrentInstalledVersion();
    var nat = getNativeApkVersion();
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaAboutModal" tabindex="-1">' +
      '  <div class="modal-dialog modal-dialog-centered">' +
      '    <div class="modal-content rounded-4 border-0 shadow">' +
      '      <div class="modal-header text-white py-2" style="background:linear-gradient(135deg,#003b5c,#005b8f);">' +
      '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-info-circle-fill me-1"></i> Tentang Aplikasi PFA</h6>' +
      '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
      '      </div>' +
      '      <div class="modal-body small">' +
      '        <div class="text-center mb-3">' +
      '          <div class="fw-bold fs-6 text-dark">PLN Field Assistant (PFA)</div>' +
      '          <div class="text-muted">' + escText(UNIT_NAME) + '</div>' +
      '          <span class="badge text-bg-primary mt-1">Versi OTA v' + escText(ver) + ' • APK v' + escText(nat) + '</span>' +
      '        </div>' +
      '        <div class="p-2 rounded-3 bg-light border mb-2">' +
      '          <div class="d-flex justify-content-between py-1 border-bottom"><span class="text-muted">Pengembang</span><strong>' + escText(DEV_NAME) + '</strong></div>' +
      '          <div class="d-flex justify-content-between py-1 border-bottom"><span class="text-muted">Unit Kerja</span><strong>' + escText(UNIT_NAME) + '</strong></div>' +
      '          <div class="d-flex justify-content-between py-1"><span class="text-muted">Status Server</span><strong id="pfaPingStatusVal">Belum diuji</strong></div>' +
      '        </div>' +
      '        <div class="d-grid gap-2">' +
      '          <button type="button" class="btn btn-outline-primary btn-sm fw-semibold" id="btnPfaPingTest"><i class="bi bi-speedometer2 me-1"></i> Tes Kecepatan Server (Ping)</button>' +
      '          <div class="d-flex gap-2">' +
      '            <button type="button" class="btn btn-light border btn-sm flex-grow-1" id="btnAboutCheckUpd"><i class="bi bi-cloud-arrow-down me-1"></i> Cek Update</button>' +
      '            <button type="button" class="btn btn-light border btn-sm flex-grow-1" id="btnAboutFeedback"><i class="bi bi-chat-dots me-1"></i> Lapor Kendala</button>' +
      '          </div>' +
      '        </div>' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var modalEl = document.getElementById('pfaAboutModal');
    var inst = bootstrap.Modal.getOrCreateInstance(modalEl);
    modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); }, { once: true });

    document.getElementById('btnPfaPingTest').onclick = function () {
      var stEl = document.getElementById('pfaPingStatusVal');
      if (stEl) stEl.textContent = 'Mengukur...';
      var t0 = Date.now();
      postToGas(getApiUrl(), { action: 'ping' }).then(function () {
        var ms = Date.now() - t0;
        var label = ms < 1200 ? (ms + ' ms (Lancar)') : (ms + ' ms (Lambat — disarankan Mode Sinyal Lemah)');
        if (stEl) {
          stEl.textContent = label;
          stEl.className = ms < 1200 ? 'text-success fw-bold' : 'text-warning fw-bold';
        }
      }).catch(function () {
        if (stEl) { stEl.textContent = 'Gagal terhubung'; stEl.className = 'text-danger fw-bold'; }
      });
    };
    document.getElementById('btnAboutCheckUpd').onclick = function () { inst.hide(); window.checkPfaUpdate(); };
    document.getElementById('btnAboutFeedback').onclick = function () { inst.hide(); window.openPfaFeedbackModal(); };
    inst.show();
  };

  function injectEnhancedMenuItems() {
    var menu = document.querySelector('#appScreen .topbar-pln .dropdown-menu');
    if (!menu || document.getElementById('pfaMenuCheckUpdate')) return;
    var ver = getCurrentInstalledVersion();
    var isLarge = document.documentElement.classList.contains('pfa-font-large');

    var itemsHtml = [
      '<li id="pfaMenuCheckUpdate"><button type="button" class="dropdown-item small py-2" onclick="checkPfaUpdate()"><i class="bi bi-cloud-arrow-down-fill me-2 text-primary"></i> Cek Update <span class="badge text-bg-light border ms-1">v' + escText(ver) + '</span></button></li>',
      '<li><button type="button" class="dropdown-item small py-2" onclick="refreshPfaSessionNow()"><i class="bi bi-shield-check me-2 text-success"></i> Segarkan Sesi <span id="pfaSessionRemLabel" class="badge text-bg-light border ms-1">-</span></button></li>',
      '<li><button type="button" class="dropdown-item small py-2" onclick="togglePfaFontScale()"><i class="bi bi-fonts me-2 text-secondary"></i> Ukuran Teks <span id="pfaFontScaleBadge" class="badge text-bg-light border ms-1">' + (isLarge ? 'Besar' : 'Normal') + '</span></button></li>',
      '<li><button type="button" class="dropdown-item small py-2" onclick="openPfaFeedbackModal()"><i class="bi bi-chat-square-heart me-2 text-danger"></i> Lapor Kendala / Saran</button></li>',
      '<li><button type="button" class="dropdown-item small py-2" onclick="openPfaAboutModal()"><i class="bi bi-info-circle me-2 text-info"></i> Tentang Aplikasi</button></li>'
    ].join('');

    var temp = document.createElement('ul');
    temp.innerHTML = itemsHtml;
    var divider = menu.querySelector('.dropdown-divider');
    var refNode = (divider && divider.parentNode) ? divider.parentNode : null;
    while (temp.firstChild) {
      if (refNode) menu.insertBefore(temp.firstChild, refNode);
      else menu.appendChild(temp.firstChild);
    }
    updateMenuNotificationDot();
  }

  // --- [Fitur] Popup "Apa yang Baru?" (Changelog) Otomatis Pasca Update OTA ---
  function showPostUpdateChangelogIfNeeded() {
    var ver = getCurrentInstalledVersion();
    var notes = CHANGELOG_NOTES[ver];
    if (!notes || !notes.length) return;
    try {
      if (localStorage.getItem(LAST_SEEN_CHANGELOG_KEY) === ver) return;
      localStorage.setItem(LAST_SEEN_CHANGELOG_KEY, ver);
    } catch (e) { return; }

    var old = document.getElementById('pfaChangelogModal');
    if (old) old.remove();
    var listHtml = notes.map(function (n) { return '<li class="mb-1">' + escText(n) + '</li>'; }).join('');
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaChangelogModal" tabindex="-1">' +
      '  <div class="modal-dialog modal-dialog-centered">' +
      '    <div class="modal-content rounded-4 border-0 shadow">' +
      '      <div class="modal-header text-white py-2" style="background:linear-gradient(135deg,#003b5c,#005b8f);">' +
      '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-stars me-1"></i> Apa yang Baru di PFA v' + escText(ver) + '</h6>' +
      '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
      '      </div>' +
      '      <div class="modal-body small">' +
      '        <ul class="ps-3 mb-2">' + listHtml + '</ul>' +
      '        <div class="text-muted text-end" style="font-size:0.74rem;">Pengembang: <strong>' + escText(DEV_NAME) + '</strong> • ' + escText(UNIT_NAME) + '</div>' +
      '      </div>' +
      '      <div class="modal-footer py-2">' +
      '        <button type="button" class="btn btn-primary btn-sm fw-semibold w-100" data-bs-dismiss="modal">Siap, Mulai Bekerja</button>' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var modalEl = document.getElementById('pfaChangelogModal');
    var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
    modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); }, { once: true });
    if (inst) inst.show();
  }

  // --- IndexedDB Helper untuk Antrean Offline ---
  function openOfflineDb() {
    return new Promise(function (resolve, reject) {
      if (!window.indexedDB) { reject(new Error('IndexedDB tidak didukung.')); return; }
      var req = window.indexedDB.open(OFFLINE_DB_NAME, 1);
      req.onupgradeneeded = function (ev) {
        var db = ev.target.result;
        if (!db.objectStoreNames.contains(OFFLINE_STORE)) {
          db.createObjectStore(OFFLINE_STORE, { keyPath: 'id', autoIncrement: true });
        }
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error('Gagal membuka database offline.')); };
    });
  }

  function enqueueOfflineAction(payload) {
    return openOfflineDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(OFFLINE_STORE, 'readwrite');
        var req = tx.objectStore(OFFLINE_STORE).add({
          createdAt: new Date().toISOString(),
          action: payload.action,
          payload: payload
        });
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
      });
    }).then(function (id) { refreshOfflineQueueBanner(); return id; });
  }

  function listOfflineQueue() {
    return openOfflineDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(OFFLINE_STORE, 'readonly');
        var req = tx.objectStore(OFFLINE_STORE).getAll();
        req.onsuccess = function () { resolve(req.result || []); };
        req.onerror = function () { reject(req.error); };
      });
    }).catch(function () { return []; });
  }

  function removeOfflineItem(id) {
    return openOfflineDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(OFFLINE_STORE, 'readwrite');
        var req = tx.objectStore(OFFLINE_STORE).delete(id);
        req.onsuccess = function () { resolve(); };
        req.onerror = function () { reject(req.error); };
      });
    });
  }

  function clearOfflineQueueAll() {
    return openOfflineDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(OFFLINE_STORE, 'readwrite');
        var req = tx.objectStore(OFFLINE_STORE).clear();
        req.onsuccess = function () { resolve(); };
        req.onerror = function () { reject(req.error); };
      });
    }).then(function () { refreshOfflineQueueBanner(); });
  }

  // --- Pengirim HTTP ke GAS doPost(e) ---
  function postToGas(url, payload) {
    var bodyStr = JSON.stringify(payload || {});
    var capHttp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp;

    var reqPromise = (capHttp && typeof capHttp.post === 'function')
      ? capHttp.post({
          url: url,
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          data: bodyStr,
          connectTimeout: (window.PFA_CONFIG && window.PFA_CONFIG.REQUEST_TIMEOUT_MS) || 60000,
          readTimeout: (window.PFA_CONFIG && window.PFA_CONFIG.REQUEST_TIMEOUT_MS) || 60000
        }).then(function (res) {
          var data = res && res.data;
          if (typeof data === 'string') {
            try { data = JSON.parse(data); } catch (e) {
              throw new Error('Respons server bukan JSON valid. Pastikan Deployment GAS disetel ke "Anyone".');
            }
          }
          return data;
        })
      : fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: bodyStr,
          redirect: 'follow'
        }).then(function (res) {
          return res.text().then(function (txt) {
            try { return JSON.parse(txt); } catch (e) {
              throw new Error('Respons server GAS tidak valid (HTTP ' + res.status + ').');
            }
          });
        });

    return reqPromise.then(function (res) {
      if (payload && payload.action === 'login' && res && res.status === 'success' && res.sessionToken) {
        LAST_SESSION_TOKEN = String(res.sessionToken).trim();
        setTimeout(function () {
          injectPortalGreeting();
          injectEnhancedMenuItems();
          updateMenuNotificationDot();
        }, 250);
      }
      if (res && res.code === 'SESSION_EXPIRED') {
        LAST_SESSION_TOKEN = '';
        if (typeof window.showToast === 'function') {
          window.showToast('Sesi login telah berakhir. Silakan login kembali.', 'warning');
        }
        if (typeof window.logoutApp === 'function') {
          setTimeout(function () { window.logoutApp(); }, 700);
        }
      }
      return res;
    });
  }

  // --- [Fitur] Banner Tombol "Coba Lagi" Saat Gagal Memuat Data ---
  function showRetryDataBar(msg, retryFn) {
    LAST_FAILED_RETRY_FN = retryFn;
    var container = document.querySelector('#appScreen .container');
    if (!container) return;
    var bar = document.getElementById('pfaRetryDataBar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'pfaRetryDataBar';
      bar.className = 'alert alert-warning d-flex justify-content-between align-items-center gap-2 py-2 px-3 rounded-3 mb-2 small';
      container.insertBefore(bar, container.firstChild);
    }
    bar.innerHTML =
      '<span><i class="bi bi-wifi-off me-1"></i> ' + escText(msg || 'Gagal memuat data.') + '</span>' +
      '<div class="d-flex gap-1">' +
      '  <button type="button" class="btn btn-dark btn-sm py-0 px-2" id="btnPfaRetryNow">Coba Lagi</button>' +
      '  <button type="button" class="btn btn-outline-dark btn-sm py-0 px-1" id="btnPfaRetryDismiss">×</button>' +
      '</div>';
    document.getElementById('btnPfaRetryNow').onclick = function () {
      bar.remove();
      if (typeof LAST_FAILED_RETRY_FN === 'function') LAST_FAILED_RETRY_FN();
    };
    document.getElementById('btnPfaRetryDismiss').onclick = function () { bar.remove(); };
  }

  // --- Override callApi(payload) + Double-Submit Guard + Review Before Submit ---
  var originalCallApi = typeof window.callApi === 'function' ? window.callApi : null;

  function clearDirtyForAction(action) {
    if (action === 'simpan_gangguan') markTabDirty('gangguan', false);
    else if (action === 'simpan_pengukuran') markTabDirty('pengukuran', false);
    else if (action === 'simpan_p2tl') markTabDirty('p2tl', false);
  }

  window.callApi = function (payload) {
    if (typeof google !== 'undefined' && google.script && google.script.run && originalCallApi) {
      return originalCallApi(payload);
    }

    var reqPayload = Object.assign({}, payload || {});
    var act = String(reqPayload.action || '');

    // Anti-Klik Ganda (Double-Submit Guard) pada aksi simpan & cari
    var guardable = QUEUEABLE_ACTIONS.indexOf(act) !== -1 || act === 'cari_pelanggan' || act === 'cek_kct';
    if (guardable && IN_FLIGHT_KEYS[act]) {
      return Promise.reject(new Error('Permintaan sebelumnya masih diproses, mohon tunggu sebentar.'));
    }

    if (!reqPayload.sessionToken) {
      var tok = getActiveSessionToken();
      if (tok) reqPayload.sessionToken = tok;
    }

    var apiUrl = getApiUrl();
    if (!isApiUrlConfigured(apiUrl)) {
      return Promise.reject(new Error('URL API GAS belum diisi. Atur GAS_API_URL pada file www/pfa-config.js terlebih dahulu.'));
    }

    var isQueueable = QUEUEABLE_ACTIONS.indexOf(act) !== -1;

    if (act === 'get_master_kerusakan') {
      return postToGas(apiUrl, reqPayload).then(function (res) {
        if (res && res.status === 'success' && Array.isArray(res.data) && res.data.length) {
          try { localStorage.setItem('pfa_cache_master_kerusakan', JSON.stringify(res.data)); } catch (e) {}
        }
        return res;
      }).catch(function (err) {
        try {
          var cached = JSON.parse(localStorage.getItem('pfa_cache_master_kerusakan') || '[]');
          if (Array.isArray(cached) && cached.length) return { status: 'success', data: cached, fromCache: true };
        } catch (e) {}
        throw err;
      });
    }

    if (guardable) IN_FLIGHT_KEYS[act] = true;

    function releaseGuard() {
      if (guardable) delete IN_FLIGHT_KEYS[act];
    }

    if (isQueueable && !reqPayload.allowDuplicate && !reqPayload._skipReview) {
      return compressPayloadPhotos(reqPayload).then(function (compressedPayload) {
        return showReviewBeforeSubmitModal(compressedPayload).then(function (confirmed) {
          if (!confirmed) {
            releaseGuard();
            return { status: 'error', message: 'Pengiriman dibatalkan untuk dicek kembali.' };
          }
          if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengirim laporan ke server...');
          return executeQueueableRequest(apiUrl, compressedPayload).finally(releaseGuard);
        });
      }).catch(function (err) {
        releaseGuard();
        throw err;
      });
    }

    var prepPromise = isQueueable ? compressPayloadPhotos(reqPayload) : Promise.resolve(reqPayload);
    return prepPromise.then(function (finalPayload) {
      if (isQueueable) return executeQueueableRequest(apiUrl, finalPayload);
      return postToGas(apiUrl, finalPayload).catch(function (err) {
        if (act === 'cari_pelanggan' || act === 'cek_kct' || act === 'get_histori_petugas') {
          showRetryDataBar('Gagal memuat data (' + act + ').', function () {
            if (act === 'cari_pelanggan' && typeof window.cariPelanggan === 'function') window.cariPelanggan();
            else if (act === 'cek_kct' && typeof window.cariKct === 'function') window.cariKct();
            else if (act === 'get_histori_petugas' && typeof window.loadHistoriSaya === 'function') window.loadHistoriSaya();
          });
        }
        throw err;
      });
    }).finally(releaseGuard);
  };

  function executeQueueableRequest(apiUrl, finalPayload) {
    if (navigator.onLine === false) {
      return enqueueOfflineAction(finalPayload).then(function () {
        clearDirtyForAction(finalPayload.action);
        triggerHaptic([40, 40, 40]);
        schedulePhotoSizeUpdate();
        return {
          status: 'success',
          offlineQueued: true,
          message: 'Sinyal terputus. Data & foto terkompresi diamankan ke Antrean Offline perangkat.'
        };
      });
    }

    return postToGas(apiUrl, finalPayload).then(function (res) {
      if (res && res.status === 'success') {
        clearDirtyForAction(finalPayload.action);
        triggerHaptic(60);
        schedulePhotoSizeUpdate();
      }
      return res;
    }).catch(function (err) {
      var msg = err && err.message ? err.message : String(err);
      var isNetworkErr = /network|failed to fetch|timeout|offline|unable to resolve host|socket/i.test(msg) || navigator.onLine === false;
      if (isNetworkErr) {
        return enqueueOfflineAction(finalPayload).then(function () {
          clearDirtyForAction(finalPayload.action);
          triggerHaptic([40, 40, 40]);
          schedulePhotoSizeUpdate();
          return {
            status: 'success',
            offlineQueued: true,
            message: 'Koneksi tidak stabil. Laporan diamankan ke Antrean Offline dan siap dikirim ulang saat sinyal membaik.'
          };
        });
      }
      throw err;
    });
  }

  // --- Update Otomatis OTA + Aturan minNativeVersion ---
  function compareSemver(a, b) {
    var pa = String(a || '0').split('.').map(function (n) { return parseInt(n, 10) || 0; });
    var pb = String(b || '0').split('.').map(function (n) { return parseInt(n, 10) || 0; });
    for (var i = 0; i < 3; i++) {
      if ((pa[i] || 0) > (pb[i] || 0)) return 1;
      if ((pa[i] || 0) < (pb[i] || 0)) return -1;
    }
    return 0;
  }

  function getNativeApkVersion() {
    try {
      var savedNative = localStorage.getItem('pfa_native_apk_version');
      if (savedNative) return savedNative;
    } catch (e) {}
    return '2.0.0';
  }

  function getCurrentInstalledVersion() {
    var baseVer = (window.PFA_CONFIG && window.PFA_CONFIG.APP_VERSION) || '2.0.4';
    try {
      var otaVer = String(localStorage.getItem('pfa_ota_version') || '').trim();
      if (otaVer && compareSemver(otaVer, baseVer) > 0) return otaVer;
    } catch (e) {}
    return baseVer;
  }

  function runOtaInAppUpdate(otaUrl, targetVer) {
    var updater = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater;
    if (!updater || typeof updater.download !== 'function') {
      if (typeof window.showToast === 'function') window.showToast('Plugin OTA belum aktif di perangkat ini.', 'warning');
      return;
    }
    if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengunduh update PFA v' + targetVer + '...');
    updater.download({ url: otaUrl, version: targetVer })
      .then(function (bundle) {
        if (!bundle || !bundle.id) throw new Error('Paket update tidak valid.');
        try { localStorage.setItem('pfa_ota_version', targetVer); } catch (e) {}
        if (typeof window.setLoading === 'function') window.setLoading(true, 'Menerapkan pembaruan & memuat ulang...');
        return updater.set({ id: bundle.id });
      })
      .catch(function (err) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (typeof window.showToast === 'function') {
          window.showToast('Gagal update otomatis: ' + ((err && err.message) || err), 'danger');
        }
      });
  }

  function checkAppUpdateOnLaunch(manualTrigger) {
    if (navigator.onLine === false) {
      if (manualTrigger && typeof window.showToast === 'function') window.showToast('Tidak ada koneksi internet untuk cek update.', 'warning');
      return;
    }
    var apiUrl = getApiUrl();
    if (!isApiUrlConfigured(apiUrl)) return;
    var currentVer = getCurrentInstalledVersion();
    var nativeVer = getNativeApkVersion();

    if (manualTrigger && typeof window.setLoading === 'function') {
      window.setLoading(true, 'Memeriksa pembaruan PFA...');
    }

    postToGas(apiUrl, { action: 'check_app_update' }).then(function (res) {
      if (manualTrigger && typeof window.setLoading === 'function') window.setLoading(false);
      if (!res || res.status !== 'success' || !res.latestVersion) return;

      var mustUpdateApk = Boolean(res.minNativeVersion && compareSemver(res.minNativeVersion, nativeVer) > 0 && res.downloadUrl);
      var hasOta = Boolean(!mustUpdateApk && res.otaBundleUrl && isCapacitorNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater);
      var hasApk = Boolean(res.downloadUrl);
      var hasNewer = mustUpdateApk || compareSemver(res.latestVersion, currentVer) > 0;

      HAS_PENDING_UPDATE_BADGE = Boolean(hasNewer && (hasOta || hasApk));
      updateMenuNotificationDot();

      if (!HAS_PENDING_UPDATE_BADGE) {
        if (manualTrigger && typeof window.showToast === 'function') {
          window.showToast('PFA Anda sudah versi terbaru (v' + currentVer + ').', 'success');
        }
        return;
      }

      var old = document.getElementById('pfaUpdateModal');
      if (old) old.remove();
      var actionBtnHtml = hasOta
        ? '<button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnPfaRunOta"><i class="bi bi-lightning-charge-fill me-1"></i> Update Sekarang (Otomatis)</button>'
        : '<a href="' + escText(res.downloadUrl) + '" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm fw-semibold"><i class="bi bi-download me-1"></i> Unduh Update APK</a>';

      var noteHtml = mustUpdateApk
        ? '<div class="alert alert-warning py-1 px-2 mt-2 mb-0" style="font-size:0.75rem;"><i class="bi bi-shield-exclamation me-1"></i>Pembaruan ini membutuhkan instalasi ulang file <strong>APK v' + escText(res.minNativeVersion) + '</strong>.</div>'
        : (hasOta ? '<div class="text-muted mt-2" style="font-size:0.75rem;"><i class="bi bi-info-circle me-1"></i>Aplikasi akan mengunduh pembaruan kecil dan memuat ulang otomatis tanpa instal ulang APK.</div>' : '');

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="pfaUpdateModal" tabindex="-1">' +
        '  <div class="modal-dialog modal-dialog-centered">' +
        '    <div class="modal-content rounded-4 border-0 shadow">' +
        '      <div class="modal-header bg-primary text-white py-2">' +
        '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-cloud-download-fill me-1"></i> Update PFA v' + escText(res.latestVersion) + ' Tersedia</h6>' +
        '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
        '      </div>' +
        '      <div class="modal-body small">' +
        '        <p class="mb-2">Versi terpasang: <strong>v' + escText(currentVer) + '</strong> → Terbaru: <strong class="text-primary">v' + escText(res.latestVersion) + '</strong></p>' +
        '        <div class="p-2 rounded-3 bg-light border">' + escText(res.releaseNotes || 'Perbaikan bug dan peningkatan performa.') + '</div>' +
                 noteHtml +
        '      </div>' +
        '      <div class="modal-footer py-2">' +
        '        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Nanti Saja</button>' +
                 actionBtnHtml +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>';
      document.body.appendChild(wrap.firstChild);
      var modalEl = document.getElementById('pfaUpdateModal');
      var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
      var otaBtn = document.getElementById('btnPfaRunOta');
      if (otaBtn) {
        otaBtn.onclick = function () {
          if (inst) inst.hide();
          runOtaInAppUpdate(res.otaBundleUrl, res.latestVersion);
        };
      }
      if (inst) inst.show();
    }).catch(function () {
      if (manualTrigger && typeof window.setLoading === 'function') window.setLoading(false);
      if (manualTrigger && typeof window.showToast === 'function') window.showToast('Gagal memeriksa pembaruan. Periksa sinyal Anda.', 'warning');
    });
  }

  window.checkPfaUpdate = function () { checkAppUpdateOnLaunch(true); };

  // --- Banner & Sinkronisasi Antrean Offline ---
  function ensureOfflineBanner() {
    var existing = document.getElementById('pfaOfflineQueueBanner');
    if (existing) return existing;
    var container = document.querySelector('#appScreen .container');
    if (!container) return null;

    var banner = document.createElement('div');
    banner.id = 'pfaOfflineQueueBanner';
    banner.className = 'alert alert-info border-info d-none justify-content-between align-items-center flex-wrap gap-2 py-2 px-3 rounded-3 mb-3';
    banner.innerHTML =
      '<div class="small">' +
      '  <i class="bi bi-cloud-arrow-up-fill me-1 fw-bold"></i>' +
      '  Ada <strong id="pfaOfflineCount">0</strong> laporan di <strong>Antrean Offline</strong> siap dikirim.' +
      '</div>' +
      '<div class="d-flex gap-2">' +
      '  <button type="button" class="btn btn-sm btn-primary fw-semibold" id="btnSyncOfflineQueue"><i class="bi bi-arrow-repeat me-1"></i> Kirim Sekarang</button>' +
      '  <button type="button" class="btn btn-sm btn-outline-danger" id="btnClearOfflineQueue" title="Hapus antrean">Hapus</button>' +
      '</div>';

    var weakBar = document.getElementById('pfaWeakSignalBar');
    if (weakBar && weakBar.nextSibling) container.insertBefore(banner, weakBar.nextSibling);
    else container.insertBefore(banner, container.firstChild);

    banner.querySelector('#btnSyncOfflineQueue').addEventListener('click', syncOfflineQueueNow);
    banner.querySelector('#btnClearOfflineQueue').addEventListener('click', function () {
      if (confirm('Hapus semua laporan di Antrean Offline perangkat ini?')) {
        clearOfflineQueueAll().then(function () {
          if (typeof window.showToast === 'function') window.showToast('Antrean offline dibersihkan.', 'secondary');
        });
      }
    });
    return banner;
  }

  function refreshOfflineQueueBanner() {
    listOfflineQueue().then(function (items) {
      var banner = ensureOfflineBanner();
      if (!banner) return;
      var countEl = document.getElementById('pfaOfflineCount');
      if (countEl) countEl.textContent = String(items.length);
      banner.classList.toggle('d-none', items.length === 0);
      banner.classList.toggle('d-flex', items.length > 0);
    });
  }

  function askDuplicateResolutionModal(dupObj, offlineData) {
    return new Promise(function (resolve) {
      var oldModal = document.getElementById('pfaOfflineDupModal');
      if (oldModal) oldModal.remove();
      var latest = (dupObj && dupObj.latest) || {};
      var d = offlineData || {};
      var driveBtn = latest.link_folder
        ? '<a href="' + escText(latest.link_folder) + '" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary mt-2 w-100"><i class="bi bi-folder2-open me-1"></i> Lihat Foto Laporan Sebelumnya (Drive)</a>'
        : '';

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="pfaOfflineDupModal" tabindex="-1" data-bs-backdrop="static">' +
        '  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
        '    <div class="modal-content rounded-4 border-0 shadow">' +
        '      <div class="modal-header bg-warning text-dark py-2">' +
        '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-exclamation-triangle-fill me-1"></i> Data IDPEL ' + escText(d.id_pelanggan || latest.idpel || '-') + ' Sudah Ada</h6>' +
        '        <button type="button" class="btn-close" id="btnDupCloseX" aria-label="Tutup"></button>' +
        '      </div>' +
        '      <div class="modal-body small">' +
        '        <p class="mb-2">IDPEL ini tercatat sudah masuk <strong>' + escText(dupObj && dupObj.count ? dupObj.count : 1) + ' kali</strong> di server:</p>' +
        '        <div class="p-2 rounded-3 bg-light border mb-2">' +
        '          <div class="fw-bold text-primary mb-1">1. Data Sebelumnya di Server</div>' +
        '          <div>• Waktu: <strong>' + escText(latest.timestamp || '-') + '</strong></div>' +
        '          <div>• No. Form DG: <strong>' + escText(latest.no_form_dg || '-') + '</strong></div>' +
        '          <div>• Status TL: <strong>' + escText(latest.status_tl || '-') + '</strong></div>' +
        '          <div>• Meter Baru: <strong>' + escText(latest.no_meter_baru || '-') + '</strong></div>' +
        '          <div>• Sebab: <strong>' + escText(latest.sebab_kerusakan || '-') + '</strong></div>' +
        '          <div>• Petugas: <strong>' + escText(latest.petugas || '-') + '</strong></div>' +
                   driveBtn +
        '        </div>' +
        '        <div class="p-2 rounded-3 bg-info bg-opacity-10 border border-info">' +
        '          <div class="fw-bold text-dark mb-1">2. Data Offline yang Akan Dikirim</div>' +
        '          <div>• No. Form DG: <strong>' + escText(d.no_form_dg || '-') + '</strong></div>' +
        '          <div>• Status TL: <strong>' + escText(d.status_tindak_lanjut || '-') + '</strong></div>' +
        '          <div>• Meter Baru: <strong>' + escText(d.no_meter_baru || '-') + '</strong></div>' +
        '          <div>• Sebab: <strong>' + escText(d.sebab_kerusakan || '-') + '</strong></div>' +
        '          <div>• Petugas: <strong>' + escText(d.petugas || '-') + '</strong></div>' +
        '        </div>' +
        '      </div>' +
        '      <div class="modal-footer flex-column align-items-stretch gap-2 pt-1">' +
        '        <button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnDupSendForce">Tetap Kirim (Ini Data Berbeda)</button>' +
        '        <button type="button" class="btn btn-outline-danger btn-sm fw-semibold" id="btnDupDiscard">Hapus dari Antrean (Data Sama / Sudah Masuk)</button>' +
        '        <button type="button" class="btn btn-light btn-sm" id="btnDupLater">Tunda / Batal</button>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>';

      document.body.appendChild(wrap.firstChild);
      var modalEl = document.getElementById('pfaOfflineDupModal');
      var inst = bootstrap.Modal.getOrCreateInstance(modalEl);
      function finish(choice) {
        inst.hide();
        modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); resolve(choice); }, { once: true });
      }
      document.getElementById('btnDupSendForce').onclick = function () { finish('send'); };
      document.getElementById('btnDupDiscard').onclick = function () { finish('discard'); };
      document.getElementById('btnDupLater').onclick = function () { finish('cancel'); };
      document.getElementById('btnDupCloseX').onclick = function () { finish('cancel'); };
      if (typeof window.setLoading === 'function') window.setLoading(false);
      inst.show();
    });
  }

  var isSyncingQueue = false;
  function syncOfflineQueueNow() {
    if (isSyncingQueue) return;
    if (navigator.onLine === false) {
      if (typeof window.showToast === 'function') window.showToast('Perangkat masih offline. Tunggu sinyal kembali.', 'warning');
      return;
    }
    var apiUrl = getApiUrl();
    if (!isApiUrlConfigured(apiUrl)) return;

    isSyncingQueue = true;
    listOfflineQueue().then(function (items) {
      if (!items.length) { isSyncingQueue = false; refreshOfflineQueueBanner(); return; }
      if (typeof window.setLoading === 'function') window.setLoading(true, 'Menyinkronkan ' + items.length + ' laporan offline...');

      var synced = 0, failed = 0, lastErrMsg = '';
      var chain = Promise.resolve();

      items.forEach(function (entry) {
        chain = chain.then(function () {
          var payload = Object.assign({}, entry.payload || {});
          var tok = getActiveSessionToken();
          if (tok) payload.sessionToken = tok;

          return postToGas(apiUrl, payload).then(function (res) {
            if (res && res.status === 'success') { synced++; return removeOfflineItem(entry.id); }
            if (res && res.status === 'duplicate' && payload.action === 'simpan_gangguan') {
              return askDuplicateResolutionModal(res.duplicate, payload.data).then(function (choice) {
                if (choice === 'send') {
                  if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengirim laporan offline...');
                  payload.allowDuplicate = true;
                  return postToGas(apiUrl, payload).then(function (res2) {
                    if (res2 && res2.status === 'success') { synced++; return removeOfflineItem(entry.id); }
                    failed++; lastErrMsg = (res2 && res2.message) || 'Gagal simpan ulang.';
                  });
                }
                if (choice === 'discard') { synced++; return removeOfflineItem(entry.id); }
                failed++; lastErrMsg = 'Sinkronisasi ditunda oleh petugas.';
              });
            }
            failed++; lastErrMsg = (res && res.message) || ('Status server: ' + (res && res.status ? res.status : 'tidak diketahui'));
          }).catch(function (err) {
            failed++; lastErrMsg = (err && err.message) ? err.message : String(err);
          });
        });
      });

      return chain.finally(function () {
        isSyncingQueue = false;
        if (typeof window.setLoading === 'function') window.setLoading(false);
        refreshOfflineQueueBanner();
        if (typeof window.showToast === 'function') {
          if (synced > 0 && failed === 0) {
            triggerHaptic(60);
            window.showToast(synced + ' laporan offline selesai diproses!', 'success');
          } else if (synced > 0 && failed > 0) {
            window.showToast(synced + ' selesai, ' + failed + ' belum terkirim: ' + lastErrMsg, 'warning');
          } else {
            window.showToast('Sinkronisasi gagal: ' + (lastErrMsg || 'Periksa koneksi internet Anda.'), 'danger');
          }
        }
      });
    });
  }

  window.syncPfaOfflineQueue = syncOfflineQueueNow;

  // --- Scanner Google ML Kit + Fallback Html5Qrcode (Getar + Bip + Senter) ---
  function applyScannedBarcode(targetId, rawCode) {
    var cleanCode = String(rawCode || '').trim();
    if (!cleanCode) return;
    triggerHaptic(45);
    playBarcodeBeep();
    var inp = targetId ? document.getElementById(targetId) : null;
    if (inp) {
      inp.value = cleanCode;
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (typeof window.showToast === 'function') window.showToast('Barcode terbaca: ' + cleanCode, 'success');
  }

  var nativeModalQr = null;
  var originalOpenBarcode = typeof window.openBarcodeScanner === 'function' ? window.openBarcodeScanner : null;

  function openHtml5QrcodeFallback(targetId) {
    var modalEl = document.getElementById('barcodeScannerModal');
    if (!modalEl || typeof bootstrap === 'undefined') {
      if (originalOpenBarcode) return originalOpenBarcode(targetId);
      return;
    }

    var statusEl = document.getElementById('qrScanStatus');
    if (statusEl) { statusEl.textContent = 'Mengaktifkan kamera belakang...'; statusEl.classList.remove('d-none'); }

    var torchOn = false;
    var torchBtn = document.getElementById('pfaBtnTorchModal');
    if (!torchBtn) {
      var bodyEl = modalEl.querySelector('.modal-body');
      if (bodyEl) {
        var wrapBtn = document.createElement('div');
        wrapBtn.className = 'd-flex justify-content-center mb-2';
        wrapBtn.innerHTML = '<button type="button" id="pfaBtnTorchModal" class="btn btn-sm btn-warning fw-semibold d-none"><i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter</button>';
        bodyEl.insertBefore(wrapBtn, bodyEl.firstChild);
        torchBtn = document.getElementById('pfaBtnTorchModal');
      }
    }
    if (torchBtn) {
      torchBtn.className = 'btn btn-sm btn-warning fw-semibold d-none';
      torchBtn.innerHTML = '<i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter';
      torchBtn.onclick = function () {
        if (!nativeModalQr) return;
        torchOn = !torchOn;
        nativeModalQr.applyVideoConstraints({ advanced: [{ torch: torchOn }] })
          .then(function () {
            torchBtn.className = 'btn btn-sm fw-semibold ' + (torchOn ? 'btn-dark' : 'btn-warning');
            torchBtn.innerHTML = torchOn
              ? '<i class="bi bi-lightbulb-off-fill me-1"></i> Matikan Senter'
              : '<i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter';
          })
          .catch(function () {
            torchOn = false;
            if (typeof window.showToast === 'function') window.showToast('Senter tidak didukung kamera pada mode ini.', 'warning');
          });
      };
    }

    var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    modal.show();

    function stopInlineScanner() {
      if (!nativeModalQr) return Promise.resolve();
      var ref = nativeModalQr;
      nativeModalQr = null;
      return ref.stop().catch(function () {}).then(function () { try { ref.clear(); } catch (e) {} });
    }

    modalEl.addEventListener('hidden.bs.modal', function onHide() {
      modalEl.removeEventListener('hidden.bs.modal', onHide);
      torchOn = false;
      stopInlineScanner();
    });

    setTimeout(function () {
      if (typeof Html5Qrcode === 'undefined') {
        if (statusEl) statusEl.textContent = 'Library scanner belum termuat. Gunakan opsi Scan dari Foto di bawah.';
        return;
      }
      stopInlineScanner().then(function () {
        var formats = (typeof Html5QrcodeSupportedFormats !== 'undefined') ? [
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.ITF,
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.CODABAR,
          Html5QrcodeSupportedFormats.QR_CODE
        ] : undefined;

        nativeModalQr = new Html5Qrcode('qrReaderBox', {
          formatsToSupport: formats,
          experimentalFeatures: { useBarCodeDetectorIfSupported: true },
          verbose: false
        });

        var done = false;
        nativeModalQr.start(
          { facingMode: 'environment' },
          {
            fps: 20,
            qrbox: function (viewW, viewH) {
              return { width: Math.min(320, Math.floor(viewW * 0.88)), height: Math.min(140, Math.floor(viewH * 0.38)) };
            },
            videoConstraints: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
          },
          function (decodedText) {
            if (done) return;
            done = true;
            stopInlineScanner().finally(function () { modal.hide(); applyScannedBarcode(targetId, decodedText); });
          },
          function () {}
        ).then(function () {
          if (statusEl) statusEl.textContent = 'Arahkan garis barcode / QR meter sejajar kotak...';
          if (torchBtn) torchBtn.classList.remove('d-none');
        }).catch(function (err) {
          if (statusEl) statusEl.textContent = 'Kamera belum diizinkan (' + ((err && err.message) || err) + '). Gunakan Scan dari Foto di bawah.';
        });
      });
    }, 250);
  }

  window.openBarcodeScanner = function (targetInputId) {
    if (typeof google !== 'undefined' && google.script && google.script.run && originalOpenBarcode) {
      return originalOpenBarcode(targetInputId);
    }
    var targetId = targetInputId || '';
    var mlkit = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.BarcodeScanner;
    if (isCapacitorNative() && mlkit && typeof mlkit.scan === 'function') {
      var checkMod = (typeof mlkit.isGoogleBarcodeScannerModuleAvailable === 'function')
        ? mlkit.isGoogleBarcodeScannerModuleAvailable()
        : Promise.resolve({ available: true });

      checkMod.then(function (modRes) {
        if (modRes && modRes.available === false) {
          if (typeof mlkit.installGoogleBarcodeScannerModule === 'function') mlkit.installGoogleBarcodeScannerModule().catch(function () {});
          if (typeof window.showToast === 'function') window.showToast('Menyiapkan modul scanner Google di latar belakang...', 'info');
          openHtml5QrcodeFallback(targetId);
          return null;
        }
        return mlkit.scan();
      }).then(function (result) {
        if (!result) return;
        var list = (result && result.barcodes) || [];
        if (list.length > 0 && (list[0].rawValue || list[0].displayValue)) {
          applyScannedBarcode(targetId, list[0].rawValue || list[0].displayValue);
        }
      }).catch(function (err) {
        if (/cancel/i.test(String((err && err.message) || err || ''))) return;
        openHtml5QrcodeFallback(targetId);
      });
      return;
    }
    openHtml5QrcodeFallback(targetId);
  };

  // --- Cache & Auto-Reload Sebab Kerusakan ---
  function ensureMasterKerusakanLoaded() {
    var sel = document.getElementById('f_sebab_kerusakan');
    if (!sel || sel.options.length > 1) return;
    try {
      var cached = JSON.parse(localStorage.getItem('pfa_cache_master_kerusakan') || '[]');
      if (Array.isArray(cached) && cached.length) {
        var prevVal = sel.value;
        sel.innerHTML = '<option value="">-- Pilih Sebab Kerusakan --</option>';
        cached.forEach(function (item) {
          var opt = document.createElement('option');
          opt.value = item; opt.textContent = item;
          sel.appendChild(opt);
        });
        if (prevVal) sel.value = prevVal;
      }
    } catch (e) {}
    if (typeof window.loadMasterKerusakan === 'function' && getActiveSessionToken()) window.loadMasterKerusakan();
  }

  // --- Event Delegation Global (1 Listener Ringan untuk Semua Modul — Nol Lag!) ---
  function bindGlobalDelegatedListeners() {
    // 1. Auto-bersih paste IDPEL / No. Meter (hapus spasi & tanda strip '-')
    document.addEventListener('paste', function (ev) {
      var t = ev.target;
      if (!t || t.tagName !== 'INPUT') return;
      var id = t.id || '';
      if (!/(idpel|id_pelanggan|no_meter|cariPelanggan|kctSearch|u_cari|p2tl_cari)/i.test(id)) return;
      var clip = (ev.clipboardData || window.clipboardData);
      if (!clip) return;
      var raw = clip.getData('text');
      if (raw && /[\s-]/.test(raw) && /\d{6,}/.test(raw.replace(/[\s-]/g, ''))) {
        ev.preventDefault();
        t.value = raw.replace(/[\s-]+/g, '').trim();
        t.dispatchEvent(new Event('input', { bubbles: true }));
      }
    });

    // 2. Auto-fokus kolom wajib pertama yang kosong (berlaku di semua <form>)
    document.addEventListener('invalid', function (ev) {
      var el = ev.target;
      if (!el || typeof el.scrollIntoView !== 'function') return;
      var form = el.closest('form');
      if (form && form.querySelector(':invalid') === el) {
        el.classList.add('pfa-field-highlight');
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setTimeout(function () { el.classList.remove('pfa-field-highlight'); }, 2200);
      }
    }, true);

    // 3. Klik global: Tap-to-Zoom foto, Konfirmasi Hapus Foto Tambahan, Undo Reset, & Auto-Tutup Keyboard
    document.addEventListener('click', function (ev) {
      var t = ev.target;
      if (!t) return;

      // Tap-to-Zoom foto preview di semua modul
      var img = t.closest('img.foto-preview, img.rekap-foto-img');
      if (img && img.src && img.src.indexOf('data:image/') === 0 || (img && img.src && img.src.indexOf('http') === 0)) {
        if (!img.classList.contains('d-none')) {
          openPhotoZoomLightbox(img.src);
          return;
        }
      }

      // Konfirmasi hapus foto tambahan (capture sebelum inline onclick menghapus row)
      var delBtn = t.closest('.dg-foto-row button.btn-outline-danger, .ukur-foto-row button.btn-outline-danger, .p2tl-foto-row button.btn-outline-danger');
      if (delBtn && !delBtn.dataset.pfaConfirmed) {
        if (!confirm('Hapus foto dokumentasi ini?')) {
          ev.preventDefault();
          ev.stopImmediatePropagation();
          return;
        }
        schedulePhotoSizeUpdate();
      }

      // Tangkap tombol Reset formulir untuk Undo 5 detik
      var resetBtn = t.closest('button[onclick*="reset"], button[type="reset"]');
      if (resetBtn) {
        var tab = resetBtn.closest('#tab-gangguan, #tab-pengukuran, #tab-p2tl');
        if (tab) {
          var tabName = tab.id.replace('tab-', '');
          var snap = captureFormSnapshot(tab);
          setTimeout(function () {
            markTabDirty(tabName, false);
            schedulePhotoSizeUpdate();
            showUndoResetToast(snap, tabName);
          }, 120);
        }
      }

      // Auto-tutup keyboard saat tekan tombol Cari Data
      if (t.closest('button[onclick*="cariPelanggan"], button[onclick*="cariKct"]')) {
        hideMobileKeyboard();
      }
    }, true);

    // 4. Lacak dirty state & ukuran foto secara event-driven pada 3 tab form
    ['gangguan', 'pengukuran', 'p2tl'].forEach(function (tabName) {
      var el = document.getElementById('tab-' + tabName);
      if (!el || el.dataset.pfaDirtyBound) return;
      el.dataset.pfaDirtyBound = '1';
      el.addEventListener('input', function () {
        markTabDirty(tabName, true);
        schedulePhotoSizeUpdate();
      });
      el.addEventListener('change', function () {
        markTabDirty(tabName, true);
        schedulePhotoSizeUpdate();
      });
    });
  }

  // --- Lifecycle Events ---
  window.addEventListener('online', function () {
    renderWeakSignalBar();
    renderLoginOfflineBanner();
    refreshOfflineQueueBanner();
    listOfflineQueue().then(function (items) {
      if (items.length > 0 && typeof window.showToast === 'function') {
        window.showToast('Sinyal kembali! Ketuk "Kirim Sekarang" untuk menyinkronkan ' + items.length + ' laporan offline.', 'info');
      }
    });
  });

  window.addEventListener('offline', function () {
    renderWeakSignalBar();
    renderLoginOfflineBanner();
  });

  window.addEventListener('load', function () {
    applyFontScalePref();

    if (isCapacitorNative()) {
      document.body.classList.add('pfa-native-apk');
      try {
        if (window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater && typeof window.Capacitor.Plugins.CapacitorUpdater.notifyAppReady === 'function') {
          window.Capacitor.Plugins.CapacitorUpdater.notifyAppReady();
        }
      } catch (eOta) {}
      try {
        if (window.Capacitor.Plugins && window.Capacitor.Plugins.App && typeof window.Capacitor.Plugins.App.getInfo === 'function') {
          window.Capacitor.Plugins.App.getInfo().then(function (info) {
            if (info && info.version) localStorage.setItem('pfa_native_apk_version', String(info.version).trim());
          }).catch(function () {});
        }
      } catch (eInfo) {}
    }

    renderWeakSignalBar();
    renderLoginOfflineBanner();
    refreshOfflineQueueBanner();
    injectPortalGreeting();
    injectAndroidTutorialCard();
    injectEnhancedMenuItems();
    enhanceInputsUniversal();
    wrapSwitchTabWithEnhancements();
    wrapSetLoadingWithSlowCancel();
    bindGlobalDelegatedListeners();
    updateBottomNavDraftDots();

    setTimeout(ensureMasterKerusakanLoaded, 450);
    setTimeout(updateAllPhotoSizeIndicators, 600);
    setTimeout(showPostUpdateChangelogIfNeeded, 900);
    setTimeout(function () { checkAppUpdateOnLaunch(false); }, 1800);

    // Prioritas tombol Back Android (Bebas bentrok: Modal -> Form Guard -> Double-Back Exit)
    if (isCapacitorNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
      window.Capacitor.Plugins.App.addListener('backButton', function (ev) {
        var openModal = document.querySelector('.modal.show');
        if (openModal && typeof bootstrap !== 'undefined') {
          var inst = bootstrap.Modal.getInstance(openModal);
          if (inst) { inst.hide(); return; }
        }
        var portalEl = document.getElementById('tab-portal');
        if (!portalEl && ev && ev.canGoBack) {
          window.history.back();
          return;
        }
        var curTab = getActiveVisibleTabName();
        var appVisible = document.getElementById('appScreen') && !document.getElementById('appScreen').classList.contains('d-none');
        if (appVisible && curTab !== 'portal' && typeof window.switchTab === 'function') {
          window.switchTab('portal');
          return;
        }
        // Double-Back to Exit (dalam 2 detik)
        var now = Date.now();
        if (now - LAST_BACK_TS < 2000) {
          window.Capacitor.Plugins.App.exitApp();
        } else {
          LAST_BACK_TS = now;
          if (typeof window.showToast === 'function') {
            window.showToast('Tekan kembali sekali lagi untuk keluar aplikasi.', 'dark');
          }
        }
      });
    }
  });
})();

/* =====================================================================
 * PFA AI NEON UI ENHANCER (v2.0.5) — Mode Cepat/Pro, Mic Voice-to-Text,
 * Persistent Chat History, Copy/Share WA per Bubble, & Auto-Fill IDPEL
 * ===================================================================== */
(function () {
  'use strict';

  var AI_HISTORY_KEY = 'pfa_ai_neon_history_v1';
  var AI_MODE_KEY = 'pfa_ai_neon_mode_v1';
  var LAST_AI_DETECTED_ID = '';

  function getAiMode() {
    try { return localStorage.getItem(AI_MODE_KEY) || 'auto'; } catch (e) { return 'auto'; }
  }

  function setAiMode(mode) {
    try { localStorage.setItem(AI_MODE_KEY, mode); } catch (e) {}
    var sel = document.getElementById('pfaAiModeSelect');
    if (sel) sel.value = mode;
  }

  function saveAiHistoryLocal(entries) {
    try {
      var trimmed = (entries || []).slice(-20);
      localStorage.setItem(AI_HISTORY_KEY, JSON.stringify(trimmed));
    } catch (e) {}
  }

  function loadAiHistoryLocal() {
    try {
      var raw = localStorage.getItem(AI_HISTORY_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return [];
  }

  function injectAiNeonControls() {
    var tab = document.getElementById('tab-chatbot');
    if (!tab || document.getElementById('pfaAiModeSelect')) return;

    // 1. Tambahkan pemilih Mode AI (Auto / Cepat / Pro) di sebelah tombol Reset
    var resetBtn = tab.querySelector('button[onclick*="resetChatAi"]');
    if (resetBtn && resetBtn.parentElement) {
      var sel = document.createElement('select');
      sel.id = 'pfaAiModeSelect';
      sel.className = 'form-select form-select-sm';
      sel.style.width = 'auto';
      sel.style.fontSize = '0.74rem';
      sel.title = 'Pilih kecepatan/kecerdasan AI';
      sel.innerHTML =
        '<option value="auto">⚡ Auto (Neon)</option>' +
        '<option value="fast">🚀 Cepat</option>' +
        '<option value="pro">🧠 Pro (Detail)</option>';
      sel.value = getAiMode();
      sel.onchange = function () {
        setAiMode(sel.value);
        if (typeof window.showToast === 'function') {
          var lbl = sel.value === 'pro' ? 'Mode Pro aktif (analisa mendalam).' : (sel.value === 'fast' ? 'Mode Cepat aktif (respon ekstra kilat).' : 'Mode Auto Neon aktif.');
          window.showToast(lbl, 'info');
        }
      };
      resetBtn.parentElement.insertBefore(sel, resetBtn);
    }

    // 2. Tambahkan Quick Chip "Rapikan Kronologi BA"
    var chipsBar = tab.querySelector('.d-flex.flex-nowrap.overflow-auto');
    if (chipsBar) {
      var btnBa = document.createElement('button');
      btnBa.type = 'button';
      btnBa.className = 'btn btn-sm btn-outline-success rounded-pill py-0 px-2 flex-shrink-0';
      btnBa.style.fontSize = '0.72rem';
      btnBa.textContent = '📝 Rapikan Kronologi BA';
      btnBa.onclick = function () {
        var inp = document.getElementById('chatAiInput');
        if (inp) {
          inp.value = 'Tolong rapikan catatan lapangan ini menjadi kronologi Berita Acara PLN yang formal: ';
          inp.focus();
        }
      };
      chipsBar.appendChild(btnBa);
    }

    // 3. Tambahkan tombol Mikrofon (Voice-to-Text Bahasa Indonesia) di form chat AI
    var chatInp = document.getElementById('chatAiInput');
    if (chatInp && chatInp.parentElement) {
      var SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRec) {
        var micBtn = document.createElement('button');
        micBtn.type = 'button';
        micBtn.id = 'pfaAiMicBtn';
        micBtn.className = 'btn btn-outline-secondary px-2';
        micBtn.title = 'Tanya dengan Suara (Bahasa Indonesia)';
        micBtn.innerHTML = '<i class="bi bi-mic-fill"></i>';
        var rec = null;
        var listening = false;

        micBtn.onclick = function () {
          if (listening && rec) {
            try { rec.stop(); } catch (e) {}
            return;
          }
          try {
            rec = new SpeechRec();
            rec.lang = 'id-ID';
            rec.interimResults = false;
            rec.maxAlternatives = 1;
            listening = true;
            micBtn.className = 'btn btn-danger px-2';
            micBtn.innerHTML = '<i class="bi bi-stop-circle-fill"></i>';
            if (typeof window.showToast === 'function') window.showToast('Silakan bicara (Bahasa Indonesia)...', 'info');

            rec.onresult = function (ev) {
              var txt = ev.results && ev.results[0] && ev.results[0][0] ? ev.results[0][0].transcript : '';
              if (txt) {
                chatInp.value = (chatInp.value ? chatInp.value + ' ' : '') + txt;
                chatInp.focus();
              }
            };
            rec.onerror = function () {
              if (typeof window.showToast === 'function') window.showToast('Suara tidak terdengar atau izin mikrofon ditolak.', 'warning');
            };
            rec.onend = function () {
              listening = false;
              micBtn.className = 'btn btn-outline-secondary px-2';
              micBtn.innerHTML = '<i class="bi bi-mic-fill"></i>';
            };
            rec.start();
          } catch (e) {
            listening = false;
          }
        };
        chatInp.parentElement.insertBefore(micBtn, chatInp.nextSibling);
      }
    }
  }

  // Tambahkan tombol Salin & Share WA + info kecepatan di gelembung jawaban AI terbaru
  function decorateLatestAiBubble(metaRes) {
    var box = document.getElementById('chatAiBox');
    if (!box) return;
    var bubbles = box.querySelectorAll('.bg-white.border');
    if (!bubbles.length) return;
    var lastBubble = bubbles[bubbles.length - 1];
    if (lastBubble.dataset.pfaNeonDecorated) return;
    lastBubble.dataset.pfaNeonDecorated = '1';

    var rawReply = (metaRes && metaRes.reply) || lastBubble.innerText || '';
    var cleanCopy = rawReply.replace(/\[OPSI:[^\]]+\]/gi, '').trim();

    var footer = document.createElement('div');
    footer.className = 'mt-2 pt-1 border-top d-flex justify-content-between align-items-center flex-wrap gap-1';
    footer.style.fontSize = '0.7rem';

    var metaTags = [];
    if (metaRes && metaRes.latencyMs) metaTags.push('⚡ ' + (metaRes.latencyMs / 1000).toFixed(1) + ' dtk');
    if (metaRes && metaRes.cached) metaTags.push('Instan');
    if (metaRes && Array.isArray(metaRes.contextBadges) && metaRes.contextBadges.length) {
      metaTags.push('Live: ' + metaRes.contextBadges.join('+'));
    }

    var leftSpan = document.createElement('span');
    leftSpan.className = 'text-muted';
    leftSpan.textContent = metaTags.join(' • ') || 'PFA AI Neon';

    var rightWrap = document.createElement('div');
    rightWrap.className = 'd-flex gap-1';

    var btnCopy = document.createElement('button');
    btnCopy.type = 'button';
    btnCopy.className = 'btn btn-light border py-0 px-2';
    btnCopy.style.fontSize = '0.68rem';
    btnCopy.innerHTML = '<i class="bi bi-clipboard me-1"></i>Salin';
    btnCopy.onclick = function () {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(cleanCopy).then(function () {
          if (typeof window.showToast === 'function') window.showToast('Jawaban AI disalin.', 'success');
        });
      }
    };

    var btnWa = document.createElement('a');
    btnWa.href = 'https://wa.me/?text=' + encodeURIComponent(cleanCopy);
    btnWa.target = '_blank';
    btnWa.rel = 'noopener noreferrer';
    btnWa.className = 'btn btn-light border py-0 px-2 text-success text-decoration-none';
    btnWa.style.fontSize = '0.68rem';
    btnWa.innerHTML = '<i class="bi bi-whatsapp me-1"></i>WA';

    rightWrap.appendChild(btnCopy);
    rightWrap.appendChild(btnWa);
    footer.appendChild(leftSpan);
    footer.appendChild(rightWrap);
    lastBubble.appendChild(footer);
  }

  // Intercept callApi untuk menyuntikkan aiMode, simpan riwayat chat lokal, & tangkap detectedId
  function hookCallApiForAiNeon() {
    if (typeof window.callApi !== 'function' || window._pfaAiNeonHooked) return;
    window._pfaAiNeonHooked = true;
    var prevCallApi = window.callApi;

    window.callApi = function (payload) {
      if (payload && payload.action === 'tanya_ai_lapangan') {
        var nextPayload = Object.assign({}, payload, { aiMode: getAiMode() });
        return prevCallApi(nextPayload).then(function (res) {
          if (res && res.status === 'success') {
            if (res.detectedId) LAST_AI_DETECTED_ID = res.detectedId;
            // Simpan ke riwayat lokal
            var saved = loadAiHistoryLocal();
            saved.push({ role: 'user', text: String(payload.prompt || '[Foto OCR]') });
            saved.push({ role: 'model', text: String(res.reply || ''), searchMode: res.searchMode || '' });
            saveAiHistoryLocal(saved);
            setTimeout(function () { decorateLatestAiBubble(res); }, 80);
          }
          return res;
        });
      }
      return prevCallApi(payload);
    };
  }

  // Upgrade handleAiOptionClick_ agar otomatis mengisi IDPEL ke modul tujuan!
  function hookAiOptionNavigation() {
    if (typeof window.handleAiOptionClick_ !== 'function' || window._pfaAiOptHooked) return;
    window._pfaAiOptHooked = true;
    var origOpt = window.handleAiOptionClick_;
    window.handleAiOptionClick_ = function (optText) {
      var low = String(optText || '').toLowerCase();
      origOpt(optText);
      if (!LAST_AI_DETECTED_ID) return;
      setTimeout(function () {
        if (low.indexOf('cek kct') !== -1 && low.indexOf('buka') !== -1) {
          var kInp = document.getElementById('kctSearchInput');
          if (kInp) { kInp.value = LAST_AI_DETECTED_ID; kInp.dispatchEvent(new Event('input', { bubbles: true })); }
        } else if ((low.indexOf('gangguan') !== -1 || low.indexOf('laporan dg') !== -1) && low.indexOf('buka') !== -1) {
          var gInp = document.getElementById('cariPelangganInput');
          if (gInp) { gInp.value = LAST_AI_DETECTED_ID; gInp.dispatchEvent(new Event('input', { bubbles: true })); }
        } else if (low.indexOf('pengukuran') !== -1 && low.indexOf('buka') !== -1) {
          var uInp = document.getElementById('u_cari_pelanggan');
          if (uInp) { uInp.value = LAST_AI_DETECTED_ID; uInp.dispatchEvent(new Event('input', { bubbles: true })); }
        } else if (low.indexOf('p2tl') !== -1 && (low.indexOf('buka') !== -1 || low.indexOf('lanjut ke') !== -1)) {
          var pInp = document.getElementById('p2tl_cari_pelanggan');
          if (pInp) { pInp.value = LAST_AI_DETECTED_ID; pInp.dispatchEvent(new Event('input', { bubbles: true })); }
        }
      }, 220);
    };
  }

  // Pulihkan riwayat chat AI lokal & bersihkan saat Reset Chat
  function restoreAiChatHistoryAndHookReset() {
    var saved = loadAiHistoryLocal();
    if (saved.length > 0 && typeof window.appendChatBubble === 'function') {
      saved.forEach(function (item) {
        if (item && item.text) {
          window.appendChatBubble(item.role === 'model' ? 'model' : 'user', item.text, '', [], item.searchMode || '');
        }
      });
    }
    if (typeof window.resetChatAi === 'function' && !window._pfaResetAiHooked) {
      window._pfaResetAiHooked = true;
      var origReset = window.resetChatAi;
      window.resetChatAi = function () {
        try { localStorage.removeItem(AI_HISTORY_KEY); } catch (e) {}
        LAST_AI_DETECTED_ID = '';
        return origReset();
      };
    }
  }

  window.addEventListener('load', function () {
    injectAiNeonControls();
    hookCallApiForAiNeon();
    hookAiOptionNavigation();
    setTimeout(restoreAiChatHistoryAndHookReset, 350);
  });
})();

/* ==========================================================================
   PFA v2.0.8 — PLN Corporate Pro Portal, Dark Mode & Wave 2 Reliability Engine
   Pengembang: JODI SETIAWAN — PLN ULP Pelabuhan Ratu
   Arsitektur: Event-driven, zero polling, 100% kompatibel dengan fungsi lama
   ========================================================================== */
(function () {
  'use strict';

  var PFA_V208_VERSION = '2.0.11';
  var DARK_MODE_KEY = 'pfa_dark_mode_v1';
  var RECENT_ACT_KEY = 'pfa_recent_activity_v1';
  var TTL_CACHE_PREFIX = 'pfa_ttl_cache_v1_';
  var BETA_CHANNEL_KEY = 'pfa_beta_channel_v1';
  var MUTATING_ACTIONS = ['simpan_gangguan', 'simpan_pengukuran', 'simpan_p2tl', 'ajukan_material'];
  var CACHEABLE_ACTIONS = { get_master_kerusakan: 86400000, get_master_material: 86400000 }; // 24 jam
  var CRASH_REPORTS_SENT = 0;
  var LAST_VISIBLE_TS = Date.now();

  var V208_RELEASE_HISTORY = [
    {
      ver: '2.0.9',
      title: 'PLN Corporate Pro UI + Reliability Engine',
      items: [
        'Desain ulang Portal berjenjang tema warna khas PLN (Deep Navy, Cyan, Kuning Listrik) + PLN Night Dark Mode.',
        'Quick Search IDPEL / No. Meter + Scan Barcode langsung dari Portal & ringkasan status real-time.',
        'Tombol Analisa AI Neon langsung dari hasil Pengukuran Deviasi.',
        'Reliability Wave 1 & 2: Idempotency anti-dobel, Write Lock, Formula Guard, Auto-Retry Exponential Backoff, Auto-Sync saat sinyal kembali, Cache Master 24 jam, & Logout Guard antrean offline.',
        'Beta Tester Channel (khusus akun ADMIN) & Safe Mode Reset Cache di Menu ☰.'
      ]
    },
    {
      ver: '2.0.7',
      title: 'Kalibrasi Pengukuran SPLN D3.015-2:2023',
      items: [
        'Kalibrasi 100% rumus Stopwatch, KW Meter (termasuk CT terbalik/negatif), dan rata-rata 3 sampel daya sesaat.',
        'Standar Rasio CT TR sesuai SPLN D3.015-2:2023 Tabel 4 (105 kVA = 150/5, 147 kVA = 200/5).'
      ]
    },
    {
      ver: '2.0.6',
      title: 'Smart KB & Free Tier AI Stability',
      items: [
        'Peningkatan pencarian Knowledge Base (stemmer Indonesia + IDF + bigram) & optimalisasi model Gemini Free Tier.'
      ]
    },
    {
      ver: '2.0.5',
      title: 'PFA AI Neon Assistant',
      items: [
        'Auto-lookup 3 sumber data (DIL + Riwayat Gangguan + Cek KCT), Voice-to-Text, & pintasan auto-fill IDPEL.'
      ]
    }
  ];

  // --------------------------------------------------------------------------
  // 1. UTILITAS AMAN (ROLE, IDEMPOTENCY, STORAGE GUARD, TTL CACHE)
  // --------------------------------------------------------------------------
  function getCurrentUserObj() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.user ? parsed.user : parsed;
    } catch (e) {
      return null;
    }
  }

  function isCurrentUserAdmin() {
    var u = getCurrentUserObj();
    var role = u && (u.role || u.Role || u.jabatan) ? String(u.role || u.Role || u.jabatan).toUpperCase() : '';
    if (role.indexOf('ADMIN') !== -1) return true;
    var roleEl = document.getElementById('portalRoleText');
    if (roleEl && String(roleEl.textContent || '').toUpperCase().indexOf('ADMIN') !== -1) return true;
    return false;
  }

  function generateClientRequestId(action) {
    return 'pfa_' + String(action || 'req') + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  }

  function checkStorageQuotaAndPrune() {
    try {
      var totalBytes = 0;
      var ttlKeys = [];
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        var v = localStorage.getItem(k) || '';
        totalBytes += (k.length + v.length) * 2;
        if (k.indexOf(TTL_CACHE_PREFIX) === 0) ttlKeys.push(k);
      }
      // Jika > 3.8 MB (~80% batas 5MB), bersihkan cache TTL lama
      if (totalBytes > 3800000) {
        ttlKeys.forEach(function (tk) {
          try { localStorage.removeItem(tk); } catch (e) {}
        });
      }
    } catch (e) {}
  }

  function readTtlCache(action) {
    try {
      var raw = localStorage.getItem(TTL_CACHE_PREFIX + action);
      if (!raw) return null;
      var obj = JSON.parse(raw);
      if (!obj || !obj.exp || Date.now() > obj.exp) {
        localStorage.removeItem(TTL_CACHE_PREFIX + action);
        return null;
      }
      return obj.data;
    } catch (e) {
      return null;
    }
  }

  function writeTtlCache(action, data, ttlMs) {
    try {
      checkStorageQuotaAndPrune();
      localStorage.setItem(TTL_CACHE_PREFIX + action, JSON.stringify({
        exp: Date.now() + ttlMs,
        data: data
      }));
    } catch (e) {}
  }

  // --------------------------------------------------------------------------
  // 2. PLN NIGHT DARK MODE
  // --------------------------------------------------------------------------
  function applyDarkMode(enabled, persist) {
    var html = document.documentElement;
    if (enabled) {
      html.classList.add('pfa-dark-mode');
    } else {
      html.classList.remove('pfa-dark-mode');
    }
    var metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute('content', enabled ? '#0b1426' : '#003b73');

    var icon = document.getElementById('pfaQuickThemeIcon');
    if (icon) {
      icon.className = enabled ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
    }
    var menuLabel = document.getElementById('pfaMenuDarkLabel');
    if (menuLabel) {
      menuLabel.textContent = enabled ? 'Tema: PLN Night (Gelap)' : 'Tema: PLN Pro (Terang)';
    }
    if (persist) {
      try { localStorage.setItem(DARK_MODE_KEY, enabled ? '1' : '0'); } catch (e) {}
    }
  }

  function initDarkMode() {
    var saved = '0';
    try { saved = localStorage.getItem(DARK_MODE_KEY) || '0'; } catch (e) {}
    applyDarkMode(saved === '1', false);

    var quickBtn = document.getElementById('pfaQuickThemeBtn');
    if (quickBtn && !quickBtn._pfaBound) {
      quickBtn._pfaBound = true;
      quickBtn.addEventListener('click', function () {
        var next = !document.documentElement.classList.contains('pfa-dark-mode');
        applyDarkMode(next, true);
      });
    }
  }

  // --------------------------------------------------------------------------
  // 3. COMMAND PORTAL LIVE SYNC & RECENT ACTIVITY
  // --------------------------------------------------------------------------
  function getGreetingByHour() {
    var h = new Date().getHours();
    if (h >= 4 && h < 11) return 'Selamat Pagi';
    if (h >= 11 && h < 15) return 'Selamat Siang';
    if (h >= 15 && h < 18) return 'Selamat Sore';
    return 'Selamat Malam';
  }

  function recordRecentActivity(label, detail, statusText) {
    try {
      var list = JSON.parse(localStorage.getItem(RECENT_ACT_KEY) || '[]');
      if (!Array.isArray(list)) list = [];
      var now = new Date();
      var hh = String(now.getHours()).padStart(2, '0');
      var mm = String(now.getMinutes()).padStart(2, '0');
      list.unshift({
        label: String(label || 'Aktivitas'),
        detail: String(detail || '-'),
        status: String(statusText || 'Selesai'),
        time: hh + ':' + mm
      });
      if (list.length > 10) list = list.slice(0, 10);
      localStorage.setItem(RECENT_ACT_KEY, JSON.stringify(list));
      renderPortalRecentList();
    } catch (e) {}
  }

  function renderPortalRecentList() {
    if (window._pfaServerRecentLoaded) return;
    var box = document.getElementById('pfaPortalRecentList');
    if (!box) return;
    var list = [];
    try { list = JSON.parse(localStorage.getItem(RECENT_ACT_KEY) || '[]'); } catch (e) {}
    if (!Array.isArray(list) || list.length === 0) {
      box.innerHTML = '<div class="pfa-recent-empty"><i class="bi bi-clock-history me-2"></i>Belum ada aktivitas lokal hari ini.</div>';
      return;
    }
    var statLap = document.getElementById('pfaStatLaporan');
    if (statLap) statLap.textContent = String(list.length);

    box.innerHTML = list.slice(0, 3).map(function (it) {
      var safeLabel = String(it.label || '').replace(/</g, '&lt;');
      var safeDet = String(it.detail || '').replace(/</g, '&lt;');
      var safeSt = String(it.status || '').replace(/</g, '&lt;');
      var safeTm = String(it.time || '').replace(/</g, '&lt;');
      return (
        '<div class="pfa-recent-row">' +
          '<div class="min-w-0">' +
            '<div class="fw-bold text-truncate">' + safeLabel + '</div>' +
            '<div class="text-muted text-truncate" style="font-size:0.7rem;">' + safeDet + ' • ' + safeTm + '</div>' +
          '</div>' +
          '<span class="badge rounded-pill text-bg-primary flex-shrink-0" style="font-size:0.65rem;">' + safeSt + '</span>' +
        '</div>'
      );
    }).join('');
  }

  function countOfflineQueueItems(cb) {
    try {
      var req = indexedDB.open('pfa_offline_queue_db', 1);
      req.onsuccess = function (ev) {
        try {
          var db = ev.target.result;
          if (!db.objectStoreNames.contains('pending_submissions')) { cb(0); return; }
          var tx = db.transaction('pending_submissions', 'readonly');
          var cntReq = tx.objectStore('pending_submissions').count();
          cntReq.onsuccess = function () { cb(Number(cntReq.result || 0)); };
          cntReq.onerror = function () { cb(0); };
        } catch (e) { cb(0); }
      };
      req.onerror = function () { cb(0); };
    } catch (e) { cb(0); }
  }

  function refreshPortalDashboard() {
    var navNama = document.getElementById('navUserNama');
    var greetEl = document.getElementById('pfaPortalGreetingName');
    if (greetEl) {
      var nama = (navNama && navNama.textContent && navNama.textContent.trim() !== 'Petugas')
        ? navNama.textContent.trim()
        : (getCurrentUserObj() && getCurrentUserObj().nama) || 'Petugas';
      greetEl.textContent = getGreetingByHour() + ', ' + nama;
    }

    var isOnline = navigator.onLine !== false;
    var onlinePill = document.getElementById('pfaPortalOnlinePill');
    var statServer = document.getElementById('pfaStatServer');
    if (onlinePill) {
      onlinePill.classList.toggle('is-offline', !isOnline);
      onlinePill.innerHTML = '<span class="pfa-online-dot"></span>' + (isOnline ? 'Online' : 'Offline');
    }
    if (statServer) {
      statServer.textContent = isOnline ? 'Aktif' : 'Offline';
      statServer.classList.toggle('pfa-stat-ok', isOnline);
      statServer.classList.toggle('pfa-stat-warn', !isOnline);
    }

    countOfflineQueueItems(function (cnt) {
      var statAnt = document.getElementById('pfaStatAntrean');
      var subOff = document.getElementById('pfaPortalOfflineSub');
      if (statAnt) {
        statAnt.textContent = String(cnt);
        statAnt.classList.toggle('pfa-stat-warn', cnt > 0);
      }
      if (subOff) {
        subOff.textContent = cnt > 0 ? (cnt + ' menunggu sinkron') : 'Semua tersinkron';
      }
    });

    renderPortalRecentList();
    syncAdminBetaMenuVisibility();
  }

  // --------------------------------------------------------------------------
  // 4. PORTAL QUICK SEARCH & BARCODE SCAN
  // --------------------------------------------------------------------------
  function executePortalQuickSearch() {
    var inp = document.getElementById('pfaPortalQuickSearch');
    if (!inp) return;
    var raw = String(inp.value || '').trim();
    if (!raw) {
      inp.focus();
      return;
    }
    var lower = raw.toLowerCase();
    var targetTab = 'gangguan';
    var keyword = raw.replace(/\s+/g, '');
    if (lower.indexOf('kct ') === 0) {
      targetTab = 'kct';
      keyword = raw.slice(4).trim();
    }
    if (typeof window.switchTab === 'function') window.switchTab(targetTab);
    setTimeout(function () {
      if (targetTab === 'kct') {
        var kInp = document.getElementById('kctSearchInput');
        if (kInp) {
          kInp.value = keyword;
          kInp.dispatchEvent(new Event('input', { bubbles: true }));
          var kBtn = document.querySelector('#tab-kct button[onclick*="cariKct"], #tab-kct button[type="submit"]');
          if (kBtn) kBtn.click();
        }
      } else {
        var gInp = document.getElementById('cariPelangganInput');
        if (gInp) {
          gInp.value = keyword;
          gInp.dispatchEvent(new Event('input', { bubbles: true }));
          var gBtn = document.querySelector('#tab-gangguan button[onclick*="cariDataPelanggan"]');
          if (gBtn) gBtn.click();
        }
      }
    }, 180);
  }

  function initPortalQuickSearch() {
    var inp = document.getElementById('pfaPortalQuickSearch');
    var goBtn = document.getElementById('pfaPortalQuickSearchGo');
    var scanBtn = document.getElementById('pfaPortalQuickScan');

    if (goBtn && !goBtn._pfaBound) {
      goBtn._pfaBound = true;
      goBtn.addEventListener('click', executePortalQuickSearch);
    }
    if (inp && !inp._pfaBound) {
      inp._pfaBound = true;
      inp.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          executePortalQuickSearch();
        }
      });
    }
    if (scanBtn && !scanBtn._pfaBound) {
      scanBtn._pfaBound = true;
      scanBtn.addEventListener('click', function () {
        if (typeof window.openBarcodeScanner === 'function') {
          window.openBarcodeScanner('pfaPortalQuickSearch');
        } else if (typeof window.showToast === 'function') {
          window.showToast('Scanner barcode belum siap.', 'warning');
        }
      });
    }
  }

  // --------------------------------------------------------------------------
  // 5. AI NEON INSIGHT BUTTON DI TAB PENGUKURAN
  // --------------------------------------------------------------------------
  function injectPengukuranAiInsightBtn() {
    var tabUkur = document.getElementById('tab-pengukuran');
    if (!tabUkur || document.getElementById('pfaBtnAiInsightUkur')) return;
    var resultBox = tabUkur.querySelector('#hasilPengukuranBox, #boxHasilPengukuran, .alert-info, .card-body');
    if (!resultBox) return;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'pfaBtnAiInsightUkur';
    btn.className = 'btn btn-sm pfa-ai-insight-btn rounded-3 mt-2 w-100';
    btn.innerHTML = '<i class="bi bi-lightning-charge-fill text-warning me-1"></i> Analisa Hasil Pengukuran dengan PFA AI';
    btn.addEventListener('click', function () {
      var idpel = (document.getElementById('u_idpel') && document.getElementById('u_idpel').value) || '-';
      var errEl = document.getElementById('u_error_kwh') || document.getElementById('u_hasil_error');
      var errVal = errEl ? (errEl.value || errEl.textContent || '-') : '-';
      var p1El = document.getElementById('u_p1');
      var p2El = document.getElementById('u_p2');
      var promptText =
        'Tolong analisa hasil pengukuran kWh meter berikut sesuai SPLN & Perdir P2TL: ' +
        'IDPEL ' + idpel + ', Error kWh = ' + errVal +
        (p1El && p1El.value ? ', P1 = ' + p1El.value + ' kW' : '') +
        (p2El && p2El.value ? ', P2 = ' + p2El.value + ' kW' : '') +
        '. Apa indikasi kelainan dan tindak lanjut lapangannya?';

      if (typeof window.switchTab === 'function') window.switchTab('chatbot');
      setTimeout(function () {
        var chatInp = document.getElementById('chatPromptInput');
        if (chatInp) {
          chatInp.value = promptText;
          chatInp.focus();
        }
      }, 220);
    });
    resultBox.appendChild(btn);
  }

  // --------------------------------------------------------------------------
  // 6. WAVE 2 RELIABILITY WRAPPER (IDEMPOTENCY, BACKOFF, CACHE 24H, PAYLOAD GUARD)
  // --------------------------------------------------------------------------
  function sleepMs(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  function isRetryableNetworkError(err) {
    var msg = String((err && err.message) || err || '').toLowerCase();
    if (msg.indexOf('session_expired') !== -1 || msg.indexOf('password') !== -1 || msg.indexOf('terkunci') !== -1) {
      return false;
    }
    return (
      msg.indexOf('network') !== -1 ||
      msg.indexOf('timeout') !== -1 ||
      msg.indexOf('failed to fetch') !== -1 ||
      msg.indexOf('503') !== -1 ||
      msg.indexOf('502') !== -1 ||
      msg.indexOf('504') !== -1 ||
      msg.indexOf('unavailable') !== -1
    );
  }

  function wrapCallApiReliability() {
    if (typeof window.callApi !== 'function' || window._pfaV208ApiWrapped) return;
    window._pfaV208ApiWrapped = true;
    var origCallApi = window.callApi;

    window.callApi = async function (payload) {
      var req = payload && typeof payload === 'object' ? Object.assign({}, payload) : payload;
      var action = req && req.action ? String(req.action).trim() : '';

      // 1. TTL Cache 24 jam untuk data master (buka form instan)
      if (CACHEABLE_ACTIONS[action] && !req._bypassCache) {
        var cached = readTtlCache(action);
        if (cached) return cached;
      }

      // 2. Idempotency Key otomatis untuk aksi simpan/mutasi
      if (MUTATING_ACTIONS.indexOf(action) !== -1 && !req.clientRequestId) {
        req.clientRequestId = generateClientRequestId(action);
      }

      // 3. Dynamic Timeout Hint (25s baca / 90s upload multi-foto)
      if (!req._timeoutMs) {
        req._timeoutMs = MUTATING_ACTIONS.indexOf(action) !== -1 ? 90000 : 25000;
      }

      // 4. Payload > 2.5MB Guard
      try {
        var bytes = JSON.stringify(req).length;
        if (bytes > 2621440 && typeof window.showToast === 'function') {
          window.showToast('Ukuran foto cukup besar (' + (bytes / 1048576).toFixed(1) + ' MB). Aktifkan Mode Sinyal Lemah agar lebih cepat.', 'warning');
        }
      } catch (eSize) {}

      // 5. Exponential Backoff Auto-Retry (maks 2x retry untuk gangguan jaringan/503)
      var maxRetries = MUTATING_ACTIONS.indexOf(action) !== -1 ? 1 : 2;
      var attempt = 0;
      while (true) {
        try {
          var res = await origCallApi(req);

          if (CACHEABLE_ACTIONS[action] && res && res.status === 'success') {
            writeTtlCache(action, res, CACHEABLE_ACTIONS[action]);
          }
          if (MUTATING_ACTIONS.indexOf(action) !== -1 && res && res.status === 'success') {
            var lblMap = {
              simpan_gangguan: 'Laporan Meter Rusak',
              simpan_pengukuran: 'Pengukuran Deviasi',
              simpan_p2tl: 'Temuan P2TL',
              ajukan_material: 'Transaksi Material'
            };
            var det = (req.data && (req.data.idpel || req.data.noSurat || req.data.nama)) || 'Terkirim';
            recordRecentActivity(lblMap[action] || action, String(det), res.queuedOffline ? 'Antrean' : 'Terkirim');
            setTimeout(refreshPortalDashboard, 300);
          }
          return res;
        } catch (err) {
          attempt++;
          if (attempt <= maxRetries && isRetryableNetworkError(err)) {
            await sleepMs(1200 * attempt);
            continue;
          }
          throw err;
        }
      }
    };
  }

  // --------------------------------------------------------------------------
  // 7. AUTO-SYNC SAAT SINYAL KEMBALI, SILENT HEARTBEAT & LOGOUT GUARD
  // --------------------------------------------------------------------------
  function initNetworkAutoSyncAndHeartbeat() {
    function triggerAutoSync() {
      refreshPortalDashboard();
      countOfflineQueueItems(function (cnt) {
        if (cnt > 0 && typeof window.pfaSyncOfflineQueue === 'function') {
          if (typeof window.showToast === 'function') {
            window.showToast('Koneksi kembali! Menyinkronkan ' + cnt + ' antrean offline...', 'info');
          }
          window.pfaSyncOfflineQueue();
        }
      });
    }

    window.addEventListener('online', triggerAutoSync);
    window.addEventListener('offline', refreshPortalDashboard);

    // @capacitor/network listener jika tersedia di APK native
    try {
      var capNet = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Network;
      if (capNet && typeof capNet.addListener === 'function') {
        capNet.addListener('networkStatusChange', function (st) {
          if (st && st.connected) triggerAutoSync();
          else refreshPortalDashboard();
        });
      }
    } catch (e) {}

    // Silent Session Heartbeat (event-driven saat kembali ke aplikasi > 15 menit, ZERO polling)
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'visible') {
        var idleMs = Date.now() - LAST_VISIBLE_TS;
        LAST_VISIBLE_TS = Date.now();
        refreshPortalDashboard();
        if (idleMs > 900000 && navigator.onLine !== false && typeof window.callApi === 'function') {
          window.callApi({ action: 'api_version_check' }).catch(function () {});
        }
      } else {
        LAST_VISIBLE_TS = Date.now();
      }
    });
  }

  function wrapLogoutGuard() {
    if (typeof window.logoutApp !== 'function' || window._pfaLogoutGuarded) return;
    window._pfaLogoutGuarded = true;
    var origLogout = window.logoutApp;
    window.logoutApp = function () {
      countOfflineQueueItems(function (cnt) {
        if (cnt > 0) {
          var ok = window.confirm(
            'Masih ada ' + cnt + ' laporan di Antrean Offline yang belum terkirim ke server.\n\n' +
            'Yakin tetap ingin keluar sekarang?'
          );
          if (!ok) return;
        }
        origLogout();
      });
    };
  }

  // --------------------------------------------------------------------------
  // 8. WEBP PHOTO COMPRESSOR, LAZY THUMBNAILS & DEBOUNCED SEARCH
  // --------------------------------------------------------------------------
  window.pfaCompressImageWebp = function (file, maxWidth, quality) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onerror = reject;
      reader.onload = function (e) {
        var img = new Image();
        img.onerror = reject;
        img.onload = function () {
          var mw = maxWidth || 1280;
          var ratio = img.width > mw ? mw / img.width : 1;
          var canvas = document.createElement('canvas');
          canvas.width = Math.round(img.width * ratio);
          canvas.height = Math.round(img.height * ratio);
          var ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          var webp = canvas.toDataURL('image/webp', quality || 0.78);
          if (webp && webp.indexOf('data:image/webp') === 0) {
            resolve(webp);
          } else {
            resolve(canvas.toDataURL('image/jpeg', quality || 0.8));
          }
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    });
  };

  function enableLazyImagesAndPagination() {
    try {
      var imgs = document.querySelectorAll('img.foto-preview, img.rekap-foto-img');
      imgs.forEach(function (im) {
        im.setAttribute('loading', 'lazy');
        im.setAttribute('decoding', 'async');
      });
    } catch (e) {}
  }

  // --------------------------------------------------------------------------
  // 9. SILENT CRASH REPORTER -> System_Logs (Maks 3x/sesi)
  // --------------------------------------------------------------------------
  function reportSilentCrash(msg, src) {
    if (CRASH_REPORTS_SENT >= 3 || navigator.onLine === false) return;
    if (typeof window.callApi !== 'function') return;
    CRASH_REPORTS_SENT++;
    var u = getCurrentUserObj();
    window.callApi({
      action: 'log_client_error',
      versi: PFA_V208_VERSION,
      username: (u && u.username) || '-',
      message: String(msg || 'Unknown error').slice(0, 300),
      source: String(src || '-').slice(0, 120)
    }).catch(function () {});
  }

  window.addEventListener('error', function (ev) {
    if (ev && ev.message) reportSilentCrash(ev.message, ev.filename + ':' + ev.lineno);
  });

  window.addEventListener('unhandledrejection', function (ev) {
    var reason = ev && ev.reason ? (ev.reason.message || String(ev.reason)) : '';
    if (reason && reason.toLowerCase().indexOf('network') === -1) {
      reportSilentCrash('Promise: ' + reason, 'unhandledrejection');
    }
  });

  // --------------------------------------------------------------------------
  // 10. MENU ☰: DARK MODE, RIWAYAT RILIS & SAFE MODE, BETA CHANNEL (ADMIN ONLY)
  // --------------------------------------------------------------------------
  function openReleaseHistoryModal() {
    var modalId = 'pfaReleaseHistoryModal';
    var el = document.getElementById(modalId);
    if (!el) {
      var htmlList = V208_RELEASE_HISTORY.map(function (r) {
        var bullets = r.items.map(function (it) {
          return '<li class="mb-1">' + it + '</li>';
        }).join('');
        return (
          '<div class="mb-3 pb-2 border-bottom">' +
            '<div class="d-flex justify-content-between align-items-center mb-1">' +
              '<span class="fw-bold text-primary">v' + r.ver + ' — ' + r.title + '</span>' +
            '</div>' +
            '<ul class="small mb-0 ps-3">' + bullets + '</ul>' +
          '</div>'
        );
      }).join('');

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">' +
          '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
            '<div class="modal-content rounded-4 border-0 shadow">' +
              '<div class="modal-header border-0 pb-1">' +
                '<h6 class="modal-title fw-bold"><i class="bi bi-clock-history me-2 text-primary"></i>Riwayat Rilis &amp; Safe Mode</h6>' +
                '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
              '</div>' +
              '<div class="modal-body pt-2">' +
                htmlList +
                '<div class="p-2 rounded-3 bg-light small mb-2">' +
                  '<div class="fw-bold">Pengembang Aplikasi</div>' +
                  '<div>JODI SETIAWAN — PLN ULP Pelabuhan Ratu</div>' +
                '</div>' +
                '<button type="button" id="pfaSafeModeResetBtn" class="btn btn-outline-warning btn-sm w-100 fw-semibold">' +
                  '<i class="bi bi-shield-exclamation me-1"></i> Safe Mode: Bersihkan Cache &amp; Muat Ulang' +
                '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';
      document.body.appendChild(wrap.firstElementChild);
      el = document.getElementById(modalId);

      var safeBtn = document.getElementById('pfaSafeModeResetBtn');
      if (safeBtn) {
        safeBtn.addEventListener('click', function () {
          if (!window.confirm('Bersihkan cache master & muat ulang aplikasi? (Antrean offline tetap aman)')) return;
          try {
            Object.keys(localStorage).forEach(function (k) {
              if (k.indexOf(TTL_CACHE_PREFIX) === 0) localStorage.removeItem(k);
            });
          } catch (e) {}
          window.location.reload();
        });
      }
    }
    if (window.bootstrap && window.bootstrap.Modal) {
      window.bootstrap.Modal.getOrCreateInstance(el).show();
    }
  }

  function syncAdminBetaMenuVisibility() {
    var betaLi = document.getElementById('pfaMenuBetaLi');
    if (!betaLi) return;
    if (isCurrentUserAdmin()) {
      betaLi.classList.remove('d-none');
    } else {
      betaLi.classList.add('d-none');
    }
  }

  function injectV208DropdownMenuItems() {
    var menuUl = document.querySelector('#appScreen .topbar-pln .dropdown-menu');
    if (!menuUl || document.getElementById('pfaMenuDarkLi')) return;

    var divider = menuUl.querySelector('.dropdown-divider');
    var anchorLi = divider ? divider.closest('li') : menuUl.lastElementChild;

    // 1. Toggle Dark Mode
    var darkLi = document.createElement('li');
    darkLi.id = 'pfaMenuDarkLi';
    darkLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2" id="pfaMenuDarkBtn">' +
        '<i class="bi bi-moon-stars-fill me-2 text-warning"></i>' +
        '<span id="pfaMenuDarkLabel">Tema: PLN Pro (Terang)</span>' +
      '</button>';
    darkLi.querySelector('button').addEventListener('click', function () {
      var next = !document.documentElement.classList.contains('pfa-dark-mode');
      applyDarkMode(next, true);
    });

    // 2. Riwayat Rilis & Safe Mode
    var relLi = document.createElement('li');
    relLi.id = 'pfaMenuReleaseLi';
    relLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2">' +
        '<i class="bi bi-stars me-2 text-info"></i> Riwayat Rilis &amp; Safe Mode' +
      '</button>';
    relLi.querySelector('button').addEventListener('click', openReleaseHistoryModal);

    // 3. Beta Tester Channel (KHUSUS ADMIN)
    var betaLi = document.createElement('li');
    betaLi.id = 'pfaMenuBetaLi';
    betaLi.className = 'd-none';
    var isBeta = false;
    try { isBeta = localStorage.getItem(BETA_CHANNEL_KEY) === '1'; } catch (e) {}
    betaLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2" id="pfaMenuBetaBtn">' +
        '<i class="bi bi-rocket-takeoff-fill me-2 text-primary"></i>' +
        '<span id="pfaMenuBetaLabel">Channel Beta (Admin): ' + (isBeta ? 'AKTIF' : 'OFF') + '</span>' +
      '</button>';
    betaLi.querySelector('button').addEventListener('click', function () {
      if (!isCurrentUserAdmin()) return;
      var cur = localStorage.getItem(BETA_CHANNEL_KEY) === '1';
      var next = !cur;
      try { localStorage.setItem(BETA_CHANNEL_KEY, next ? '1' : '0'); } catch (e) {}
      var lbl = document.getElementById('pfaMenuBetaLabel');
      if (lbl) lbl.textContent = 'Channel Beta (Admin): ' + (next ? 'AKTIF' : 'OFF');
      if (typeof window.showToast === 'function') {
        window.showToast('Beta Tester Channel ' + (next ? 'diaktifkan' : 'dinonaktifkan') + ' (Khusus Admin).', 'info');
      }
    });

    if (anchorLi && anchorLi.parentNode) {
      anchorLi.parentNode.insertBefore(darkLi, anchorLi);
      anchorLi.parentNode.insertBefore(relLi, anchorLi);
      anchorLi.parentNode.insertBefore(betaLi, anchorLi);
    } else {
      menuUl.appendChild(darkLi);
      menuUl.appendChild(relLi);
      menuUl.appendChild(betaLi);
    }
    applyDarkMode(document.documentElement.classList.contains('pfa-dark-mode'), false);
    syncAdminBetaMenuVisibility();
  }

  // Hook switchTab agar Portal selalu refresh saat dibuka kembali
  function hookSwitchTabForPortal() {
    if (typeof window.switchTab !== 'function' || window._pfaV208TabHooked) return;
    window._pfaV208TabHooked = true;
    var origSwitch = window.switchTab;
    window.switchTab = function (tabName) {
      var r = origSwitch.apply(this, arguments);
      if (tabName === 'portal') setTimeout(refreshPortalDashboard, 80);
      if (tabName === 'pengukuran') setTimeout(injectPengukuranAiInsightBtn, 120);
      return r;
    };
  }

  // Bootstrap seluruh fitur v2.0.8 setelah DOM siap
  function bootV208() {
    initDarkMode();
    initPortalQuickSearch();
    injectV208DropdownMenuItems();
    wrapCallApiReliability();
    wrapLogoutGuard();
    hookSwitchTabForPortal();
    initNetworkAutoSyncAndHeartbeat();
    enableLazyImagesAndPagination();
    setTimeout(refreshPortalDashboard, 350);
    setTimeout(injectPengukuranAiInsightBtn, 500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootV208);
  } else {
    bootV208();
  }
  window.addEventListener('load', function () {
    setTimeout(refreshPortalDashboard, 450);
  });
})();

/* ==========================================================================
   PFA v2.0.8 — Portal Live Summary Berbasis Role (Admin Semua / Petugas Sendiri)
   ========================================================================== */
(function () {
  'use strict';
  var LAST_SUMMARY_FETCH_TS = 0;
  var IS_FETCHING_SUMMARY = false;

  function getUserObjSafe() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.user ? parsed.user : parsed;
    } catch (e) { return null; }
  }

  function isAdminRole() {
    var u = getUserObjSafe();
    var r = u && (u.role || u.Role || u.jabatan) ? String(u.role || u.Role || u.jabatan).toUpperCase() : '';
    if (r.indexOf('ADMIN') !== -1) return true;
    var el = document.getElementById('portalRoleText');
    return Boolean(el && String(el.textContent || '').toUpperCase().indexOf('ADMIN') !== -1);
  }

  function renderServerRecent(items, scope) {
    window._pfaServerRecentLoaded = true;
    var box = document.getElementById('pfaPortalRecentList');
    if (!box) return;
    if (!Array.isArray(items) || items.length === 0) {
      box.innerHTML = '<div class="pfa-recent-empty"><i class="bi bi-clock-history me-2"></i>' +
        (scope === 'ALL_PETUGAS' ? 'Belum ada laporan petugas masuk.' : 'Belum ada laporan yang kamu kirim.') +
        '</div>';
      return;
    }
    box.innerHTML = items.slice(0, 5).map(function (it) {
      var m = String(it.modul || 'Laporan').replace(/</g, '&lt;');
      var d = String(it.detail || '-').replace(/</g, '&lt;');
      var t = String(it.timestamp || '').replace(/</g, '&lt;');
      var s = String(it.status || 'Terkirim').replace(/</g, '&lt;');
      return (
        '<div class="pfa-recent-row">' +
          '<div class="pfa-recent-top">' +
            '<span class="pfa-recent-title">' + m + '</span>' +
            '<span class="badge rounded-pill text-bg-primary pfa-recent-badge">' + s + '</span>' +
          '</div>' +
          '<div class="pfa-recent-detail">' + d + (t ? ' • ' + t : '') + '</div>' +
        '</div>'
      );
    }).join('');
  }

  function syncPortalSummaryFromServer(force) {
    if (IS_FETCHING_SUMMARY || navigator.onLine === false) return;
    if (typeof window.callApi !== 'function') return;
    var u = getUserObjSafe();
    if (!u) return;

    var now = Date.now();
    if (!force && (now - LAST_SUMMARY_FETCH_TS) < 45000) return;

    IS_FETCHING_SUMMARY = true;
    LAST_SUMMARY_FETCH_TS = now;

    window.callApi({
      action: 'get_portal_summary',
      petugasNama: u.nama || '',
      username: u.username || '',
      userRole: u.role || '',
      forceRefresh: Boolean(force)
    }).then(function (res) {
      IS_FETCHING_SUMMARY = false;
      if (!res || res.status !== 'success') return;

      var statLap = document.getElementById('pfaStatLaporan');
      if (statLap && res.counts) {
        statLap.textContent = String(res.counts.total || 0);
        var lblEl = statLap.parentElement && statLap.parentElement.querySelector('.pfa-stat-lbl');
        if (lblEl) {
          lblEl.textContent = (res.scope === 'ALL_PETUGAS') ? 'Semua Laporan' : 'Laporan Saya';
        }
        // Klik angka Laporan: Admin -> Backoffice Admin, Petugas -> Histori Saya
        if (statLap.parentElement) {
          statLap.parentElement.onclick = function () {
            if (res.scope === 'ALL_PETUGAS' && typeof window.switchTab === 'function') {
              window.switchTab('admin');
            } else if (typeof window.openHistoriSayaModal === 'function') {
              window.openHistoriSayaModal();
            }
          };
        }
      }
      renderServerRecent(res.recent || [], res.scope);
    }).catch(function () {
      IS_FETCHING_SUMMARY = false;
    });
  }

  // Hook switchTab & login agar angka langsung sinkron dari server
  function initV209PortalLive() {
    // Hapus kotak greeting putih duplikat jika sempat terbuat
    var dup = document.getElementById('pfaPortalGreeting');
    if (dup && dup.parentNode) dup.parentNode.removeChild(dup);

    if (typeof window.switchTab === 'function' && !window._pfaV209TabHooked) {
      window._pfaV209TabHooked = true;
      var orig = window.switchTab;
      window.switchTab = function (tabName) {
        var r = orig.apply(this, arguments);
        if (tabName === 'portal') setTimeout(function () { syncPortalSummaryFromServer(false); }, 150);
        return r;
      };
    }

    // Jika baru selesai simpan laporan, paksa refresh summary
    if (typeof window.callApi === 'function' && !window._pfaV209SaveHooked) {
      window._pfaV209SaveHooked = true;
      var origApi = window.callApi;
      window.callApi = async function (payload) {
        var res = await origApi(payload);
        var act = payload && payload.action;
        if (res && res.status === 'success' && (act === 'login' || act === 'simpan_gangguan' || act === 'simpan_pengukuran' || act === 'simpan_p2tl' || act === 'ajukan_material')) {
          setTimeout(function () { syncPortalSummaryFromServer(true); }, 450);
        }
        return res;
      };
    }

    setTimeout(function () { syncPortalSummaryFromServer(false); }, 700);
  }

  window.addEventListener('load', initV209PortalLive);
})();

/* ==========================================================================
   PFA v2.0.8 — All-Module PLN Corporate Pro Hero & Photo Checkmark Enhancer
   (Non-destruktif: 0 perubahan ID HTML, 100% aman untuk seluruh form & fungsi)
   ========================================================================== */
(function () {
  'use strict';

  var MODULE_HEROES = [
    {
      tabId: 'tab-gangguan',
      badge: 'OPERASIONAL METER',
      title: 'Input Meter Rusak & Gangguan',
      sub: 'Auto-fill Master DIL, lokasi gardu/tiang & unggah 4 foto bukti',
      icon: 'bi-tools'
    },
    {
      tabId: 'tab-p2tl',
      badge: 'PENERTIBAN P2TL',
      title: 'Temuan Potensi P2TL',
      sub: 'Perdir 0028.P/DIR/2023 + PBJT-TL & dokumentasi lapangan',
      icon: 'bi-exclamation-octagon-fill'
    },
    {
      tabId: 'tab-kct',
      badge: 'TOKEN & KCT',
      title: 'Cek KCT Lintas ULP',
      sub: 'Pencarian cepat token KCT 1A/1B/2A/2B & kirim langsung via WA',
      icon: 'bi-key-fill'
    },
    {
      tabId: 'tab-chatbot',
      badge: 'PFA AI NEON',
      title: 'Asisten AI Petugas Lapangan',
      sub: 'Diagnosa APP, OCR foto meter/CT, DIL, KCT, P2TL & SPLN',
      icon: 'bi-lightning-charge-fill'
    },
    {
      tabId: 'tab-tutorial',
      badge: 'PANDUAN RESMI',
      title: 'Tutorial Penggunaan PFA',
      sub: 'Panduan langkah demi langkah seluruh modul operasional',
      icon: 'bi-book-half'
    }
  ];

  function injectModuleHeroCards() {
    MODULE_HEROES.forEach(function (cfg) {
      var sec = document.getElementById(cfg.tabId);
      if (!sec || sec.querySelector('.pfa-mod-hero')) return;
      var firstBar = sec.querySelector(':scope > .d-flex');
      var hero = document.createElement('div');
      hero.className = 'pfa-mod-hero';
      hero.innerHTML =
        '<div class="min-w-0">' +
          '<span class="pfa-mod-hero-badge">⚡ ' + cfg.badge + '</span>' +
          '<h6 class="pfa-mod-hero-title">' + cfg.title + '</h6>' +
          '<div class="pfa-mod-hero-sub">' + cfg.sub + '</div>' +
        '</div>' +
        '<div class="pfa-mod-hero-icon" aria-hidden="true"><i class="bi ' + cfg.icon + '"></i></div>';

      if (firstBar && firstBar.nextSibling) {
        sec.insertBefore(hero, firstBar.nextSibling);
      } else {
        sec.insertBefore(hero, sec.firstChild);
      }
    });
  }

  function bindPhotoFilledIndicators() {
    document.addEventListener('change', function (ev) {
      var el = ev && ev.target;
      if (!el || el.tagName !== 'INPUT' || el.type !== 'file') return;
      var hasFile = Boolean(el.files && el.files.length > 0);
      el.classList.toggle('pfa-photo-filled', hasFile);

      var wrap = el.closest('.mb-2, .mb-3, .col-6, .col-12, div');
      var lbl = wrap ? wrap.querySelector('label.form-label, label') : null;
      if (lbl) {
        var existing = lbl.querySelector('.pfa-photo-ok-pill');
        if (hasFile && !existing) {
          var pill = document.createElement('span');
          pill.className = 'pfa-photo-ok-pill';
          pill.innerHTML = '<i class="bi bi-check-circle-fill"></i>Siap';
          lbl.appendChild(pill);
        } else if (!hasFile && existing) {
          existing.remove();
        }
      }
    });
  }

  function bootAllModulePolish() {
    injectModuleHeroCards();
    bindPhotoFilledIndicators();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootAllModulePolish);
  } else {
    bootAllModulePolish();
  }
})();

/* ==========================================================================
   PFA v2.0.11 — Menu ☰ Ringkas (5 Item Inti), Modal Pengaturan & Tentang+Saran
   ========================================================================== */
(function () {
  'use strict';

  function getUserSafeV210() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.user ? parsed.user : parsed;
    } catch (e) { return null; }
  }

  function isAdminV210() {
    var u = getUserSafeV210();
    var r = u && (u.role || u.Role || u.jabatan) ? String(u.role || u.Role || u.jabatan).toUpperCase() : '';
    if (r.indexOf('ADMIN') !== -1) return true;
    var el = document.getElementById('portalRoleText');
    return Boolean(el && String(el.textContent || '').toUpperCase().indexOf('ADMIN') !== -1);
  }

  function syncPortalOddGrid() {
    var grid = document.querySelector('#tab-portal .pfa-util-grid');
    var adm = document.getElementById('portalAdminCard');
    if (!grid || !adm) return;
    grid.classList.toggle('pfa-util-odd', adm.classList.contains('d-none'));
  }

  function openCompactSettingsModal() {
    var modalId = 'pfaCompactSettingsModal';
    var existing = document.getElementById(modalId);
    if (existing) existing.remove();

    var isDark = document.documentElement.classList.contains('pfa-dark-mode');
    var isLarge = document.documentElement.classList.contains('pfa-font-large');
    var isBeta = localStorage.getItem('pfa_beta_channel_v1') === '1';
    var showBeta = isAdminV210();

    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">' +
        '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
          '<div class="modal-content rounded-4 border-0 shadow">' +
            '<div class="modal-header border-0 pb-1">' +
              '<h6 class="modal-title fw-bold"><i class="bi bi-sliders2 me-2 text-primary"></i>Pengaturan &amp; Sistem</h6>' +
              '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
            '</div>' +
            '<div class="modal-body pt-2">' +
              '<div class="small fw-bold text-muted mb-1 px-1">TAMPILAN</div>' +
              '<div class="pfa-settings-group">' +
                '<button type="button" class="pfa-settings-row" id="pfaSetDarkBtn">' +
                  '<span><i class="bi bi-moon-stars-fill me-2 text-warning"></i>Mode Tampilan</span>' +
                  '<span class="badge text-bg-primary rounded-pill" id="pfaSetDarkVal">' + (isDark ? 'PLN Night' : 'PLN Pro') + '</span>' +
                '</button>' +
                '<button type="button" class="pfa-settings-row" id="pfaSetFontBtn">' +
                  '<span><i class="bi bi-fonts me-2 text-info"></i>Ukuran Teks</span>' +
                  '<span class="badge text-bg-secondary rounded-pill" id="pfaSetFontVal">' + (isLarge ? 'Besar' : 'Normal') + '</span>' +
                '</button>' +
              '</div>' +

              '<div class="small fw-bold text-muted mb-1 px-1">SESI &amp; PEMBARUAN</div>' +
              '<div class="pfa-settings-group">' +
                '<button type="button" class="pfa-settings-row" id="pfaSetSessionBtn">' +
                  '<span><i class="bi bi-shield-check me-2 text-success"></i>Segarkan Sesi Login</span>' +
                  '<span class="badge text-bg-light border rounded-pill">Segarkan</span>' +
                '</button>' +
                '<button type="button" class="pfa-settings-row" id="pfaSetUpdateBtn">' +
                  '<span><i class="bi bi-cloud-download-fill me-2 text-primary"></i>Cek Update Aplikasi</span>' +
                  '<span class="badge text-bg-light border rounded-pill">v2.0.11</span>' +
                '</button>' +
                (showBeta
                  ? '<button type="button" class="pfa-settings-row" id="pfaSetBetaBtn">' +
                      '<span><i class="bi bi-rocket-takeoff-fill me-2 text-primary"></i>Channel Beta (Admin)</span>' +
                      '<span class="badge ' + (isBeta ? 'text-bg-success' : 'text-bg-secondary') + ' rounded-pill" id="pfaSetBetaVal">' + (isBeta ? 'AKTIF' : 'OFF') + '</span>' +
                    '</button>'
                  : '') +
              '</div>' +

              '<div class="small fw-bold text-muted mb-1 px-1">PEMELIHARAAN</div>' +
              '<div class="pfa-settings-group mb-1">' +
                '<button type="button" class="pfa-settings-row" id="pfaSetSafeBtn">' +
                  '<span><i class="bi bi-shield-exclamation me-2 text-warning"></i>Safe Mode (Bersihkan Cache)</span>' +
                  '<i class="bi bi-chevron-right text-muted"></i>' +
                '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(wrap.firstElementChild);
    var modalEl = document.getElementById(modalId);
    var bsModal = window.bootstrap && window.bootstrap.Modal ? window.bootstrap.Modal.getOrCreateInstance(modalEl) : null;

    document.getElementById('pfaSetDarkBtn').onclick = function () {
      var quickBtn = document.getElementById('pfaQuickThemeBtn');
      if (quickBtn) quickBtn.click();
      var nowDark = document.documentElement.classList.contains('pfa-dark-mode');
      document.getElementById('pfaSetDarkVal').textContent = nowDark ? 'PLN Night' : 'PLN Pro';
    };

    document.getElementById('pfaSetFontBtn').onclick = function () {
      var origFontBtn = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="font"]');
      if (origFontBtn) {
        origFontBtn.click();
      } else {
        var nextLarge = !document.documentElement.classList.contains('pfa-font-large');
        document.documentElement.classList.toggle('pfa-font-large', nextLarge);
        try { localStorage.setItem('pfa_font_large_v1', nextLarge ? '1' : '0'); } catch (e) {}
      }
      var nowLarge = document.documentElement.classList.contains('pfa-font-large');
      document.getElementById('pfaSetFontVal').textContent = nowLarge ? 'Besar' : 'Normal';
    };

    document.getElementById('pfaSetSessionBtn').onclick = function () {
      if (bsModal) bsModal.hide();
      var origSess = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="session"]');
      if (origSess) origSess.click();
    };

    document.getElementById('pfaSetUpdateBtn').onclick = function () {
      if (bsModal) bsModal.hide();
      var origUpd = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="update"]');
      if (origUpd) origUpd.click();
    };

    var betaBtn = document.getElementById('pfaSetBetaBtn');
    if (betaBtn) {
      betaBtn.onclick = function () {
        var cur = localStorage.getItem('pfa_beta_channel_v1') === '1';
        var next = !cur;
        try { localStorage.setItem('pfa_beta_channel_v1', next ? '1' : '0'); } catch (e) {}
        var valEl = document.getElementById('pfaSetBetaVal');
        if (valEl) {
          valEl.textContent = next ? 'AKTIF' : 'OFF';
          valEl.className = 'badge ' + (next ? 'text-bg-success' : 'text-bg-secondary') + ' rounded-pill';
        }
      };
    }

    document.getElementById('pfaSetSafeBtn').onclick = function () {
      if (!window.confirm('Bersihkan cache master & muat ulang aplikasi? (Antrean offline tetap aman)')) return;
      try {
        Object.keys(localStorage).forEach(function (k) {
          if (k.indexOf('pfa_ttl_cache_v1_') === 0) localStorage.removeItem(k);
        });
      } catch (e) {}
      window.location.reload();
    };

    if (bsModal) bsModal.show();
  }

  function openCompactAboutModal() {
    var modalId = 'pfaCompactAboutModal';
    var existing = document.getElementById(modalId);
    if (existing) existing.remove();

    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">' +
        '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
          '<div class="modal-content rounded-4 border-0 shadow">' +
            '<div class="modal-header border-0 pb-1">' +
              '<h6 class="modal-title fw-bold"><i class="bi bi-info-circle-fill me-2 text-primary"></i>Tentang Aplikasi</h6>' +
              '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
            '</div>' +
            '<div class="modal-body pt-2">' +
              '<div class="p-3 rounded-4 mb-3 text-white" style="background:linear-gradient(135deg,#002850 0%,#003b73 60%,#0077b6 100%);">' +
                '<div class="fw-bold fs-6">PLN Field Assistant (PFA)</div>' +
                '<div class="small opacity-75">Versi 2.0.11 • PLN Corporate Pro</div>' +
                '<div class="small mt-2 pt-2 border-top border-light border-opacity-25">' +
                  'Pengembang: <strong>JODI SETIAWAN</strong><br>' +
                  'Unit: <strong>PLN ULP Pelabuhan Ratu</strong>' +
                '</div>' +
              '</div>' +
              '<div class="d-grid gap-2">' +
                '<button type="button" class="btn btn-primary fw-semibold" id="pfaAboutFeedbackBtn">' +
                  '<i class="bi bi-chat-heart-fill me-1"></i> Lapor Kendala / Kirim Saran' +
                '</button>' +
                '<button type="button" class="btn btn-outline-secondary btn-sm fw-semibold" id="pfaAboutChangelogBtn">' +
                  '<i class="bi bi-clock-history me-1"></i> Lihat Riwayat Rilis' +
                '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(wrap.firstElementChild);
    var modalEl = document.getElementById(modalId);
    var bsModal = window.bootstrap && window.bootstrap.Modal ? window.bootstrap.Modal.getOrCreateInstance(modalEl) : null;

    document.getElementById('pfaAboutFeedbackBtn').onclick = function () {
      if (bsModal) bsModal.hide();
      setTimeout(function () {
        var origFb = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="feedback"]');
        if (origFb) origFb.click();
      }, 220);
    };

    document.getElementById('pfaAboutChangelogBtn').onclick = function () {
      if (bsModal) bsModal.hide();
      setTimeout(function () {
        var origRel = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="release"]');
        if (origRel) origRel.click();
      }, 220);
    };

    if (bsModal) bsModal.show();
  }

  function compactTopDropdownMenu() {
    var menuUl = document.querySelector('#appScreen .topbar-pln .dropdown-menu');
    if (!menuUl) return;

    var lis = Array.prototype.slice.call(menuUl.children);
    lis.forEach(function (li) {
      var btn = li.querySelector('button');
      if (!btn) return;
      var txt = String(btn.textContent || '').toLowerCase();
      var onclk = String(btn.getAttribute('onclick') || '').toLowerCase();

      // Tandai tombol asli lalu sembunyikan item yang dipindah ke Pengaturan & Tentang
      if (txt.indexOf('ukuran teks') !== -1) { btn.setAttribute('data-pfa-orig', 'font'); li.classList.add('d-none'); }
      else if (txt.indexOf('segarkan sesi') !== -1) { btn.setAttribute('data-pfa-orig', 'session'); li.classList.add('d-none'); }
      else if (txt.indexOf('cek update') !== -1) { btn.setAttribute('data-pfa-orig', 'update'); li.classList.add('d-none'); }
      else if (txt.indexOf('lapor kendala') !== -1 || txt.indexOf('masukan') !== -1) { btn.setAttribute('data-pfa-orig', 'feedback'); li.classList.add('d-none'); }
      else if (txt.indexOf('riwayat rilis') !== -1) { btn.setAttribute('data-pfa-orig', 'release'); li.classList.add('d-none'); }
      else if (txt.indexOf('tema:') !== -1 || txt.indexOf('channel beta') !== -1 || txt.indexOf('tentang aplikasi') !== -1 || onclk.indexOf("switchtab('tutorial')") !== -1) {
        li.classList.add('d-none');
      }
    });

    var divider = menuUl.querySelector('.dropdown-divider');
    var anchorLi = divider ? divider.closest('li') : menuUl.lastElementChild;

    if (menuUl.querySelector('[data-pfa-compact-item="settings"]')) return;
    var setLi = document.createElement('li');
    setLi.setAttribute('data-pfa-compact-item', 'settings');
    setLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2">' +
        '<i class="bi bi-sliders2 me-2 text-primary"></i> Pengaturan &amp; Sistem' +
      '</button>';
    setLi.querySelector('button').addEventListener('click', openCompactSettingsModal);

    var aboutLi = document.createElement('li');
    aboutLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2">' +
        '<i class="bi bi-info-circle-fill me-2 text-info"></i> Tentang Aplikasi' +
      '</button>';
    aboutLi.querySelector('button').addEventListener('click', openCompactAboutModal);

    if (anchorLi && anchorLi.parentNode) {
      anchorLi.parentNode.insertBefore(setLi, anchorLi);
      anchorLi.parentNode.insertBefore(aboutLi, anchorLi);
    } else {
      menuUl.appendChild(setLi);
      menuUl.appendChild(aboutLi);
    }
    menuUl.setAttribute('data-pfa-compacted', '1');
  }

  window.addEventListener('load', function () {
    setTimeout(compactTopDropdownMenu, 650);
    setTimeout(compactTopDropdownMenu, 1800);
    var menuToggleBtn = document.querySelector('#appScreen .topbar-pln button[data-bs-toggle="dropdown"]');
    if (menuToggleBtn) {
      menuToggleBtn.addEventListener('click', function () {
        setTimeout(compactTopDropdownMenu, 10);
      });
    }
    setTimeout(syncPortalOddGrid, 500);
    setTimeout(syncPortalOddGrid, 1200);
  });

  if (typeof window.switchTab === 'function') {
    var origSw = window.switchTab;
    window.switchTab = function (t) {
      var r = origSw.apply(this, arguments);
      if (t === 'portal') setTimeout(syncPortalOddGrid, 120);
      return r;
    };
  }
})();
