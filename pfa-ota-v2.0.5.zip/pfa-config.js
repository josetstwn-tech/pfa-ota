/**
 * KONFIGURASI BACKEND GAS UNTUK APLIKASI ANDROID PFA v2.0
 * -------------------------------------------------------
 * Tempel URL Web App (/exec) dari Google Apps Script Anda di bawah ini,
 * lalu jalankan: npm run cap:sync
 */
window.PFA_CONFIG = {
    GAS_API_URL: 'https://script.google.com/macros/s/AKfycbwaqwRMeiqZ8sjHj_AD62hTH9sWLdnOCp5XoUUcrzn7c6zCuPN0jKz0sDYMpwkrIRqzCw/exec',
  APP_VERSION: '2.0.5',
  REQUEST_TIMEOUT_MS: 60000
};
