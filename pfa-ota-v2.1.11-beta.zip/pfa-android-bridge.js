/**
 * PFA Android Bridge v2.0.4 (29-Feature Field UX & Reliability Engine)
 * Pengembang: JODI SETIAWAN — PLN ULP Pelabuhan Ratu
 * Arsitektur: Event-driven (tanpa polling berat / anti-lag), modular, dan bebas bentrok antar-fitur.
 */
(function () {
  'use strict';

  var DEV_NAME = 'JODI SETIAWAN';
  var UNIT_NAME = 'PLN ULP Pelabuhan Ratu';
  var OFFLINE_DB_NAME = 'pfa_offline_queue_db';
  var OFFLINE_STORE = 'pending_submissions';
  var QUEUEABLE_ACTIONS = ['simpan_gangguan', 'simpan_pengukuran', 'simpan_p2tl'];
  var WEAK_SIGNAL_PREF_KEY = 'pfa_weak_signal_mode_v1';
  var FONT_LARGE_PREF_KEY = 'pfa_font_large_v1';
  var LAST_SEEN_CHANGELOG_KEY = 'pfa_last_changelog_ver_v1';
  var LAST_SESSION_TOKEN = '';
  var IN_FLIGHT_KEYS = {};
  var LAST_BACK_TS = 0;
  var LOADING_SLOW_TIMER = null;
  var LAST_FAILED_RETRY_FN = null;
  var HAS_PENDING_UPDATE_BADGE = false;

  var CHANGELOG_NOTES = {
    '2.0.5': [
      'PFA AI Neon: Auto-lookup 3 sumber data sekaligus (DIL + Riwayat Gangguan + Cek KCT + MCB standar).',
      'Smart Model Router (Mode Auto / Cepat / Pro) + Cache instan untuk respon jauh lebih cepat.',
      'Tombol Mikrofon (Voice-to-Text Bahasa Indonesia), riwayat chat AI tersimpan di HP, & tombol Salin/Share WA di tiap jawaban AI.',
      'Tombol pintasan AI otomatis mengisi IDPEL ke modul Gangguan, Pengukuran, P2TL, atau Cek KCT.'
    ],
    '2.0.4': [
      'Menu Kirim Masukan / Lapor Kendala langsung ke Admin & Modal Tentang Aplikasi.',
      'Tombol Urungkan (Undo 5 detik) saat tidak sengaja menekan Reset formulir.',
      'Info Sisa Masa Sesi + tombol Segarkan Sesi & Pengaturan Ukuran Teks (Normal/Besar) di Menu ☰.',
      'Getar halus & bunyi bip saat scan barcode, ikon mata (👁️) password, & keyboard angka otomatis.',
      'Double-Back untuk keluar, tombol hapus cepat (×), auto-bersih paste IDPEL, & Enter langsung cari.',
      'Tap-to-Zoom semua foto, konfirmasi hapus foto, auto-tutup keyboard, & tombol Batalkan jika sinyal hang >20 detik.'
    ]
  };

  function isCapacitorNative() {
    return typeof window.Capacitor !== 'undefined' &&
      typeof window.Capacitor.isNativePlatform === 'function' &&
      window.Capacitor.isNativePlatform();
  }

  function getApiUrl() {
    var customUrl = '';
    try { customUrl = String(localStorage.getItem('pfa_custom_api_url') || '').trim(); } catch (e) {}
    if (customUrl) return customUrl;
    return (window.PFA_CONFIG && window.PFA_CONFIG.GAS_API_URL) ? String(window.PFA_CONFIG.GAS_API_URL).trim() : '';
  }

  function isApiUrlConfigured(url) {
    return Boolean(url && url.indexOf('https://script.google.com/macros/s/') === 0 && url.indexOf('PASTE_DEPLOYMENT_ID') === -1);
  }

  function getSessionObj() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return null;
  }

  function getActiveSessionToken() {
    if (LAST_SESSION_TOKEN) return LAST_SESSION_TOKEN;
    var s = getSessionObj();
    if (s && s.sessionToken) {
      LAST_SESSION_TOKEN = String(s.sessionToken).trim();
      return LAST_SESSION_TOKEN;
    }
    return '';
  }

  function escText(v) {
    if (typeof window.escHtml === 'function') return window.escHtml(v);
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatGroupedDigits(val) {
    var s = String(val || '').trim();
    if (!s || !/^\d{8,16}$/.test(s)) return s || '-';
    return s.replace(/(\d{4})(?=\d)/g, '$1 ');
  }

  function formatBytesKB(bytes) {
    if (!bytes || bytes <= 0) return '0 KB';
    var kb = bytes / 1024;
    return kb >= 1024 ? (kb / 1024).toFixed(2) + ' MB' : Math.round(kb) + ' KB';
  }

  function estimateBase64Bytes(dataUrl) {
    if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image/') !== 0) return 0;
    var commaIdx = dataUrl.indexOf(',');
    var b64Len = commaIdx !== -1 ? (dataUrl.length - commaIdx - 1) : dataUrl.length;
    return Math.floor(b64Len * 0.75);
  }

  function hideMobileKeyboard() {
    try {
      if (document.activeElement && typeof document.activeElement.blur === 'function') {
        document.activeElement.blur();
      }
    } catch (e) {}
  }

  // --- [Fitur] Haptic Feedback (Getar Halus) & Bunyi Bip Barcode ---
  function triggerHaptic(pattern) {
    try {
      if (navigator.vibrate) navigator.vibrate(pattern || 45);
    } catch (e) {}
  }

  function playBarcodeBeep() {
    try {
      var AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      var ctx = new AudioCtx();
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1320, ctx.currentTime);
      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.09);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.095);
      setTimeout(function () { try { ctx.close(); } catch (e2) {} }, 180);
    } catch (e) {}
  }

  // --- [Fitur] Pengaturan Ukuran Teks (Normal / Besar) ---
  function applyFontScalePref() {
    var isLarge = false;
    try { isLarge = localStorage.getItem(FONT_LARGE_PREF_KEY) === '1'; } catch (e) {}
    document.documentElement.classList.toggle('pfa-font-large', isLarge);
    var lbl = document.getElementById('pfaFontScaleBadge');
    if (lbl) lbl.textContent = isLarge ? 'Besar' : 'Normal';
  }

  window.togglePfaFontScale = function () {
    var next = !document.documentElement.classList.contains('pfa-font-large');
    try { localStorage.setItem(FONT_LARGE_PREF_KEY, next ? '1' : '0'); } catch (e) {}
    applyFontScalePref();
    if (typeof window.showToast === 'function') {
      window.showToast(next ? 'Ukuran teks diubah ke mode Besar.' : 'Ukuran teks kembali ke Normal.', 'info');
    }
  };

  // --- [Fitur] Mode Sinyal Lemah & Kompresi Foto Adaptif ---
  function isAutoWeakNetwork() {
    if (navigator.onLine === false) return true;
    var conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if (conn) {
      var eff = String(conn.effectiveType || '').toLowerCase();
      if (eff === 'slow-2g' || eff === '2g' || eff === '3g' || conn.saveData) return true;
    }
    return false;
  }

  function isWeakSignalModeActive() {
    try {
      var pref = localStorage.getItem(WEAK_SIGNAL_PREF_KEY);
      if (pref === '1') return true;
      if (pref === '0') return false;
    } catch (e) {}
    return isAutoWeakNetwork();
  }

  function setWeakSignalPref(val) {
    try {
      if (val === null) localStorage.removeItem(WEAK_SIGNAL_PREF_KEY);
      else localStorage.setItem(WEAK_SIGNAL_PREF_KEY, val ? '1' : '0');
    } catch (e) {}
    renderWeakSignalBar();
    schedulePhotoSizeUpdate();
  }

  function compressDataUrl(dataUrl, maxDim, quality) {
    return new Promise(function (resolve) {
      if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image/') !== 0 || dataUrl.length < 120000) {
        resolve(dataUrl);
        return;
      }
      var img = new Image();
      img.onload = function () {
        try {
          var w = img.naturalWidth || img.width;
          var h = img.naturalHeight || img.height;
          if (!w || !h) { resolve(dataUrl); return; }
          var scale = Math.min(1, maxDim / Math.max(w, h));
          var nw = Math.max(1, Math.round(w * scale));
          var nh = Math.max(1, Math.round(h * scale));
          var canvas = document.createElement('canvas');
          canvas.width = nw;
          canvas.height = nh;
          canvas.getContext('2d').drawImage(img, 0, 0, nw, nh);
          var out = canvas.toDataURL('image/jpeg', quality);
          resolve(out && out.length < dataUrl.length ? out : dataUrl);
        } catch (e) { resolve(dataUrl); }
      };
      img.onerror = function () { resolve(dataUrl); };
      img.src = dataUrl;
    });
  }

  function compressPayloadPhotos(payload) {
    if (!payload || !payload.fotos || typeof payload.fotos !== 'object') return Promise.resolve(payload);
    var weak = isWeakSignalModeActive();
    var isP2tlAct = payload && payload.action === 'simpan_p2tl';
    var maxDim = weak ? 800 : (isP2tlAct ? 1100 : 1280);
    var quality = weak ? 0.55 : (isP2tlAct ? 0.76 : 0.78);
    var fotosCopy = Object.assign({}, payload.fotos);
    var tasks = [];

    Object.keys(fotosCopy).forEach(function (k) {
      var val = fotosCopy[k];
      if (typeof val === 'string' && val.indexOf('data:image/') === 0 && k !== 'foto_grid') {
        tasks.push(compressDataUrl(val, maxDim, quality).then(function (res) { fotosCopy[k] = res; }));
      } else if (Array.isArray(val)) {
        var arrCopy = val.map(function (it) { return it && typeof it === 'object' ? Object.assign({}, it) : it; });
        fotosCopy[k] = arrCopy;
        arrCopy.forEach(function (item, idx) {
          if (item && typeof item.base64 === 'string' && item.base64.indexOf('data:image/') === 0) {
            tasks.push(compressDataUrl(item.base64, maxDim, quality).then(function (res) { arrCopy[idx].base64 = res; }));
          }
        });
      }
    });

    return Promise.all(tasks).then(function () { return Object.assign({}, payload, { fotos: fotosCopy }); });
  }


  function countPayloadPhotos(fotos) {
    var count = 0;
    var bytes = 0;
    if (!fotos || typeof fotos !== 'object') return { count: 0, bytes: 0 };
    Object.keys(fotos).forEach(function (k) {
      var val = fotos[k];
      if (typeof val === 'string' && val.indexOf('data:image/') === 0 && k !== 'foto_grid') {
        count++; bytes += estimateBase64Bytes(val);
      } else if (Array.isArray(val)) {
        val.forEach(function (it) {
          if (it && typeof it.base64 === 'string' && it.base64.indexOf('data:image/') === 0) {
            count++; bytes += estimateBase64Bytes(it.base64);
          }
        });
      }
    });
    return { count: count, bytes: bytes };
  }

  function renderWeakSignalBar() {
    var container = document.querySelector('#appScreen .container');
    if (!container) return;
    var bar = document.getElementById('pfaWeakSignalBar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'pfaWeakSignalBar';
      bar.className = 'd-flex justify-content-between align-items-center mb-2 px-2 py-1 rounded-3 border bg-white';
      container.insertBefore(bar, container.firstChild);
    }
    var active = isWeakSignalModeActive();
    var offline = navigator.onLine === false;
    var badgeHtml = offline
      ? '<span class="badge text-bg-danger me-1">Offline</span>'
      : (active ? '<span class="badge text-bg-warning text-dark me-1">Hemat Sinyal</span>' : '<span class="badge text-bg-success me-1">Normal</span>');

    bar.innerHTML =
      '<div class="d-flex align-items-center text-truncate">' +
      badgeHtml +
      '<span class="text-muted text-truncate">' + (active ? 'Kompresi foto aktif (ringan)' : 'Kualitas foto standar') + '</span>' +
      '</div>' +
      '<button type="button" class="btn btn-sm py-0 px-2 ' + (active ? 'btn-warning' : 'btn-outline-secondary') + '" id="btnToggleWeakSignal">' +
      (active ? 'Matikan Hemat' : 'Mode Sinyal Lemah') +
      '</button>';

    var btn = document.getElementById('btnToggleWeakSignal');
    if (btn) {
      btn.onclick = function () {
        setWeakSignalPref(!active);
        if (typeof window.showToast === 'function') {
          window.showToast(!active ? 'Mode Sinyal Lemah aktif: foto otomatis dikompres lebih ringan.' : 'Kembali ke kualitas foto standar.', 'info');
        }
      };
    }
  }

  // --- [Fitur] Indikator Offline di Halaman Login ---
  function renderLoginOfflineBanner() {
    var loginScreen = document.getElementById('loginScreen');
    if (!loginScreen) return;
    var form = loginScreen.querySelector('form');
    if (!form) return;
    var el = document.getElementById('pfaLoginOfflineAlert');
    if (!el) {
      el = document.createElement('div');
      el.id = 'pfaLoginOfflineAlert';
      el.className = 'alert alert-danger py-2 px-3 small rounded-3 mb-3 d-none';
      el.innerHTML = '<i class="bi bi-wifi-off me-1 fw-bold"></i> Perangkat sedang <strong>offline</strong>. Aktifkan data seluler atau Wi-Fi untuk login.';
      form.parentNode.insertBefore(el, form);
    }
    el.classList.toggle('d-none', navigator.onLine !== false);
  }

  // --- [Fitur] Indikator Live Total Ukuran Foto (Debounced, Tanpa Polling!) ---
  var PHOTO_BTN_TARGETS = [
    { tabId: 'tab-gangguan', btnSel: '#gangguanForm button[type="submit"]' },
    { tabId: 'tab-pengukuran', btnSel: 'button[onclick*="simpanHasilPengukuran"]' },
    { tabId: 'tab-p2tl', btnSel: '#p2tlForm button[type="submit"]' }
  ];
  var photoSizeDebounceTimer = null;

  function updateAllPhotoSizeIndicators() {
    var weak = isWeakSignalModeActive();
    PHOTO_BTN_TARGETS.forEach(function (cfg) {
      var btn = document.querySelector(cfg.btnSel);
      var tabEl = document.getElementById(cfg.tabId);
      if (!btn || !tabEl) return;
      var count = 0;
      var bytes = 0;
      var hiddenInputs = tabEl.querySelectorAll('input[type="hidden"]');
      for (var i = 0; i < hiddenInputs.length; i++) {
        var v = hiddenInputs[i].value || '';
        if (v.indexOf('data:image/') === 0) {
          count++;
          bytes += estimateBase64Bytes(v);
        }
      }
      var estBytes = weak ? Math.round(bytes * 0.45) : Math.round(bytes * 0.78);
      var suffix = count > 0 ? ' • ' + count + ' foto (~' + formatBytesKB(estBytes) + ')' : '';
      var span = btn.querySelector('.pfa-upload-meta');
      if (!span) {
        span = document.createElement('span');
        span.className = 'pfa-upload-meta fw-normal';
        span.style.fontSize = '0.82em';
        btn.appendChild(span);
      }
      span.textContent = suffix;
    });
  }

  function schedulePhotoSizeUpdate() {
    clearTimeout(photoSizeDebounceTimer);
    photoSizeDebounceTimer = setTimeout(updateAllPhotoSizeIndicators, 220);
  }

  // --- [Fitur] Layar Ringkasan Konfirmasi (Review Before Submit) ---
  function buildReviewRowsHtml(action, dataObj, photoStats) {
    var d = dataObj || {};
    var rows = [];
    if (action === 'simpan_gangguan') {
      rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
      rows.push(['Nama Pelanggan', d.nama_pelanggan || d.nama || '-']);
      rows.push(['No. Form DG', d.no_form_dg || '-']);
      rows.push(['Status TL', d.status_tindak_lanjut || d.status_tl || '-']);
      rows.push(['No. Meter Lama', formatGroupedDigits(d.no_meter_lama)]);
      if (d.no_meter_baru) rows.push(['No. Meter Baru', formatGroupedDigits(d.no_meter_baru)]);
      if (d.no_segel_baru) rows.push(['No. Segel Baru', d.no_segel_baru]);
      if (d.sisa_kwh) rows.push(['Sisa kWh', d.sisa_kwh]);
      rows.push(['Sebab Kerusakan', d.sebab_kerusakan || '-']);
    } else if (action === 'simpan_pengukuran') {
      rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
      rows.push(['Nama Pelanggan', d.nama_pelanggan || d.nama || '-']);
      if (d.no_meter) rows.push(['No. Meter', formatGroupedDigits(d.no_meter)]);
      if (d.deviasi_kwh != null && d.deviasi_kwh !== '') rows.push(['Deviasi kWh', d.deviasi_kwh + ' %']);
      if (d.fkm) rows.push(['FKM', d.fkm]);
      if (d.petugas) rows.push(['Petugas', d.petugas]);
    } else if (action === 'simpan_p2tl') {
      rows.push(['Kategori', d.kategori_temuan || d.kategori_pelanggan || d.kategori || '-']);
      if (d.id_pelanggan || d.idpel) rows.push(['ID Pelanggan', formatGroupedDigits(d.id_pelanggan || d.idpel)]);
      rows.push(['Nama', d.nama_pelanggan || d.nama || '-']);
      if (d.golongan_pelanggaran || d.golongan_temuan) rows.push(['Golongan / Jenis', (d.golongan_pelanggaran || d.golongan_temuan) + (d.jenis_temuan ? (' (' + d.jenis_temuan + ')') : '')]);
      if (d.kwh_kedapatan) rows.push(['kWh Kedapatan', d.kwh_kedapatan + ' kWh']);
      if (d.rupiah_ts || d.total_tagihan) rows.push(['Estimasi TS', 'Rp ' + Number(d.rupiah_ts || d.total_tagihan || 0).toLocaleString('id-ID')]);
      if (d.status_penertiban) rows.push(['Penertiban', d.status_penertiban]);
    }
    var modeLbl = isWeakSignalModeActive() ? 'Mode Sinyal Lemah' : 'Standar';
    rows.push(['Lampiran Foto', photoStats.count + ' foto (' + formatBytesKB(photoStats.bytes) + ' • ' + modeLbl + ')']);

    return rows.map(function (r) {
      return '<div class="d-flex justify-content-between gap-2 py-1 border-bottom">' +
        '<span class="text-muted">' + escText(r[0]) + '</span>' +
        '<strong class="text-end text-dark" style="word-break:break-word;">' + escText(r[1]) + '</strong>' +
      '</div>';
    }).join('');
  }

  function showReviewBeforeSubmitModal(payload) {
    return new Promise(function (resolve) {
      var old = document.getElementById('pfaReviewSubmitModal');
      if (old) old.remove();
      var titleMap = {
        simpan_gangguan: 'Cek Ulang Laporan Gangguan',
        simpan_pengukuran: 'Cek Ulang Hasil Pengukuran',
        simpan_p2tl: 'Cek Ulang Data P2TL / K2'
      };
      var photoStats = countPayloadPhotos(payload.fotos);
      var rowsHtml = buildReviewRowsHtml(payload.action, payload.data, photoStats);
      var offlineWarn = navigator.onLine === false
        ? '<div class="alert alert-warning py-1 px-2 small mt-2 mb-0"><i class="bi bi-wifi-off me-1"></i>Sedang offline: laporan akan disimpan ke <strong>Antrean Offline</strong>.</div>'
        : '';

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="pfaReviewSubmitModal" tabindex="-1" data-bs-backdrop="static">' +
        '  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
        '    <div class="modal-content rounded-4 border-0 shadow">' +
        '      <div class="modal-header bg-primary text-white py-2">' +
        '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-clipboard-check-fill me-1"></i> ' + escText(titleMap[payload.action] || 'Konfirmasi Kirim Data') + '</h6>' +
        '        <button type="button" class="btn-close btn-close-white" id="btnRevCloseX" aria-label="Batal"></button>' +
        '      </div>' +
        '      <div class="modal-body small">' +
        '        <p class="text-muted mb-2">Pastikan IDPEL, nomor meter, dan foto sudah sesuai sebelum dikirim:</p>' +
        '        <div class="px-2 py-1 rounded-3 bg-light border">' + rowsHtml + '</div>' +
                 offlineWarn +
        '      </div>' +
        '      <div class="modal-footer py-2 d-flex justify-content-between gap-2">' +
        '        <button type="button" class="btn btn-outline-secondary btn-sm flex-grow-1" id="btnRevCancel"><i class="bi bi-pencil-square me-1"></i> Kembali Edit</button>' +
        '        <button type="button" class="btn btn-success btn-sm fw-semibold flex-grow-1" id="btnRevConfirm"><i class="bi bi-send-check-fill me-1"></i> Ya, Kirim Sekarang</button>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>';

      document.body.appendChild(wrap.firstChild);
      var modalEl = document.getElementById('pfaReviewSubmitModal');
      var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
      function done(ok) {
        if (inst) inst.hide();
        modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); resolve(ok); }, { once: true });
        if (!inst) { modalEl.remove(); resolve(ok); }
      }
      document.getElementById('btnRevConfirm').onclick = function () { done(true); };
      document.getElementById('btnRevCancel').onclick = function () { done(false); };
      document.getElementById('btnRevCloseX').onclick = function () { done(false); };
      if (typeof window.setLoading === 'function') window.setLoading(false);
      if (inst) inst.show(); else resolve(true);
    });
  }

  // --- [Fitur] Peringatan Keluar Form Belum Disimpan + Lencana Draft Bottom Nav + Auto-Scroll Atas + Animasi Tab ---
  var DIRTY_FORM_TABS = { gangguan: false, pengukuran: false, p2tl: false };

  function getActiveVisibleTabName() {
    var tabs = ['gangguan', 'pengukuran', 'p2tl', 'portal', 'kct', 'material', 'chatbot', 'tutorial', 'admin'];
    for (var i = 0; i < tabs.length; i++) {
      var el = document.getElementById('tab-' + tabs[i]);
      if (el && !el.classList.contains('d-none')) return tabs[i];
    }
    return 'portal';
  }

  function updateBottomNavDraftDots() {
    ['gangguan', 'pengukuran'].forEach(function (t) {
      var nav = document.getElementById('nav-' + t);
      if (!nav) return;
      var hasDraft = Boolean(DIRTY_FORM_TABS[t]);
      if (t === 'gangguan') {
        try { if (localStorage.getItem('pfa_gangguan_draft_v1')) hasDraft = true; } catch (e) {}
      }
      nav.classList.toggle('pfa-has-draft', hasDraft);
    });
  }

  function markTabDirty(tabName, isDirty) {
    if (Object.prototype.hasOwnProperty.call(DIRTY_FORM_TABS, tabName)) {
      DIRTY_FORM_TABS[tabName] = Boolean(isDirty);
      updateBottomNavDraftDots();
    }
  }

  function confirmLeaveDirtyForm(currentTabName) {
    return new Promise(function (resolve) {
      var old = document.getElementById('pfaUnsavedLeaveModal');
      if (old) old.remove();
      var labelMap = { gangguan: 'Gangguan', pengukuran: 'Pengukuran', p2tl: 'P2TL / K2' };
      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="pfaUnsavedLeaveModal" tabindex="-1">' +
        '  <div class="modal-dialog modal-dialog-centered">' +
        '    <div class="modal-content rounded-4 border-0 shadow">' +
        '      <div class="modal-header bg-warning text-dark py-2">' +
        '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-exclamation-circle-fill me-1"></i> Formulir Belum Disimpan</h6>' +
        '      </div>' +
        '      <div class="modal-body small">' +
        '        Anda memiliki isian pada formulir <strong>' + escText(labelMap[currentTabName] || currentTabName) + '</strong> yang belum dikirim. Tetap keluar dari halaman ini?' +
        '      </div>' +
        '      <div class="modal-footer py-2">' +
        '        <button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnStayForm">Tetap di Formulir</button>' +
        '        <button type="button" class="btn btn-outline-danger btn-sm" id="btnLeaveForm">Keluar</button>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>';
      document.body.appendChild(wrap.firstChild);
      var modalEl = document.getElementById('pfaUnsavedLeaveModal');
      var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
      var resolved = false;
      function finish(leave) {
        if (resolved) return;
        resolved = true;
        if (inst) inst.hide();
        modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); resolve(leave); }, { once: true });
        if (!inst) { modalEl.remove(); resolve(leave); }
      }
      document.getElementById('btnStayForm').onclick = function () { finish(false); };
      document.getElementById('btnLeaveForm').onclick = function () { finish(true); };
      modalEl.addEventListener('hidden.bs.modal', function () {
        if (!resolved) { resolved = true; modalEl.remove(); resolve(false); }
      }, { once: true });
      if (inst) inst.show(); else resolve(true);
    });
  }

  function wrapSwitchTabWithEnhancements() {
    if (typeof window.switchTab !== 'function' || window._pfaSwitchTabWrapped) return;
    window._pfaSwitchTabWrapped = true;
    var origSwitchTab = window.switchTab;
    window.switchTab = function (nextTab) {
      hideMobileKeyboard();
      var curTab = getActiveVisibleTabName();
      function proceed() {
        origSwitchTab(nextTab);
        // Auto-scroll halus ke atas & animasi masuk tab
        try { window.scrollTo({ top: 0, behavior: 'instant' }); } catch (e) { window.scrollTo(0, 0); }
        var targetEl = document.getElementById('tab-' + nextTab);
        if (targetEl) {
          targetEl.classList.remove('pfa-tab-enter');
          void targetEl.offsetWidth;
          targetEl.classList.add('pfa-tab-enter');
        }
        schedulePhotoSizeUpdate();
      }
      if (curTab !== nextTab && DIRTY_FORM_TABS[curTab]) {
        confirmLeaveDirtyForm(curTab).then(function (leave) {
          if (leave) {
            markTabDirty(curTab, false);
            proceed();
          }
        });
        return;
      }
      proceed();
    };
  }

  // --- [Fitur] Tombol Urungkan (Undo 5 Detik) Saat Reset Formulir ---
  var undoResetTimer = null;
  function captureFormSnapshot(container) {
    var snap = [];
    if (!container) return snap;
    var fields = container.querySelectorAll('input, select, textarea');
    for (var i = 0; i < fields.length; i++) {
      var f = fields[i];
      if (!f.id || f.type === 'file') continue;
      snap.push({ id: f.id, type: f.type, value: f.value, checked: f.checked });
    }
    return snap;
  }

  function showUndoResetToast(snapshot, tabName) {
    if (!snapshot || !snapshot.length) return;
    var hasAnyVal = snapshot.some(function (it) { return it.value && String(it.value).trim() !== ''; });
    if (!hasAnyVal) return;

    var old = document.getElementById('pfaUndoResetBar');
    if (old) old.remove();
    clearTimeout(undoResetTimer);

    var bar = document.createElement('div');
    bar.id = 'pfaUndoResetBar';
    bar.className = 'alert alert-dark d-flex justify-content-between align-items-center py-2 px-3 rounded-4 shadow-lg mb-0';
    bar.innerHTML =
      '<span class="small"><i class="bi bi-arrow-counterclockwise me-1"></i> Formulir direset.</span>' +
      '<button type="button" class="btn btn-warning btn-sm fw-bold py-0 px-2" id="btnPfaUndoReset">Urungkan</button>';
    document.body.appendChild(bar);

    document.getElementById('btnPfaUndoReset').onclick = function () {
      clearTimeout(undoResetTimer);
      snapshot.forEach(function (it) {
        var el = document.getElementById(it.id);
        if (!el) return;
        if (it.type === 'checkbox' || it.type === 'radio') el.checked = it.checked;
        else el.value = it.value;
      });
      if (tabName) markTabDirty(tabName, true);
      schedulePhotoSizeUpdate();
      bar.remove();
      if (typeof window.showToast === 'function') window.showToast('Isian formulir dikembalikan.', 'success');
    };

    undoResetTimer = setTimeout(function () { if (bar.parentNode) bar.remove(); }, 5500);
  }

  // --- [Fitur] Hook Loading Overlay: Tombol Batalkan Jika Sinyal Hang >20 Detik ---
  function wrapSetLoadingWithSlowCancel() {
    if (typeof window.setLoading !== 'function' || window._pfaLoadingWrapped) return;
    window._pfaLoadingWrapped = true;
    var origSetLoading = window.setLoading;
    window.setLoading = function (show, text) {
      origSetLoading(show, text);
      clearTimeout(LOADING_SLOW_TIMER);
      var cancelBtn = document.getElementById('pfaSlowCancelBtn');
      if (!show) {
        if (cancelBtn) cancelBtn.classList.add('d-none');
        return;
      }
      var overlay = document.getElementById('loadingOverlay');
      if (overlay && !cancelBtn) {
        cancelBtn = document.createElement('button');
        cancelBtn.id = 'pfaSlowCancelBtn';
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn btn-sm btn-outline-light mt-3 d-none';
        cancelBtn.innerHTML = '<i class="bi bi-x-circle me-1"></i> Sinyal lambat — Batalkan Tunggu';
        cancelBtn.onclick = function () {
          origSetLoading(false);
          cancelBtn.classList.add('d-none');
          if (typeof window.showToast === 'function') {
            window.showToast('Layar tunggu ditutup. Anda bisa coba lagi atau aktifkan Mode Sinyal Lemah.', 'warning');
          }
        };
        var box = overlay.querySelector('.text-center') || overlay;
        box.appendChild(cancelBtn);
      }
      LOADING_SLOW_TIMER = setTimeout(function () {
        var btnNow = document.getElementById('pfaSlowCancelBtn');
        if (btnNow && overlay && overlay.style.display !== 'none') {
          btnNow.classList.remove('d-none');
        }
      }, 20000);
    };
  }

  // --- [Fitur] Tap-to-Zoom Lightbox Universal untuk Semua Foto ---
  function openPhotoZoomLightbox(imgSrc) {
    if (!imgSrc) return;
    var old = document.getElementById('pfaPhotoZoomModal');
    if (old) old.remove();
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaPhotoZoomModal" tabindex="-1">' +
      '  <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">' +
      '    <div class="modal-content bg-dark text-white border-0">' +
      '      <div class="modal-header border-0 py-2">' +
      '        <h6 class="modal-title small mb-0"><i class="bi bi-zoom-in me-1"></i> Pratinjau Foto</h6>' +
      '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
      '      </div>' +
      '      <div class="modal-body d-flex align-items-center justify-content-center p-2" style="overflow:auto;">' +
      '        <img src="' + escText(imgSrc) + '" style="max-width:100%; max-height:80vh; object-fit:contain; border-radius:8px;" alt="Zoom Foto">' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var modalEl = document.getElementById('pfaPhotoZoomModal');
    var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
    modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); }, { once: true });
    if (inst) inst.show();
  }

  // --- [Fitur] Sapaan Otomatis Sesuai Jam di Portal ---
  function injectPortalGreeting() {
    var portal = document.getElementById('tab-portal');
    if (!portal || document.getElementById('pfaPortalGreeting')) return;
    var h = new Date().getHours();
    var salam = h < 11 ? 'Selamat Pagi' : (h < 15 ? 'Selamat Siang' : (h < 18 ? 'Selamat Sore' : 'Selamat Malam'));
    var s = getSessionObj();
    var nama = (s && s.user && s.user.nama) ? s.user.nama : 'Petugas';
    var tgl = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    var box = document.createElement('div');
    box.id = 'pfaPortalGreeting';
    box.className = 'd-flex justify-content-between align-items-center flex-wrap gap-1 px-3 py-2 mb-2 rounded-3 bg-white border';
    box.innerHTML =
      '<div class="small fw-semibold text-dark">' + escText(salam) + ', <span class="text-primary">' + escText(nama) + '</span></div>' +
      '<div class="text-muted" style="font-size:0.74rem;">' + escText(tgl) + '</div>';
    portal.insertBefore(box, portal.firstChild);
  }

  // --- [Fitur] Kartu Panduan Khusus Android di Tab Tutorial ---
  function injectAndroidTutorialCard() {
    var tut = document.getElementById('tab-tutorial');
    if (!tut || document.getElementById('pfaAndroidTutCard')) return;
    var card = document.createElement('div');
    card.id = 'pfaAndroidTutCard';
    card.className = 'card card-modern border-primary border-opacity-25 mb-3';
    card.innerHTML =
      '<div class="card-body py-3">' +
      '  <div class="d-flex align-items-center gap-2 mb-2">' +
      '    <span class="badge text-bg-primary">Khusus Aplikasi Android</span>' +
      '    <strong class="small text-dark">Panduan Cepat Fitur Lapangan</strong>' +
      '  </div>' +
      '  <ul class="small text-muted ps-3 mb-0">' +
      '    <li class="mb-1"><strong>Antrean Offline:</strong> Saat blankspot, tetap tekan Simpan—data &amp; foto aman di HP lalu kirim lewat banner biru saat sinyal kembali.</li>' +
      '    <li class="mb-1"><strong>Mode Sinyal Lemah:</strong> Aktifkan tombol di atas layar agar foto otomatis dikompres lebih ringan dan cepat terunggah.</li>' +
      '    <li class="mb-1"><strong>Update Otomatis &amp; Lapor Kendala:</strong> Buka menu <strong>☰</strong> di pojok kanan atas untuk Cek Update, perpanjang sesi, atau kirim masukan ke pengembang.</li>' +
      '    <li><strong>Ketuk Foto untuk Zoom:</strong> Ketuk foto pratinjau mana saja untuk memperbesar dan memeriksa kejelasan angka meter.</li>' +
      '  </ul>' +
      '</div>';
    tut.insertBefore(card, tut.firstChild);
  }

  // --- [Fitur] Ikon Mata Password, Keyboard Angka Otomatis, Tombol Clear (x), & Enter Langsung Cari ---
  function enhanceInputsUniversal() {
    // 1. Ikon Mata (👁️) pada semua input password (Login & Ganti Password)
    var passInputs = document.querySelectorAll('input[type="password"]');
    for (var i = 0; i < passInputs.length; i++) {
      (function (inp) {
        if (inp.dataset.pfaEyeBound) return;
        inp.dataset.pfaEyeBound = '1';
        var parent = inp.parentElement;
        if (!parent) return;
        if (!parent.classList.contains('input-group')) {
          var grp = document.createElement('div');
          grp.className = 'input-group';
          parent.insertBefore(grp, inp);
          grp.appendChild(inp);
          parent = grp;
        }
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-outline-secondary';
        btn.title = 'Tampilkan/Sembunyikan Password';
        btn.innerHTML = '<i class="bi bi-eye"></i>';
        btn.onclick = function () {
          var show = inp.type === 'password';
          inp.type = show ? 'text' : 'password';
          btn.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
        };
        parent.appendChild(btn);
      })(passInputs[i]);
    }

    // 2. Keyboard Angka Besar Otomatis (inputmode="numeric") pada kolom angka IDPEL / Meter / HP / Stand
    var numericIds = [
      'cariPelangganInput', 'f_id_pelanggan', 'f_no_telepon', 'f_no_meter_lama',
      'f_no_meter_baru', 'f_no_pelapor', 'kctSearchInput', 'u_cari_pelanggan',
      'p2tl_cari_pelanggan', 'p2tl_idpel'
    ];
    numericIds.forEach(function (id) {
      var el = document.getElementById(id);
      if (el && el.tagName === 'INPUT') {
        el.setAttribute('inputmode', 'numeric');
        el.setAttribute('enterkeyhint', /cari|search/i.test(id) ? 'search' : 'next');
      }
    });

    // 3. Tombol Hapus Cepat (x) + Enter Langsung Cari pada kolom pencarian DIL & KCT
    var searchMap = [
      { id: 'cariPelangganInput', fnName: 'cariPelanggan' },
      { id: 'kctSearchInput', fnName: 'cariKct' },
      { id: 'u_cari_pelanggan', fnName: 'cariPelangganPengukuran' },
      { id: 'p2tl_cari_pelanggan', fnName: 'cariPelangganP2tl' }
    ];
    searchMap.forEach(function (cfg) {
      var inp = document.getElementById(cfg.id);
      if (!inp || inp.dataset.pfaSearchBound) return;
      inp.dataset.pfaSearchBound = '1';

      // Enter di keyboard HP langsung cari
      inp.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          hideMobileKeyboard();
          if (typeof window[cfg.fnName] === 'function') window[cfg.fnName]();
        }
      });

      // Tombol (x) di dalam input-group
      var grp = inp.closest('.input-group');
      if (grp) {
        var clrBtn = document.createElement('button');
        clrBtn.type = 'button';
        clrBtn.className = 'btn btn-outline-secondary pfa-clear-btn d-none';
        clrBtn.title = 'Hapus teks';
        clrBtn.innerHTML = '<i class="bi bi-x-lg"></i>';
        clrBtn.onclick = function () {
          inp.value = '';
          clrBtn.classList.add('d-none');
          inp.focus();
        };
        inp.addEventListener('input', function () {
          clrBtn.classList.toggle('d-none', !inp.value);
        });
        inp.parentNode.insertBefore(clrBtn, inp.nextSibling);
      }
    });
  }

  // --- [Fitur] Menu ☰ Lengkap (Cek Update, Sisa Sesi + Segarkan, Ukuran Teks, Lapor Kendala, Tentang Aplikasi + Badge Dot) ---
  function getSessionRemainingMinutes() {
    var s = getSessionObj();
    if (!s || !s.expiresAt) return 0;
    return Math.max(0, Math.round((Number(s.expiresAt) - Date.now()) / 60000));
  }

  function updateMenuNotificationDot() {
    var mins = getSessionRemainingMinutes();
    var sessionLow = mins > 0 && mins <= 45;
    var showDot = HAS_PENDING_UPDATE_BADGE || sessionLow;
    var menuBtn = document.querySelector('#appScreen .topbar-pln .dropdown > button');
    if (!menuBtn) return;
    menuBtn.classList.add('pfa-menu-btn-wrap');
    var dot = document.getElementById('pfaMenuAlertDot');
    if (showDot && !dot) {
      dot = document.createElement('span');
      dot.id = 'pfaMenuAlertDot';
      dot.className = 'pfa-menu-dot';
      menuBtn.appendChild(dot);
    } else if (!showDot && dot) {
      dot.remove();
    }
    var sessEl = document.getElementById('pfaSessionRemLabel');
    if (sessEl) {
      if (mins >= 60) sessEl.textContent = Math.floor(mins / 60) + 'j ' + (mins % 60) + 'm';
      else sessEl.textContent = mins + ' mnt';
      sessEl.className = 'badge ms-1 ' + (sessionLow ? 'text-bg-warning text-dark' : 'text-bg-light border');
    }
  }

  window.refreshPfaSessionNow = function () {
    var apiUrl = getApiUrl();
    if (!isApiUrlConfigured(apiUrl)) return;
    if (typeof window.setLoading === 'function') window.setLoading(true, 'Menyegarkan sesi login...');
    postToGas(apiUrl, { action: 'get_module_permissions', sessionToken: getActiveSessionToken() })
      .then(function (res) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (res && res.status === 'success') {
          var s = getSessionObj();
          if (s) {
            s.expiresAt = Date.now() + (6 * 60 * 60 * 1000);
            localStorage.setItem('pfa_session_v1', JSON.stringify(s));
          }
          updateMenuNotificationDot();
          if (typeof window.showToast === 'function') window.showToast('Sesi login diperpanjang (aktif 6 jam ke depan).', 'success');
        }
      })
      .catch(function (err) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (typeof window.showToast === 'function') window.showToast('Gagal segarkan sesi: ' + ((err && err.message) || err), 'danger');
      });
  };

  window.openPfaFeedbackModal = function () {
    var old = document.getElementById('pfaFeedbackModal');
    if (old) old.remove();
    var ver = getCurrentInstalledVersion();
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaFeedbackModal" tabindex="-1">' +
      '  <div class="modal-dialog modal-dialog-centered">' +
      '    <div class="modal-content rounded-4 border-0 shadow">' +
      '      <div class="modal-header bg-primary text-white py-2">' +
      '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-chat-square-heart-fill me-1"></i> Kirim Masukan / Lapor Kendala</h6>' +
      '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
      '      </div>' +
      '      <div class="modal-body small">' +
      '        <div class="mb-2">' +
      '          <label class="form-label fw-semibold mb-1">Kategori</label>' +
      '          <select id="pfaFbKat" class="form-select form-select-sm">' +
      '            <option value="Kendala / Bug">Kendala / Bug Aplikasi</option>' +
      '            <option value="Saran Fitur">Saran Fitur Baru</option>' +
      '            <option value="Data DIL / KCT">Masalah Data DIL / KCT</option>' +
      '          </select>' +
      '        </div>' +
      '        <div class="mb-2">' +
      '          <label class="form-label fw-semibold mb-1">Detail Kendala / Saran</label>' +
      '          <textarea id="pfaFbMsg" class="form-control form-control-sm" rows="4" placeholder="Jelaskan kendala atau saran fitur yang diinginkan..."></textarea>' +
      '        </div>' +
      '        <div class="text-muted" style="font-size:0.74rem;">Versi terlampir otomatis: <strong>v' + escText(ver) + '</strong></div>' +
      '      </div>' +
      '      <div class="modal-footer py-2">' +
      '        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Batal</button>' +
      '        <button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnSendPfaFeedback"><i class="bi bi-send-fill me-1"></i> Kirim ke Admin</button>' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var modalEl = document.getElementById('pfaFeedbackModal');
    var inst = bootstrap.Modal.getOrCreateInstance(modalEl);
    modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); }, { once: true });

    document.getElementById('btnSendPfaFeedback').onclick = function () {
      var msg = String(document.getElementById('pfaFbMsg').value || '').trim();
      var kat = document.getElementById('pfaFbKat').value;
      if (!msg) {
        if (typeof window.showToast === 'function') window.showToast('Tulis dulu detail masukan atau kendala.', 'warning');
        return;
      }
      var s = getSessionObj();
      var u = (s && s.user) || {};
      if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengirim masukan...');
      window.callApi({
        action: 'kirim_masukan_pfa',
        kategori: kat,
        pesan: msg,
        versi: ver,
        petugasNama: u.nama || '-',
        username: u.username || '-'
      }).then(function (res) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (res && res.status === 'success') {
          inst.hide();
          triggerHaptic(50);
          if (typeof window.showToast === 'function') window.showToast('Terima kasih! Masukan berhasil dikirim ke pengembang.', 'success');
        } else {
          if (typeof window.showToast === 'function') window.showToast((res && res.message) || 'Gagal mengirim masukan.', 'danger');
        }
      }).catch(function (err) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (typeof window.showToast === 'function') window.showToast('Gagal kirim masukan: ' + ((err && err.message) || err), 'danger');
      });
    };
    inst.show();
  };

  window.openPfaAboutModal = function () {
    var old = document.getElementById('pfaAboutModal');
    if (old) old.remove();
    var ver = getCurrentInstalledVersion();
    var nat = getNativeApkVersion();
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaAboutModal" tabindex="-1">' +
      '  <div class="modal-dialog modal-dialog-centered">' +
      '    <div class="modal-content rounded-4 border-0 shadow">' +
      '      <div class="modal-header text-white py-2" style="background:linear-gradient(135deg,#003b5c,#005b8f);">' +
      '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-info-circle-fill me-1"></i> Tentang Aplikasi PFA</h6>' +
      '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
      '      </div>' +
      '      <div class="modal-body small">' +
      '        <div class="text-center mb-3">' +
      '          <div class="fw-bold fs-6 text-dark">PLN Field Assistant (PFA)</div>' +
      '          <div class="text-muted">' + escText(UNIT_NAME) + '</div>' +
      '          <span class="badge text-bg-primary mt-1">Versi OTA v' + escText(ver) + ' • APK v' + escText(nat) + '</span>' +
      '        </div>' +
      '        <div class="p-2 rounded-3 bg-light border mb-2">' +
      '          <div class="d-flex justify-content-between py-1 border-bottom"><span class="text-muted">Pengembang</span><strong>' + escText(DEV_NAME) + '</strong></div>' +
      '          <div class="d-flex justify-content-between py-1 border-bottom"><span class="text-muted">Unit Kerja</span><strong>' + escText(UNIT_NAME) + '</strong></div>' +
      '          <div class="d-flex justify-content-between py-1"><span class="text-muted">Status Server</span><strong id="pfaPingStatusVal">Belum diuji</strong></div>' +
      '        </div>' +
      '        <div class="d-grid gap-2">' +
      '          <button type="button" class="btn btn-outline-primary btn-sm fw-semibold" id="btnPfaPingTest"><i class="bi bi-speedometer2 me-1"></i> Tes Kecepatan Server (Ping)</button>' +
      '          <div class="d-flex gap-2">' +
      '            <button type="button" class="btn btn-light border btn-sm flex-grow-1" id="btnAboutCheckUpd"><i class="bi bi-cloud-arrow-down me-1"></i> Cek Update</button>' +
      '            <button type="button" class="btn btn-light border btn-sm flex-grow-1" id="btnAboutFeedback"><i class="bi bi-chat-dots me-1"></i> Lapor Kendala</button>' +
      '          </div>' +
      '        </div>' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var modalEl = document.getElementById('pfaAboutModal');
    var inst = bootstrap.Modal.getOrCreateInstance(modalEl);
    modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); }, { once: true });

    document.getElementById('btnPfaPingTest').onclick = function () {
      var stEl = document.getElementById('pfaPingStatusVal');
      if (stEl) stEl.textContent = 'Mengukur...';
      var t0 = Date.now();
      postToGas(getApiUrl(), { action: 'ping' }).then(function () {
        var ms = Date.now() - t0;
        var label = ms < 1200 ? (ms + ' ms (Lancar)') : (ms + ' ms (Lambat — disarankan Mode Sinyal Lemah)');
        if (stEl) {
          stEl.textContent = label;
          stEl.className = ms < 1200 ? 'text-success fw-bold' : 'text-warning fw-bold';
        }
      }).catch(function () {
        if (stEl) { stEl.textContent = 'Gagal terhubung'; stEl.className = 'text-danger fw-bold'; }
      });
    };
    document.getElementById('btnAboutCheckUpd').onclick = function () { inst.hide(); window.checkPfaUpdate(); };
    document.getElementById('btnAboutFeedback').onclick = function () { inst.hide(); window.openPfaFeedbackModal(); };
    inst.show();
  };

  function injectEnhancedMenuItems() {
    var menu = document.querySelector('#appScreen .topbar-pln .dropdown-menu');
    if (!menu || document.getElementById('pfaMenuCheckUpdate')) return;
    var ver = getCurrentInstalledVersion();
    var isLarge = document.documentElement.classList.contains('pfa-font-large');

    var itemsHtml = [
      '<li id="pfaMenuCheckUpdate"><button type="button" class="dropdown-item small py-2" onclick="checkPfaUpdate()"><i class="bi bi-cloud-arrow-down-fill me-2 text-primary"></i> Cek Update <span class="badge text-bg-light border ms-1">v' + escText(ver) + '</span></button></li>',
      '<li><button type="button" class="dropdown-item small py-2" onclick="refreshPfaSessionNow()"><i class="bi bi-shield-check me-2 text-success"></i> Segarkan Sesi <span id="pfaSessionRemLabel" class="badge text-bg-light border ms-1">-</span></button></li>',
      '<li><button type="button" class="dropdown-item small py-2" onclick="togglePfaFontScale()"><i class="bi bi-fonts me-2 text-secondary"></i> Ukuran Teks <span id="pfaFontScaleBadge" class="badge text-bg-light border ms-1">' + (isLarge ? 'Besar' : 'Normal') + '</span></button></li>',
      '<li><button type="button" class="dropdown-item small py-2" onclick="openPfaFeedbackModal()"><i class="bi bi-chat-square-heart me-2 text-danger"></i> Lapor Kendala / Saran</button></li>',
      '<li><button type="button" class="dropdown-item small py-2" onclick="openPfaAboutModal()"><i class="bi bi-info-circle me-2 text-info"></i> Tentang Aplikasi</button></li>'
    ].join('');

    var temp = document.createElement('ul');
    temp.innerHTML = itemsHtml;
    var divider = menu.querySelector('.dropdown-divider');
    var refNode = (divider && divider.parentNode) ? divider.parentNode : null;
    while (temp.firstChild) {
      if (refNode) menu.insertBefore(temp.firstChild, refNode);
      else menu.appendChild(temp.firstChild);
    }
    updateMenuNotificationDot();
  }

  // --- [Fitur] Popup "Apa yang Baru?" (Changelog) Otomatis Pasca Update OTA ---
  function showPostUpdateChangelogIfNeeded() {
    var ver = getCurrentInstalledVersion();
    var notes = CHANGELOG_NOTES[ver];
    if (!notes || !notes.length) return;
    try {
      if (localStorage.getItem(LAST_SEEN_CHANGELOG_KEY) === ver) return;
      localStorage.setItem(LAST_SEEN_CHANGELOG_KEY, ver);
    } catch (e) { return; }

    var old = document.getElementById('pfaChangelogModal');
    if (old) old.remove();
    var listHtml = notes.map(function (n) { return '<li class="mb-1">' + escText(n) + '</li>'; }).join('');
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaChangelogModal" tabindex="-1">' +
      '  <div class="modal-dialog modal-dialog-centered">' +
      '    <div class="modal-content rounded-4 border-0 shadow">' +
      '      <div class="modal-header text-white py-2" style="background:linear-gradient(135deg,#003b5c,#005b8f);">' +
      '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-stars me-1"></i> Apa yang Baru di PFA v' + escText(ver) + '</h6>' +
      '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
      '      </div>' +
      '      <div class="modal-body small">' +
      '        <ul class="ps-3 mb-2">' + listHtml + '</ul>' +
      '        <div class="text-muted text-end" style="font-size:0.74rem;">Pengembang: <strong>' + escText(DEV_NAME) + '</strong> • ' + escText(UNIT_NAME) + '</div>' +
      '      </div>' +
      '      <div class="modal-footer py-2">' +
      '        <button type="button" class="btn btn-primary btn-sm fw-semibold w-100" data-bs-dismiss="modal">Siap, Mulai Bekerja</button>' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var modalEl = document.getElementById('pfaChangelogModal');
    var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
    modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); }, { once: true });
    if (inst) inst.show();
  }

  // --- IndexedDB Helper untuk Antrean Offline ---
  function openOfflineDb() {
    return new Promise(function (resolve, reject) {
      if (!window.indexedDB) { reject(new Error('IndexedDB tidak didukung.')); return; }
      var req = window.indexedDB.open(OFFLINE_DB_NAME, 1);
      req.onupgradeneeded = function (ev) {
        var db = ev.target.result;
        if (!db.objectStoreNames.contains(OFFLINE_STORE)) {
          db.createObjectStore(OFFLINE_STORE, { keyPath: 'id', autoIncrement: true });
        }
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error('Gagal membuka database offline.')); };
    });
  }

  function enqueueOfflineAction(payload) {
    return openOfflineDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(OFFLINE_STORE, 'readwrite');
        var req = tx.objectStore(OFFLINE_STORE).add({
          createdAt: new Date().toISOString(),
          action: payload.action,
          payload: payload
        });
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
      });
    }).then(function (id) { refreshOfflineQueueBanner(); return id; });
  }

  function listOfflineQueue() {
    return openOfflineDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(OFFLINE_STORE, 'readonly');
        var req = tx.objectStore(OFFLINE_STORE).getAll();
        req.onsuccess = function () { resolve(req.result || []); };
        req.onerror = function () { reject(req.error); };
      });
    }).catch(function () { return []; });
  }

  function removeOfflineItem(id) {
    return openOfflineDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(OFFLINE_STORE, 'readwrite');
        var req = tx.objectStore(OFFLINE_STORE).delete(id);
        req.onsuccess = function () { resolve(); };
        req.onerror = function () { reject(req.error); };
      });
    });
  }

  function clearOfflineQueueAll() {
    return openOfflineDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(OFFLINE_STORE, 'readwrite');
        var req = tx.objectStore(OFFLINE_STORE).clear();
        req.onsuccess = function () { resolve(); };
        req.onerror = function () { reject(req.error); };
      });
    }).then(function () { refreshOfflineQueueBanner(); });
  }

  // --- Pengirim HTTP ke GAS doPost(e) ---
  function postToGas(url, payload) {
    var bodyStr = JSON.stringify(payload || {});
    var capHttp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp;

    var reqPromise = (capHttp && typeof capHttp.post === 'function')
      ? capHttp.post({
          url: url,
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          data: bodyStr,
          connectTimeout: (window.PFA_CONFIG && window.PFA_CONFIG.REQUEST_TIMEOUT_MS) || 60000,
          readTimeout: (window.PFA_CONFIG && window.PFA_CONFIG.REQUEST_TIMEOUT_MS) || 60000
        }).then(function (res) {
          var data = res && res.data;
          if (typeof data === 'string') {
            try { data = JSON.parse(data); } catch (e) {
              throw new Error('Respons server bukan JSON valid. Pastikan Deployment GAS disetel ke "Anyone".');
            }
          }
          return data;
        })
      : fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: bodyStr,
          redirect: 'follow'
        }).then(function (res) {
          return res.text().then(function (txt) {
            try { return JSON.parse(txt); } catch (e) {
              throw new Error('Respons server GAS tidak valid (HTTP ' + res.status + ').');
            }
          });
        });

    return reqPromise.then(function (res) {
      if (payload && payload.action === 'login' && res && res.status === 'success' && res.sessionToken) {
        LAST_SESSION_TOKEN = String(res.sessionToken).trim();
        setTimeout(function () {
          injectPortalGreeting();
          injectEnhancedMenuItems();
          updateMenuNotificationDot();
        }, 250);
      }
      if (res && res.code === 'SESSION_EXPIRED') {
        LAST_SESSION_TOKEN = '';
        if (typeof window.showToast === 'function') {
          window.showToast('Sesi login telah berakhir. Silakan login kembali.', 'warning');
        }
        if (typeof window.logoutApp === 'function') {
          setTimeout(function () { window.logoutApp(); }, 700);
        }
      }
      return res;
    });
  }

  // --- [Fitur] Banner Tombol "Coba Lagi" Saat Gagal Memuat Data ---
  function showRetryDataBar(msg, retryFn) {
    LAST_FAILED_RETRY_FN = retryFn;
    var container = document.querySelector('#appScreen .container');
    if (!container) return;
    var bar = document.getElementById('pfaRetryDataBar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'pfaRetryDataBar';
      bar.className = 'alert alert-warning d-flex justify-content-between align-items-center gap-2 py-2 px-3 rounded-3 mb-2 small';
      container.insertBefore(bar, container.firstChild);
    }
    bar.innerHTML =
      '<span><i class="bi bi-wifi-off me-1"></i> ' + escText(msg || 'Gagal memuat data.') + '</span>' +
      '<div class="d-flex gap-1">' +
      '  <button type="button" class="btn btn-dark btn-sm py-0 px-2" id="btnPfaRetryNow">Coba Lagi</button>' +
      '  <button type="button" class="btn btn-outline-dark btn-sm py-0 px-1" id="btnPfaRetryDismiss">×</button>' +
      '</div>';
    document.getElementById('btnPfaRetryNow').onclick = function () {
      bar.remove();
      if (typeof LAST_FAILED_RETRY_FN === 'function') LAST_FAILED_RETRY_FN();
    };
    document.getElementById('btnPfaRetryDismiss').onclick = function () { bar.remove(); };
  }

  // --- Override callApi(payload) + Double-Submit Guard + Review Before Submit ---
  var originalCallApi = typeof window.callApi === 'function' ? window.callApi : null;

  function clearDirtyForAction(action) {
    if (action === 'simpan_gangguan') markTabDirty('gangguan', false);
    else if (action === 'simpan_pengukuran') markTabDirty('pengukuran', false);
    else if (action === 'simpan_p2tl') markTabDirty('p2tl', false);
  }

  window.callApi = function (payload) {
    if (typeof google !== 'undefined' && google.script && google.script.run && originalCallApi) {
      return originalCallApi(payload);
    }

    var reqPayload = Object.assign({}, payload || {});
    var act = String(reqPayload.action || '');

    // Anti-Klik Ganda (Double-Submit Guard) pada aksi simpan & cari
    var guardable = QUEUEABLE_ACTIONS.indexOf(act) !== -1 || act === 'cari_pelanggan' || act === 'cek_kct';
    if (guardable && IN_FLIGHT_KEYS[act]) {
      return Promise.reject(new Error('Permintaan sebelumnya masih diproses, mohon tunggu sebentar.'));
    }

    if (!reqPayload.sessionToken) {
      var tok = getActiveSessionToken();
      if (tok) reqPayload.sessionToken = tok;
    }

    var apiUrl = getApiUrl();
    if (!isApiUrlConfigured(apiUrl)) {
      return Promise.reject(new Error('URL API GAS belum diisi. Atur GAS_API_URL pada file www/pfa-config.js terlebih dahulu.'));
    }

    var isQueueable = QUEUEABLE_ACTIONS.indexOf(act) !== -1;

    if (act === 'get_master_kerusakan') {
      return postToGas(apiUrl, reqPayload).then(function (res) {
        if (res && res.status === 'success' && Array.isArray(res.data) && res.data.length) {
          try { localStorage.setItem('pfa_cache_master_kerusakan', JSON.stringify(res.data)); } catch (e) {}
        }
        return res;
      }).catch(function (err) {
        try {
          var cached = JSON.parse(localStorage.getItem('pfa_cache_master_kerusakan') || '[]');
          if (Array.isArray(cached) && cached.length) return { status: 'success', data: cached, fromCache: true };
        } catch (e) {}
        throw err;
      });
    }

    if (guardable) IN_FLIGHT_KEYS[act] = true;

    function releaseGuard() {
      if (guardable) delete IN_FLIGHT_KEYS[act];
    }

    if (isQueueable && !reqPayload.allowDuplicate && !reqPayload._skipReview) {
      return compressPayloadPhotos(reqPayload).then(function (compressedPayload) {
        return showReviewBeforeSubmitModal(compressedPayload).then(function (confirmed) {
          if (!confirmed) {
            releaseGuard();
            return { status: 'error', message: 'Pengiriman dibatalkan untuk dicek kembali.' };
          }
          if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengirim laporan ke server...');
          return executeQueueableRequest(apiUrl, compressedPayload).finally(releaseGuard);
        });
      }).catch(function (err) {
        releaseGuard();
        throw err;
      });
    }

    var prepPromise = isQueueable ? compressPayloadPhotos(reqPayload) : Promise.resolve(reqPayload);
    return prepPromise.then(function (finalPayload) {
      if (isQueueable) return executeQueueableRequest(apiUrl, finalPayload);
      return postToGas(apiUrl, finalPayload).catch(function (err) {
        if (act === 'cari_pelanggan' || act === 'cek_kct' || act === 'get_histori_petugas') {
          showRetryDataBar('Gagal memuat data (' + act + ').', function () {
            if (act === 'cari_pelanggan' && typeof window.cariPelanggan === 'function') window.cariPelanggan();
            else if (act === 'cek_kct' && typeof window.cariKct === 'function') window.cariKct();
            else if (act === 'get_histori_petugas' && typeof window.loadHistoriSaya === 'function') window.loadHistoriSaya();
          });
        }
        throw err;
      });
    }).finally(releaseGuard);
  };

  function executeQueueableRequest(apiUrl, finalPayload) {
    if (navigator.onLine === false) {
      return enqueueOfflineAction(finalPayload).then(function () {
        clearDirtyForAction(finalPayload.action);
        triggerHaptic([40, 40, 40]);
        schedulePhotoSizeUpdate();
        return {
          status: 'success',
          offlineQueued: true,
          message: 'Sinyal terputus. Data & foto terkompresi diamankan ke Antrean Offline perangkat.'
        };
      });
    }

    return postToGas(apiUrl, finalPayload).then(function (res) {
      if (res && res.status === 'success') {
        clearDirtyForAction(finalPayload.action);
        triggerHaptic(60);
        schedulePhotoSizeUpdate();
      }
      return res;
    }).catch(function (err) {
      var msg = err && err.message ? err.message : String(err);
      var isNetworkErr = /network|failed to fetch|timeout|offline|unable to resolve host|socket/i.test(msg) || navigator.onLine === false;
      if (isNetworkErr) {
        return enqueueOfflineAction(finalPayload).then(function () {
          clearDirtyForAction(finalPayload.action);
          triggerHaptic([40, 40, 40]);
          schedulePhotoSizeUpdate();
          return {
            status: 'success',
            offlineQueued: true,
            message: 'Koneksi tidak stabil. Laporan diamankan ke Antrean Offline dan siap dikirim ulang saat sinyal membaik.'
          };
        });
      }
      throw err;
    });
  }

  // --- Update Otomatis OTA + Aturan minNativeVersion ---
  function compareSemver(a, b) {
    var pa = String(a || '0').split('.').map(function (n) { return parseInt(n, 10) || 0; });
    var pb = String(b || '0').split('.').map(function (n) { return parseInt(n, 10) || 0; });
    for (var i = 0; i < 3; i++) {
      if ((pa[i] || 0) > (pb[i] || 0)) return 1;
      if ((pa[i] || 0) < (pb[i] || 0)) return -1;
    }
    return 0;
  }

  function getNativeApkVersion() {
    try {
      var savedNative = localStorage.getItem('pfa_native_apk_version');
      if (savedNative) return savedNative;
    } catch (e) {}
    return '2.0.0';
  }

  function getCurrentInstalledVersion() {
    var baseVer = (window.PFA_CONFIG && window.PFA_CONFIG.APP_VERSION) || '2.0.4';
    try {
      var otaVer = String(localStorage.getItem('pfa_ota_version') || '').trim();
      if (otaVer && compareSemver(otaVer, baseVer) > 0) return otaVer;
    } catch (e) {}
    return baseVer;
  }

  function runOtaInAppUpdate(otaUrl, targetVer) {
    var updater = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater;
    if (!updater || typeof updater.download !== 'function') {
      if (typeof window.showToast === 'function') window.showToast('Plugin OTA belum aktif di perangkat ini.', 'warning');
      return;
    }
    if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengunduh update PFA v' + targetVer + '...');
    updater.download({ url: otaUrl, version: targetVer })
      .then(function (bundle) {
        if (!bundle || !bundle.id) throw new Error('Paket update tidak valid.');
        try { localStorage.setItem('pfa_ota_version', targetVer); } catch (e) {}
        if (typeof window.setLoading === 'function') window.setLoading(true, 'Menerapkan pembaruan & memuat ulang...');
        return updater.set({ id: bundle.id });
      })
      .catch(function (err) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (typeof window.showToast === 'function') {
          window.showToast('Gagal update otomatis: ' + ((err && err.message) || err), 'danger');
        }
      });
  }

  function checkAppUpdateOnLaunch(manualTrigger) {
    if (navigator.onLine === false) {
      if (manualTrigger && typeof window.showToast === 'function') window.showToast('Tidak ada koneksi internet untuk cek update.', 'warning');
      return;
    }
    var apiUrl = getApiUrl();
    if (!isApiUrlConfigured(apiUrl)) return;
    var currentVer = getCurrentInstalledVersion();
    var nativeVer = getNativeApkVersion();

    if (manualTrigger && typeof window.setLoading === 'function') {
      window.setLoading(true, 'Memeriksa pembaruan PFA...');
    }

    postToGas(apiUrl, { action: 'check_app_update' }).then(function (res) {
      if (manualTrigger && typeof window.setLoading === 'function') window.setLoading(false);
      if (!res || res.status !== 'success' || !res.latestVersion) return;

      var isBetaChannelOn = false;
      try { isBetaChannelOn = localStorage.getItem('pfa_beta_channel_v1') === '1'; } catch (eB) {}
      var useBetaOta = Boolean(isBetaChannelOn && res.betaVersion && res.betaOtaBundleUrl);
      var targetVersion = useBetaOta ? res.betaVersion : res.latestVersion;
      var targetOtaUrl = useBetaOta ? res.betaOtaBundleUrl : res.otaBundleUrl;

      var mustUpdateApk = Boolean(!useBetaOta && res.minNativeVersion && compareSemver(res.minNativeVersion, nativeVer) > 0 && res.downloadUrl);
      var hasOta = Boolean(!mustUpdateApk && targetOtaUrl && isCapacitorNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater);
      var hasApk = Boolean(res.downloadUrl);
      var hasNewer = mustUpdateApk || compareSemver(targetVersion, currentVer) > 0;

      HAS_PENDING_UPDATE_BADGE = Boolean(hasNewer && (hasOta || hasApk));
      updateMenuNotificationDot();

      if (!HAS_PENDING_UPDATE_BADGE) {
        if (manualTrigger && typeof window.showToast === 'function') {
          window.showToast('PFA Anda sudah versi terbaru (v' + currentVer + ').', 'success');
        }
        return;
      }

      var old = document.getElementById('pfaUpdateModal');
      if (old) old.remove();
      var actionBtnHtml = hasOta
        ? '<button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnPfaRunOta"><i class="bi bi-lightning-charge-fill me-1"></i> Update Sekarang (Otomatis)</button>'
        : '<a href="' + escText(res.downloadUrl) + '" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm fw-semibold"><i class="bi bi-download me-1"></i> Unduh Update APK</a>';

      var noteHtml = mustUpdateApk
        ? '<div class="alert alert-warning py-1 px-2 mt-2 mb-0" style="font-size:0.75rem;"><i class="bi bi-shield-exclamation me-1"></i>Pembaruan ini membutuhkan instalasi ulang file <strong>APK v' + escText(res.minNativeVersion) + '</strong>.</div>'
        : (hasOta ? '<div class="text-muted mt-2" style="font-size:0.75rem;"><i class="bi bi-info-circle me-1"></i>Aplikasi akan mengunduh pembaruan kecil dan memuat ulang otomatis tanpa instal ulang APK.</div>' : '');

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="pfaUpdateModal" tabindex="-1">' +
        '  <div class="modal-dialog modal-dialog-centered">' +
        '    <div class="modal-content rounded-4 border-0 shadow">' +
        '      <div class="modal-header bg-primary text-white py-2">' +
        '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-cloud-download-fill me-1"></i> Update PFA v' + escText(targetVersion) + (useBetaOta ? ' (BETA)' : '') + ' Tersedia</h6>' +
        '        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
        '      </div>' +
        '      <div class="modal-body small">' +
        '        <p class="mb-2">Versi terpasang: <strong>v' + escText(currentVer) + '</strong> → Terbaru: <strong class="text-primary">v' + escText(targetVersion) + (useBetaOta ? ' (Channel Beta)' : '') + '</strong></p>' +
        '        <div class="p-2 rounded-3 bg-light border">' + escText(res.releaseNotes || 'Perbaikan bug dan peningkatan performa.') + '</div>' +
                 noteHtml +
        '      </div>' +
        '      <div class="modal-footer py-2">' +
        '        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Nanti Saja</button>' +
                 actionBtnHtml +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>';
      document.body.appendChild(wrap.firstChild);
      var modalEl = document.getElementById('pfaUpdateModal');
      var inst = typeof bootstrap !== 'undefined' ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
      var otaBtn = document.getElementById('btnPfaRunOta');
      if (otaBtn) {
        otaBtn.onclick = function () {
          if (inst) inst.hide();
          runOtaInAppUpdate(targetOtaUrl, targetVersion);
        };
      }
      if (inst) inst.show();
    }).catch(function () {
      if (manualTrigger && typeof window.setLoading === 'function') window.setLoading(false);
      if (manualTrigger && typeof window.showToast === 'function') window.showToast('Gagal memeriksa pembaruan. Periksa sinyal Anda.', 'warning');
    });
  }

  window.checkPfaUpdate = function () { checkAppUpdateOnLaunch(true); };

  // --- Banner & Sinkronisasi Antrean Offline ---
  function ensureOfflineBanner() {
    var existing = document.getElementById('pfaOfflineQueueBanner');
    if (existing) return existing;
    var container = document.querySelector('#appScreen .container');
    if (!container) return null;

    var banner = document.createElement('div');
    banner.id = 'pfaOfflineQueueBanner';
    banner.className = 'alert alert-info border-info d-none justify-content-between align-items-center flex-wrap gap-2 py-2 px-3 rounded-3 mb-3';
    banner.innerHTML =
      '<div class="small">' +
      '  <i class="bi bi-cloud-arrow-up-fill me-1 fw-bold"></i>' +
      '  Ada <strong id="pfaOfflineCount">0</strong> laporan di <strong>Antrean Offline</strong> siap dikirim.' +
      '</div>' +
      '<div class="d-flex gap-2">' +
      '  <button type="button" class="btn btn-sm btn-primary fw-semibold" id="btnSyncOfflineQueue"><i class="bi bi-arrow-repeat me-1"></i> Kirim Sekarang</button>' +
      '  <button type="button" class="btn btn-sm btn-outline-danger" id="btnClearOfflineQueue" title="Hapus antrean">Hapus</button>' +
      '</div>';

    var weakBar = document.getElementById('pfaWeakSignalBar');
    if (weakBar && weakBar.nextSibling) container.insertBefore(banner, weakBar.nextSibling);
    else container.insertBefore(banner, container.firstChild);

    banner.querySelector('#btnSyncOfflineQueue').addEventListener('click', syncOfflineQueueNow);
    banner.querySelector('#btnClearOfflineQueue').addEventListener('click', function () {
      if (confirm('Hapus semua laporan di Antrean Offline perangkat ini?')) {
        clearOfflineQueueAll().then(function () {
          if (typeof window.showToast === 'function') window.showToast('Antrean offline dibersihkan.', 'secondary');
        });
      }
    });
    return banner;
  }

  function refreshOfflineQueueBanner() {
    listOfflineQueue().then(function (items) {
      var banner = ensureOfflineBanner();
      if (!banner) return;
      var countEl = document.getElementById('pfaOfflineCount');
      if (countEl) countEl.textContent = String(items.length);
      banner.classList.toggle('d-none', items.length === 0);
      banner.classList.toggle('d-flex', items.length > 0);
    });
  }

  function askDuplicateResolutionModal(dupObj, offlineData) {
    return new Promise(function (resolve) {
      var oldModal = document.getElementById('pfaOfflineDupModal');
      if (oldModal) oldModal.remove();
      var latest = (dupObj && dupObj.latest) || {};
      var d = offlineData || {};
      var driveBtn = latest.link_folder
        ? '<a href="' + escText(latest.link_folder) + '" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary mt-2 w-100"><i class="bi bi-folder2-open me-1"></i> Lihat Foto Laporan Sebelumnya (Drive)</a>'
        : '';

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="pfaOfflineDupModal" tabindex="-1" data-bs-backdrop="static">' +
        '  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
        '    <div class="modal-content rounded-4 border-0 shadow">' +
        '      <div class="modal-header bg-warning text-dark py-2">' +
        '        <h6 class="modal-title fw-bold mb-0"><i class="bi bi-exclamation-triangle-fill me-1"></i> Data IDPEL ' + escText(d.id_pelanggan || latest.idpel || '-') + ' Sudah Ada</h6>' +
        '        <button type="button" class="btn-close" id="btnDupCloseX" aria-label="Tutup"></button>' +
        '      </div>' +
        '      <div class="modal-body small">' +
        '        <p class="mb-2">IDPEL ini tercatat sudah masuk <strong>' + escText(dupObj && dupObj.count ? dupObj.count : 1) + ' kali</strong> di server:</p>' +
        '        <div class="p-2 rounded-3 bg-light border mb-2">' +
        '          <div class="fw-bold text-primary mb-1">1. Data Sebelumnya di Server</div>' +
        '          <div>• Waktu: <strong>' + escText(latest.timestamp || '-') + '</strong></div>' +
        '          <div>• No. Form DG: <strong>' + escText(latest.no_form_dg || '-') + '</strong></div>' +
        '          <div>• Status TL: <strong>' + escText(latest.status_tl || '-') + '</strong></div>' +
        '          <div>• Meter Baru: <strong>' + escText(latest.no_meter_baru || '-') + '</strong></div>' +
        '          <div>• Sebab: <strong>' + escText(latest.sebab_kerusakan || '-') + '</strong></div>' +
        '          <div>• Petugas: <strong>' + escText(latest.petugas || '-') + '</strong></div>' +
                   driveBtn +
        '        </div>' +
        '        <div class="p-2 rounded-3 bg-info bg-opacity-10 border border-info">' +
        '          <div class="fw-bold text-dark mb-1">2. Data Offline yang Akan Dikirim</div>' +
        '          <div>• No. Form DG: <strong>' + escText(d.no_form_dg || '-') + '</strong></div>' +
        '          <div>• Status TL: <strong>' + escText(d.status_tindak_lanjut || '-') + '</strong></div>' +
        '          <div>• Meter Baru: <strong>' + escText(d.no_meter_baru || '-') + '</strong></div>' +
        '          <div>• Sebab: <strong>' + escText(d.sebab_kerusakan || '-') + '</strong></div>' +
        '          <div>• Petugas: <strong>' + escText(d.petugas || '-') + '</strong></div>' +
        '        </div>' +
        '      </div>' +
        '      <div class="modal-footer flex-column align-items-stretch gap-2 pt-1">' +
        '        <button type="button" class="btn btn-primary btn-sm fw-semibold" id="btnDupSendForce">Tetap Kirim (Ini Data Berbeda)</button>' +
        '        <button type="button" class="btn btn-outline-danger btn-sm fw-semibold" id="btnDupDiscard">Hapus dari Antrean (Data Sama / Sudah Masuk)</button>' +
        '        <button type="button" class="btn btn-light btn-sm" id="btnDupLater">Tunda / Batal</button>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>';

      document.body.appendChild(wrap.firstChild);
      var modalEl = document.getElementById('pfaOfflineDupModal');
      var inst = bootstrap.Modal.getOrCreateInstance(modalEl);
      function finish(choice) {
        inst.hide();
        modalEl.addEventListener('hidden.bs.modal', function () { modalEl.remove(); resolve(choice); }, { once: true });
      }
      document.getElementById('btnDupSendForce').onclick = function () { finish('send'); };
      document.getElementById('btnDupDiscard').onclick = function () { finish('discard'); };
      document.getElementById('btnDupLater').onclick = function () { finish('cancel'); };
      document.getElementById('btnDupCloseX').onclick = function () { finish('cancel'); };
      if (typeof window.setLoading === 'function') window.setLoading(false);
      inst.show();
    });
  }

  var isSyncingQueue = false;
  function syncOfflineQueueNow() {
    if (isSyncingQueue) return;
    if (navigator.onLine === false) {
      if (typeof window.showToast === 'function') window.showToast('Perangkat masih offline. Tunggu sinyal kembali.', 'warning');
      return;
    }
    var apiUrl = getApiUrl();
    if (!isApiUrlConfigured(apiUrl)) return;

    isSyncingQueue = true;
    listOfflineQueue().then(function (items) {
      if (!items.length) { isSyncingQueue = false; refreshOfflineQueueBanner(); return; }
      if (typeof window.setLoading === 'function') window.setLoading(true, 'Menyinkronkan ' + items.length + ' laporan offline...');

      var synced = 0, failed = 0, lastErrMsg = '';
      var chain = Promise.resolve();

      items.forEach(function (entry) {
        chain = chain.then(function () {
          var payload = Object.assign({}, entry.payload || {});
          var tok = getActiveSessionToken();
          if (tok) payload.sessionToken = tok;

          return postToGas(apiUrl, payload).then(function (res) {
            if (res && res.status === 'success') { synced++; return removeOfflineItem(entry.id); }
            if (res && res.status === 'duplicate' && ['simpan_gangguan', 'simpan_pengukuran', 'simpan_p2tl'].indexOf(payload.action) !== -1) {
              return askDuplicateResolutionModal(res.duplicate, payload.data).then(function (choice) {
                if (choice === 'send') {
                  if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengirim laporan offline...');
                  payload.allowDuplicate = true;
                  return postToGas(apiUrl, payload).then(function (res2) {
                    if (res2 && res2.status === 'success') { synced++; return removeOfflineItem(entry.id); }
                    failed++; lastErrMsg = (res2 && res2.message) || 'Gagal simpan ulang.';
                  });
                }
                if (choice === 'discard') { synced++; return removeOfflineItem(entry.id); }
                failed++; lastErrMsg = 'Sinkronisasi ditunda oleh petugas.';
              });
            }
            failed++; lastErrMsg = (res && res.message) || ('Status server: ' + (res && res.status ? res.status : 'tidak diketahui'));
          }).catch(function (err) {
            failed++; lastErrMsg = (err && err.message) ? err.message : String(err);
          });
        });
      });

      return chain.finally(function () {
        isSyncingQueue = false;
        if (typeof window.setLoading === 'function') window.setLoading(false);
        refreshOfflineQueueBanner();
        if (typeof window.showToast === 'function') {
          if (synced > 0 && failed === 0) {
            triggerHaptic(60);
            window.showToast(synced + ' laporan offline selesai diproses!', 'success');
          } else if (synced > 0 && failed > 0) {
            window.showToast(synced + ' selesai, ' + failed + ' belum terkirim: ' + lastErrMsg, 'warning');
          } else {
            window.showToast('Sinkronisasi gagal: ' + (lastErrMsg || 'Periksa koneksi internet Anda.'), 'danger');
          }
        }
      });
    });
  }

  window.syncPfaOfflineQueue = syncOfflineQueueNow;

  // --- Scanner Google ML Kit + Fallback Html5Qrcode (Getar + Bip + Senter) ---
  function applyScannedBarcode(targetId, rawCode) {
    var cleanCode = String(rawCode || '').trim();
    if (!cleanCode) return;
    triggerHaptic(45);
    playBarcodeBeep();
    var inp = targetId ? document.getElementById(targetId) : null;
    if (inp) {
      inp.value = cleanCode;
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (typeof window.showToast === 'function') window.showToast('Barcode terbaca: ' + cleanCode, 'success');
  }

  var nativeModalQr = null;
  var originalOpenBarcode = typeof window.openBarcodeScanner === 'function' ? window.openBarcodeScanner : null;

  function openHtml5QrcodeFallback(targetId) {
    var modalEl = document.getElementById('barcodeScannerModal');
    if (!modalEl || typeof bootstrap === 'undefined') {
      if (originalOpenBarcode) return originalOpenBarcode(targetId);
      return;
    }

    var statusEl = document.getElementById('qrScanStatus');
    if (statusEl) { statusEl.textContent = 'Mengaktifkan kamera belakang...'; statusEl.classList.remove('d-none'); }

    var torchOn = false;
    var torchBtn = document.getElementById('pfaBtnTorchModal');
    if (!torchBtn) {
      var bodyEl = modalEl.querySelector('.modal-body');
      if (bodyEl) {
        var wrapBtn = document.createElement('div');
        wrapBtn.className = 'd-flex justify-content-center mb-2';
        wrapBtn.innerHTML = '<button type="button" id="pfaBtnTorchModal" class="btn btn-sm btn-warning fw-semibold d-none"><i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter</button>';
        bodyEl.insertBefore(wrapBtn, bodyEl.firstChild);
        torchBtn = document.getElementById('pfaBtnTorchModal');
      }
    }
    if (torchBtn) {
      torchBtn.className = 'btn btn-sm btn-warning fw-semibold d-none';
      torchBtn.innerHTML = '<i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter';
      torchBtn.onclick = function () {
        if (!nativeModalQr) return;
        torchOn = !torchOn;
        nativeModalQr.applyVideoConstraints({ advanced: [{ torch: torchOn }] })
          .then(function () {
            torchBtn.className = 'btn btn-sm fw-semibold ' + (torchOn ? 'btn-dark' : 'btn-warning');
            torchBtn.innerHTML = torchOn
              ? '<i class="bi bi-lightbulb-off-fill me-1"></i> Matikan Senter'
              : '<i class="bi bi-lightning-charge-fill me-1"></i> Nyalakan Senter';
          })
          .catch(function () {
            torchOn = false;
            if (typeof window.showToast === 'function') window.showToast('Senter tidak didukung kamera pada mode ini.', 'warning');
          });
      };
    }

    var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    modal.show();

    function stopInlineScanner() {
      if (!nativeModalQr) return Promise.resolve();
      var ref = nativeModalQr;
      nativeModalQr = null;
      return ref.stop().catch(function () {}).then(function () { try { ref.clear(); } catch (e) {} });
    }

    modalEl.addEventListener('hidden.bs.modal', function onHide() {
      modalEl.removeEventListener('hidden.bs.modal', onHide);
      torchOn = false;
      stopInlineScanner();
    });

    setTimeout(function () {
      if (typeof Html5Qrcode === 'undefined') {
        if (statusEl) statusEl.textContent = 'Library scanner belum termuat. Gunakan opsi Scan dari Foto di bawah.';
        return;
      }
      stopInlineScanner().then(function () {
        var formats = (typeof Html5QrcodeSupportedFormats !== 'undefined') ? [
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.ITF,
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.CODABAR,
          Html5QrcodeSupportedFormats.QR_CODE
        ] : undefined;

        nativeModalQr = new Html5Qrcode('qrReaderBox', {
          formatsToSupport: formats,
          experimentalFeatures: { useBarCodeDetectorIfSupported: true },
          verbose: false
        });

        var done = false;
        nativeModalQr.start(
          { facingMode: 'environment' },
          {
            fps: 20,
            qrbox: function (viewW, viewH) {
              return { width: Math.min(320, Math.floor(viewW * 0.88)), height: Math.min(140, Math.floor(viewH * 0.38)) };
            },
            videoConstraints: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
          },
          function (decodedText) {
            if (done) return;
            done = true;
            stopInlineScanner().finally(function () { modal.hide(); applyScannedBarcode(targetId, decodedText); });
          },
          function () {}
        ).then(function () {
          if (statusEl) statusEl.textContent = 'Arahkan garis barcode / QR meter sejajar kotak...';
          if (torchBtn) torchBtn.classList.remove('d-none');
        }).catch(function (err) {
          if (statusEl) statusEl.textContent = 'Kamera belum diizinkan (' + ((err && err.message) || err) + '). Gunakan Scan dari Foto di bawah.';
        });
      });
    }, 250);
  }

  window.openBarcodeScanner = function (targetInputId) {
    if (typeof google !== 'undefined' && google.script && google.script.run && originalOpenBarcode) {
      return originalOpenBarcode(targetInputId);
    }
    var targetId = targetInputId || '';
    var mlkit = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.BarcodeScanner;
    if (isCapacitorNative() && mlkit && typeof mlkit.scan === 'function') {
      var checkMod = (typeof mlkit.isGoogleBarcodeScannerModuleAvailable === 'function')
        ? mlkit.isGoogleBarcodeScannerModuleAvailable()
        : Promise.resolve({ available: true });

      checkMod.then(function (modRes) {
        if (modRes && modRes.available === false) {
          if (typeof mlkit.installGoogleBarcodeScannerModule === 'function') mlkit.installGoogleBarcodeScannerModule().catch(function () {});
          if (typeof window.showToast === 'function') window.showToast('Menyiapkan modul scanner Google di latar belakang...', 'info');
          openHtml5QrcodeFallback(targetId);
          return null;
        }
        return mlkit.scan();
      }).then(function (result) {
        if (!result) return;
        var list = (result && result.barcodes) || [];
        if (list.length > 0 && (list[0].rawValue || list[0].displayValue)) {
          applyScannedBarcode(targetId, list[0].rawValue || list[0].displayValue);
        }
      }).catch(function (err) {
        if (/cancel/i.test(String((err && err.message) || err || ''))) return;
        openHtml5QrcodeFallback(targetId);
      });
      return;
    }
    openHtml5QrcodeFallback(targetId);
  };

  // --- Cache & Auto-Reload Sebab Kerusakan ---
  function ensureMasterKerusakanLoaded() {
    var sel = document.getElementById('f_sebab_kerusakan');
    if (!sel || sel.options.length > 1) return;
    try {
      var cached = JSON.parse(localStorage.getItem('pfa_cache_master_kerusakan') || '[]');
      if (Array.isArray(cached) && cached.length) {
        var prevVal = sel.value;
        sel.innerHTML = '<option value="">-- Pilih Sebab Kerusakan --</option>';
        cached.forEach(function (item) {
          var opt = document.createElement('option');
          opt.value = item; opt.textContent = item;
          sel.appendChild(opt);
        });
        if (prevVal) sel.value = prevVal;
      }
    } catch (e) {}
    if (typeof window.loadMasterKerusakan === 'function' && getActiveSessionToken()) window.loadMasterKerusakan();
  }

  // --- Event Delegation Global (1 Listener Ringan untuk Semua Modul — Nol Lag!) ---
  function bindGlobalDelegatedListeners() {
    // 1. Auto-bersih paste IDPEL / No. Meter (hapus spasi & tanda strip '-')
    document.addEventListener('paste', function (ev) {
      var t = ev.target;
      if (!t || t.tagName !== 'INPUT') return;
      var id = t.id || '';
      if (!/(idpel|id_pelanggan|no_meter|cariPelanggan|kctSearch|u_cari|p2tl_cari)/i.test(id)) return;
      var clip = (ev.clipboardData || window.clipboardData);
      if (!clip) return;
      var raw = clip.getData('text');
      if (raw && /[\s-]/.test(raw) && /\d{6,}/.test(raw.replace(/[\s-]/g, ''))) {
        ev.preventDefault();
        t.value = raw.replace(/[\s-]+/g, '').trim();
        t.dispatchEvent(new Event('input', { bubbles: true }));
      }
    });

    // 2. Auto-fokus kolom wajib pertama yang kosong (berlaku di semua <form>)
    document.addEventListener('invalid', function (ev) {
      var el = ev.target;
      if (!el || typeof el.scrollIntoView !== 'function') return;
      var form = el.closest('form');
      if (form && form.querySelector(':invalid') === el) {
        el.classList.add('pfa-field-highlight');
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setTimeout(function () { el.classList.remove('pfa-field-highlight'); }, 2200);
      }
    }, true);

    // 3. Klik global: Tap-to-Zoom foto, Konfirmasi Hapus Foto Tambahan, Undo Reset, & Auto-Tutup Keyboard
    document.addEventListener('click', function (ev) {
      var t = ev.target;
      if (!t) return;

      // Tap-to-Zoom foto preview di semua modul
      var img = t.closest('img.foto-preview, img.rekap-foto-img');
      if (img && img.src && img.src.indexOf('data:image/') === 0 || (img && img.src && img.src.indexOf('http') === 0)) {
        if (!img.classList.contains('d-none')) {
          openPhotoZoomLightbox(img.src);
          return;
        }
      }

      // Konfirmasi hapus foto tambahan (capture sebelum inline onclick menghapus row)
      var delBtn = t.closest('.dg-foto-row button.btn-outline-danger, .ukur-foto-row button.btn-outline-danger, .p2tl-foto-row button.btn-outline-danger');
      if (delBtn && !delBtn.dataset.pfaConfirmed) {
        if (!confirm('Hapus foto dokumentasi ini?')) {
          ev.preventDefault();
          ev.stopImmediatePropagation();
          return;
        }
        schedulePhotoSizeUpdate();
      }

      // Tangkap tombol Reset formulir untuk Undo 5 detik
      var resetBtn = t.closest('button[onclick*="reset"], button[type="reset"]');
      if (resetBtn) {
        var tab = resetBtn.closest('#tab-gangguan, #tab-pengukuran, #tab-p2tl');
        if (tab) {
          var tabName = tab.id.replace('tab-', '');
          var snap = captureFormSnapshot(tab);
          setTimeout(function () {
            markTabDirty(tabName, false);
            schedulePhotoSizeUpdate();
            showUndoResetToast(snap, tabName);
          }, 120);
        }
      }

      // Auto-tutup keyboard saat tekan tombol Cari Data
      if (t.closest('button[onclick*="cariPelanggan"], button[onclick*="cariKct"]')) {
        hideMobileKeyboard();
      }
    }, true);

    // 4. Lacak dirty state & ukuran foto secara event-driven pada 3 tab form
    ['gangguan', 'pengukuran', 'p2tl'].forEach(function (tabName) {
      var el = document.getElementById('tab-' + tabName);
      if (!el || el.dataset.pfaDirtyBound) return;
      el.dataset.pfaDirtyBound = '1';
      el.addEventListener('input', function () {
        markTabDirty(tabName, true);
        schedulePhotoSizeUpdate();
      });
      el.addEventListener('change', function () {
        markTabDirty(tabName, true);
        schedulePhotoSizeUpdate();
      });
    });
  }

  // --- Lifecycle Events ---
  window.addEventListener('online', function () {
    renderWeakSignalBar();
    renderLoginOfflineBanner();
    refreshOfflineQueueBanner();
    listOfflineQueue().then(function (items) {
      if (items.length > 0 && typeof window.showToast === 'function') {
        window.showToast('Sinyal kembali! Ketuk "Kirim Sekarang" untuk menyinkronkan ' + items.length + ' laporan offline.', 'info');
      }
    });
  });

  window.addEventListener('offline', function () {
    renderWeakSignalBar();
    renderLoginOfflineBanner();
  });

  window.addEventListener('load', function () {
    applyFontScalePref();

    if (isCapacitorNative()) {
      document.body.classList.add('pfa-native-apk');
      try {
        if (window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater && typeof window.Capacitor.Plugins.CapacitorUpdater.notifyAppReady === 'function') {
          window.Capacitor.Plugins.CapacitorUpdater.notifyAppReady();
        }
      } catch (eOta) {}
      try {
        if (window.Capacitor.Plugins && window.Capacitor.Plugins.App && typeof window.Capacitor.Plugins.App.getInfo === 'function') {
          window.Capacitor.Plugins.App.getInfo().then(function (info) {
            if (info && info.version) localStorage.setItem('pfa_native_apk_version', String(info.version).trim());
          }).catch(function () {});
        }
      } catch (eInfo) {}
    }

    renderWeakSignalBar();
    renderLoginOfflineBanner();
    refreshOfflineQueueBanner();
    injectPortalGreeting();
    injectAndroidTutorialCard();
    injectEnhancedMenuItems();
    enhanceInputsUniversal();
    wrapSwitchTabWithEnhancements();
    wrapSetLoadingWithSlowCancel();
    bindGlobalDelegatedListeners();
    updateBottomNavDraftDots();

    setTimeout(ensureMasterKerusakanLoaded, 450);
    setTimeout(updateAllPhotoSizeIndicators, 600);
    setTimeout(showPostUpdateChangelogIfNeeded, 900);
    setTimeout(function () { checkAppUpdateOnLaunch(false); }, 1800);

    // Prioritas tombol Back Android (Bebas bentrok: Modal -> Form Guard -> Double-Back Exit)
    if (isCapacitorNative() && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
      window.Capacitor.Plugins.App.addListener('backButton', function (ev) {
        var openModal = document.querySelector('.modal.show');
        if (openModal && typeof bootstrap !== 'undefined') {
          var inst = bootstrap.Modal.getInstance(openModal);
          if (inst) { inst.hide(); return; }
        }
        var portalEl = document.getElementById('tab-portal');
        if (!portalEl && ev && ev.canGoBack) {
          window.history.back();
          return;
        }
        var curTab = getActiveVisibleTabName();
        var appVisible = document.getElementById('appScreen') && !document.getElementById('appScreen').classList.contains('d-none');
        if (appVisible && curTab !== 'portal' && typeof window.switchTab === 'function') {
          window.switchTab('portal');
          return;
        }
        // Double-Back to Exit (dalam 2 detik)
        var now = Date.now();
        if (now - LAST_BACK_TS < 2000) {
          window.Capacitor.Plugins.App.exitApp();
        } else {
          LAST_BACK_TS = now;
          if (typeof window.showToast === 'function') {
            window.showToast('Tekan kembali sekali lagi untuk keluar aplikasi.', 'dark');
          }
        }
      });
    }
  });
})();

/* =====================================================================
 * PFA AI NEON UI ENHANCER (v2.0.5) — Mode Cepat/Pro, Mic Voice-to-Text,
 * Persistent Chat History, Copy/Share WA per Bubble, & Auto-Fill IDPEL
 * ===================================================================== */
(function () {
  'use strict';

  var AI_HISTORY_KEY = 'pfa_ai_neon_history_v1';
  var AI_MODE_KEY = 'pfa_ai_neon_mode_v1';
  var LAST_AI_DETECTED_ID = '';

  function getAiMode() {
    try { return localStorage.getItem(AI_MODE_KEY) || 'auto'; } catch (e) { return 'auto'; }
  }

  function setAiMode(mode) {
    try { localStorage.setItem(AI_MODE_KEY, mode); } catch (e) {}
    var sel = document.getElementById('pfaAiModeSelect');
    if (sel) sel.value = mode;
  }

  function saveAiHistoryLocal(entries) {
    try {
      var trimmed = (entries || []).slice(-20);
      localStorage.setItem(AI_HISTORY_KEY, JSON.stringify(trimmed));
    } catch (e) {}
  }

  function loadAiHistoryLocal() {
    try {
      var raw = localStorage.getItem(AI_HISTORY_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return [];
  }

  function injectAiNeonControls() {
    var tab = document.getElementById('tab-chatbot');
    if (!tab || document.getElementById('pfaAiModeSelect')) return;

    // 1. Tambahkan pemilih Mode AI (Auto / Cepat / Pro) di sebelah tombol Reset
    var resetBtn = tab.querySelector('button[onclick*="resetChatAi"]');
    if (resetBtn && resetBtn.parentElement) {
      var sel = document.createElement('select');
      sel.id = 'pfaAiModeSelect';
      sel.className = 'form-select form-select-sm';
      sel.style.width = 'auto';
      sel.style.fontSize = '0.74rem';
      sel.title = 'Pilih kecepatan/kecerdasan AI';
      sel.innerHTML =
        '<option value="auto">⚡ Auto (Neon)</option>' +
        '<option value="fast">🚀 Cepat</option>' +
        '<option value="pro">🧠 Pro (Detail)</option>';
      sel.value = getAiMode();
      sel.onchange = function () {
        setAiMode(sel.value);
        if (typeof window.showToast === 'function') {
          var lbl = sel.value === 'pro' ? 'Mode Pro aktif (analisa mendalam).' : (sel.value === 'fast' ? 'Mode Cepat aktif (respon ekstra kilat).' : 'Mode Auto Neon aktif.');
          window.showToast(lbl, 'info');
        }
      };
      resetBtn.parentElement.insertBefore(sel, resetBtn);
    }

    // 2. Tambahkan Quick Chip "Rapikan Kronologi BA"
    var chipsBar = tab.querySelector('.d-flex.flex-nowrap.overflow-auto');
    if (chipsBar) {
      var btnBa = document.createElement('button');
      btnBa.type = 'button';
      btnBa.className = 'btn btn-sm btn-outline-success rounded-pill py-0 px-2 flex-shrink-0';
      btnBa.style.fontSize = '0.72rem';
      btnBa.textContent = '📝 Rapikan Kronologi BA';
      btnBa.onclick = function () {
        var inp = document.getElementById('chatAiInput');
        if (inp) {
          inp.value = 'Tolong rapikan catatan lapangan ini menjadi kronologi Berita Acara PLN yang formal: ';
          inp.focus();
        }
      };
      chipsBar.appendChild(btnBa);
    }

    // 3. Tambahkan tombol Mikrofon (Voice-to-Text Bahasa Indonesia) di form chat AI
    var chatInp = document.getElementById('chatAiInput');
    if (chatInp && chatInp.parentElement) {
      var SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRec) {
        var micBtn = document.createElement('button');
        micBtn.type = 'button';
        micBtn.id = 'pfaAiMicBtn';
        micBtn.className = 'btn btn-outline-secondary px-2';
        micBtn.title = 'Tanya dengan Suara (Bahasa Indonesia)';
        micBtn.innerHTML = '<i class="bi bi-mic-fill"></i>';
        var rec = null;
        var listening = false;

        micBtn.onclick = function () {
          if (listening && rec) {
            try { rec.stop(); } catch (e) {}
            return;
          }
          try {
            rec = new SpeechRec();
            rec.lang = 'id-ID';
            rec.interimResults = false;
            rec.maxAlternatives = 1;
            listening = true;
            micBtn.className = 'btn btn-danger px-2';
            micBtn.innerHTML = '<i class="bi bi-stop-circle-fill"></i>';
            if (typeof window.showToast === 'function') window.showToast('Silakan bicara (Bahasa Indonesia)...', 'info');

            rec.onresult = function (ev) {
              var txt = ev.results && ev.results[0] && ev.results[0][0] ? ev.results[0][0].transcript : '';
              if (txt) {
                chatInp.value = (chatInp.value ? chatInp.value + ' ' : '') + txt;
                chatInp.focus();
              }
            };
            rec.onerror = function () {
              if (typeof window.showToast === 'function') window.showToast('Suara tidak terdengar atau izin mikrofon ditolak.', 'warning');
            };
            rec.onend = function () {
              listening = false;
              micBtn.className = 'btn btn-outline-secondary px-2';
              micBtn.innerHTML = '<i class="bi bi-mic-fill"></i>';
            };
            rec.start();
          } catch (e) {
            listening = false;
          }
        };
        chatInp.parentElement.insertBefore(micBtn, chatInp.nextSibling);
      }
    }
  }

  // Tambahkan tombol Salin & Share WA + info kecepatan di gelembung jawaban AI terbaru
  function decorateLatestAiBubble(metaRes) {
    var box = document.getElementById('chatAiBox');
    if (!box) return;
    var bubbles = box.querySelectorAll('.bg-white.border');
    if (!bubbles.length) return;
    var lastBubble = bubbles[bubbles.length - 1];
    if (lastBubble.dataset.pfaNeonDecorated) return;
    lastBubble.dataset.pfaNeonDecorated = '1';

    var rawReply = (metaRes && metaRes.reply) || lastBubble.innerText || '';
    var cleanCopy = rawReply.replace(/\[OPSI:[^\]]+\]/gi, '').trim();

    var footer = document.createElement('div');
    footer.className = 'mt-2 pt-1 border-top d-flex justify-content-between align-items-center flex-wrap gap-1';
    footer.style.fontSize = '0.7rem';

    var metaTags = [];
    if (metaRes && metaRes.latencyMs) metaTags.push('⚡ ' + (metaRes.latencyMs / 1000).toFixed(1) + ' dtk');
    if (metaRes && metaRes.cached) metaTags.push('Instan');
    if (metaRes && Array.isArray(metaRes.contextBadges) && metaRes.contextBadges.length) {
      metaTags.push('Live: ' + metaRes.contextBadges.join('+'));
    }

    var leftSpan = document.createElement('span');
    leftSpan.className = 'text-muted';
    leftSpan.textContent = metaTags.join(' • ') || 'PFA AI Neon';

    var rightWrap = document.createElement('div');
    rightWrap.className = 'd-flex gap-1';

    var btnCopy = document.createElement('button');
    btnCopy.type = 'button';
    btnCopy.className = 'btn btn-light border py-0 px-2';
    btnCopy.style.fontSize = '0.68rem';
    btnCopy.innerHTML = '<i class="bi bi-clipboard me-1"></i>Salin';
    btnCopy.onclick = function () {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(cleanCopy).then(function () {
          if (typeof window.showToast === 'function') window.showToast('Jawaban AI disalin.', 'success');
        });
      }
    };

    var btnWa = document.createElement('a');
    btnWa.href = 'https://wa.me/?text=' + encodeURIComponent(cleanCopy);
    btnWa.target = '_blank';
    btnWa.rel = 'noopener noreferrer';
    btnWa.className = 'btn btn-light border py-0 px-2 text-success text-decoration-none';
    btnWa.style.fontSize = '0.68rem';
    btnWa.innerHTML = '<i class="bi bi-whatsapp me-1"></i>WA';

    rightWrap.appendChild(btnCopy);
    rightWrap.appendChild(btnWa);
    footer.appendChild(leftSpan);
    footer.appendChild(rightWrap);
    lastBubble.appendChild(footer);
  }

  // Intercept callApi untuk menyuntikkan aiMode, simpan riwayat chat lokal, & tangkap detectedId
  function hookCallApiForAiNeon() {
    if (typeof window.callApi !== 'function' || window._pfaAiNeonHooked) return;
    window._pfaAiNeonHooked = true;
    var prevCallApi = window.callApi;

    window.callApi = function (payload) {
      if (payload && payload.action === 'tanya_ai_lapangan') {
        var nextPayload = Object.assign({}, payload, { aiMode: getAiMode() });
        return prevCallApi(nextPayload).then(function (res) {
          if (res && res.status === 'success') {
            if (res.detectedId) LAST_AI_DETECTED_ID = res.detectedId;
            // Simpan ke riwayat lokal
            var saved = loadAiHistoryLocal();
            saved.push({ role: 'user', text: String(payload.prompt || '[Foto OCR]') });
            saved.push({ role: 'model', text: String(res.reply || ''), searchMode: res.searchMode || '' });
            saveAiHistoryLocal(saved);
            setTimeout(function () { decorateLatestAiBubble(res); }, 80);
          }
          return res;
        });
      }
      return prevCallApi(payload);
    };
  }

  // Upgrade handleAiOptionClick_ agar otomatis mengisi IDPEL ke modul tujuan!
  function hookAiOptionNavigation() {
    if (typeof window.handleAiOptionClick_ !== 'function' || window._pfaAiOptHooked) return;
    window._pfaAiOptHooked = true;
    var origOpt = window.handleAiOptionClick_;
    window.handleAiOptionClick_ = function (optText) {
      var low = String(optText || '').toLowerCase();
      origOpt(optText);
      if (!LAST_AI_DETECTED_ID) return;
      setTimeout(function () {
        if (low.indexOf('cek kct') !== -1 && low.indexOf('buka') !== -1) {
          var kInp = document.getElementById('kctKeywordInput');
          if (kInp) { kInp.value = LAST_AI_DETECTED_ID; kInp.dispatchEvent(new Event('input', { bubbles: true })); }
        } else if ((low.indexOf('gangguan') !== -1 || low.indexOf('laporan dg') !== -1) && low.indexOf('buka') !== -1) {
          var gInp = document.getElementById('cariPelangganInput');
          if (gInp) { gInp.value = LAST_AI_DETECTED_ID; gInp.dispatchEvent(new Event('input', { bubbles: true })); }
        } else if (low.indexOf('pengukuran') !== -1 && low.indexOf('buka') !== -1) {
          var uInp = document.getElementById('u_cari_pelanggan');
          if (uInp) { uInp.value = LAST_AI_DETECTED_ID; uInp.dispatchEvent(new Event('input', { bubbles: true })); }
        } else if (low.indexOf('p2tl') !== -1 && (low.indexOf('buka') !== -1 || low.indexOf('lanjut ke') !== -1)) {
          var pInp = document.getElementById('p2tl_cari_pelanggan');
          if (pInp) { pInp.value = LAST_AI_DETECTED_ID; pInp.dispatchEvent(new Event('input', { bubbles: true })); }
        }
      }, 220);
    };
  }

  // Pulihkan riwayat chat AI lokal & bersihkan saat Reset Chat
  function restoreAiChatHistoryAndHookReset() {
    var saved = loadAiHistoryLocal();
    if (saved.length > 0 && typeof window.appendChatBubble === 'function') {
      saved.forEach(function (item) {
        if (item && item.text) {
          window.appendChatBubble(item.role === 'model' ? 'model' : 'user', item.text, '', [], item.searchMode || '');
        }
      });
    }
    if (typeof window.resetChatAi === 'function' && !window._pfaResetAiHooked) {
      window._pfaResetAiHooked = true;
      var origReset = window.resetChatAi;
      window.resetChatAi = function () {
        try { localStorage.removeItem(AI_HISTORY_KEY); } catch (e) {}
        LAST_AI_DETECTED_ID = '';
        return origReset();
      };
    }
  }

  window.addEventListener('load', function () {
    injectAiNeonControls();
    hookCallApiForAiNeon();
    hookAiOptionNavigation();
    setTimeout(restoreAiChatHistoryAndHookReset, 350);
  });
})();

/* ==========================================================================
   PFA v2.0.8 — PLN Corporate Pro Portal, Dark Mode & Wave 2 Reliability Engine
   Pengembang: JODI SETIAWAN — PLN ULP Pelabuhan Ratu
   Arsitektur: Event-driven, zero polling, 100% kompatibel dengan fungsi lama
   ========================================================================== */
(function () {
  'use strict';

  var PFA_V208_VERSION = '2.1.11';
  var DARK_MODE_KEY = 'pfa_dark_mode_v1';
  var RECENT_ACT_KEY = 'pfa_recent_activity_v1';
  var TTL_CACHE_PREFIX = 'pfa_ttl_cache_v1_';
  var BETA_CHANNEL_KEY = 'pfa_beta_channel_v1';
  var MUTATING_ACTIONS = ['simpan_gangguan', 'simpan_pengukuran', 'simpan_p2tl', 'ajukan_material'];
  var CACHEABLE_ACTIONS = { get_master_kerusakan: 86400000 }; // Material selalu real-time (tanpa cache 24 jam)
  var CRASH_REPORTS_SENT = 0;
  var LAST_VISIBLE_TS = Date.now();

  var V208_RELEASE_HISTORY = [
    {
      ver: '2.0.9',
      title: 'PLN Corporate Pro UI + Reliability Engine',
      items: [
        'Desain ulang Portal berjenjang tema warna khas PLN (Deep Navy, Cyan, Kuning Listrik) + PLN Night Dark Mode.',
        'Quick Search IDPEL / No. Meter + Scan Barcode langsung dari Portal & ringkasan status real-time.',
        'Tombol Analisa AI Neon langsung dari hasil Pengukuran Deviasi.',
        'Reliability Wave 1 & 2: Idempotency anti-dobel, Write Lock, Formula Guard, Auto-Retry Exponential Backoff, Auto-Sync saat sinyal kembali, Cache Master 24 jam, & Logout Guard antrean offline.',
        'Beta Tester Channel (khusus akun ADMIN) & Safe Mode Reset Cache di Menu ☰.'
      ]
    },
    {
      ver: '2.0.7',
      title: 'Kalibrasi Pengukuran SPLN D3.015-2:2023',
      items: [
        'Kalibrasi 100% rumus Stopwatch, KW Meter (termasuk CT terbalik/negatif), dan rata-rata 3 sampel daya sesaat.',
        'Standar Rasio CT TR sesuai SPLN D3.015-2:2023 Tabel 4 (105 kVA = 150/5, 147 kVA = 200/5).'
      ]
    },
    {
      ver: '2.0.6',
      title: 'Smart KB & Free Tier AI Stability',
      items: [
        'Peningkatan pencarian Knowledge Base (stemmer Indonesia + IDF + bigram) & optimalisasi model Gemini Free Tier.'
      ]
    },
    {
      ver: '2.0.5',
      title: 'PFA AI Neon Assistant',
      items: [
        'Auto-lookup 3 sumber data (DIL + Riwayat Gangguan + Cek KCT), Voice-to-Text, & pintasan auto-fill IDPEL.'
      ]
    }
  ];

  // --------------------------------------------------------------------------
  // 1. UTILITAS AMAN (ROLE, IDEMPOTENCY, STORAGE GUARD, TTL CACHE)
  // --------------------------------------------------------------------------
  function getCurrentUserObj() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.user ? parsed.user : parsed;
    } catch (e) {
      return null;
    }
  }

  function isCurrentUserAdmin() {
    var u = getCurrentUserObj();
    var role = u && (u.role || u.Role || u.jabatan) ? String(u.role || u.Role || u.jabatan).toUpperCase() : '';
    if (role.indexOf('ADMIN') !== -1) return true;
    var roleEl = document.getElementById('portalRoleText');
    if (roleEl && String(roleEl.textContent || '').toUpperCase().indexOf('ADMIN') !== -1) return true;
    return false;
  }

  function generateClientRequestId(action) {
    return 'pfa_' + String(action || 'req') + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  }

  function checkStorageQuotaAndPrune() {
    try {
      var totalBytes = 0;
      var ttlKeys = [];
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        var v = localStorage.getItem(k) || '';
        totalBytes += (k.length + v.length) * 2;
        if (k.indexOf(TTL_CACHE_PREFIX) === 0) ttlKeys.push(k);
      }
      // Jika > 3.8 MB (~80% batas 5MB), bersihkan cache TTL lama
      if (totalBytes > 3800000) {
        ttlKeys.forEach(function (tk) {
          try { localStorage.removeItem(tk); } catch (e) {}
        });
      }
    } catch (e) {}
  }

  function readTtlCache(action) {
    try {
      var raw = localStorage.getItem(TTL_CACHE_PREFIX + action);
      if (!raw) return null;
      var obj = JSON.parse(raw);
      if (!obj || !obj.exp || Date.now() > obj.exp) {
        localStorage.removeItem(TTL_CACHE_PREFIX + action);
        return null;
      }
      return obj.data;
    } catch (e) {
      return null;
    }
  }

  function writeTtlCache(action, data, ttlMs) {
    try {
      checkStorageQuotaAndPrune();
      localStorage.setItem(TTL_CACHE_PREFIX + action, JSON.stringify({
        exp: Date.now() + ttlMs,
        data: data
      }));
    } catch (e) {}
  }

  // --------------------------------------------------------------------------
  // 2. PLN NIGHT DARK MODE
  // --------------------------------------------------------------------------
  function applyDarkMode(enabled, persist) {
    var html = document.documentElement;
    if (enabled) {
      html.classList.add('pfa-dark-mode');
    } else {
      html.classList.remove('pfa-dark-mode');
    }
    var metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute('content', enabled ? '#0b1426' : '#003b73');

    var icon = document.getElementById('pfaQuickThemeIcon');
    if (icon) {
      icon.className = enabled ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
    }
    var menuLabel = document.getElementById('pfaMenuDarkLabel');
    if (menuLabel) {
      menuLabel.textContent = enabled ? 'Tema: PLN Night (Gelap)' : 'Tema: PLN Pro (Terang)';
    }
    if (persist) {
      try { localStorage.setItem(DARK_MODE_KEY, enabled ? '1' : '0'); } catch (e) {}
    }
  }

  function initDarkMode() {
    var saved = '0';
    try { saved = localStorage.getItem(DARK_MODE_KEY) || '0'; } catch (e) {}
    applyDarkMode(saved === '1', false);

    var quickBtn = document.getElementById('pfaQuickThemeBtn');
    if (quickBtn && !quickBtn._pfaBound) {
      quickBtn._pfaBound = true;
      quickBtn.addEventListener('click', function () {
        var next = !document.documentElement.classList.contains('pfa-dark-mode');
        applyDarkMode(next, true);
      });
    }
  }

  // --------------------------------------------------------------------------
  // 3. COMMAND PORTAL LIVE SYNC & RECENT ACTIVITY
  // --------------------------------------------------------------------------
  function getGreetingByHour() {
    var h = new Date().getHours();
    if (h >= 4 && h < 11) return 'Selamat Pagi';
    if (h >= 11 && h < 15) return 'Selamat Siang';
    if (h >= 15 && h < 18) return 'Selamat Sore';
    return 'Selamat Malam';
  }

  function recordRecentActivity(label, detail, statusText) {
    try {
      var list = JSON.parse(localStorage.getItem(RECENT_ACT_KEY) || '[]');
      if (!Array.isArray(list)) list = [];
      var now = new Date();
      var hh = String(now.getHours()).padStart(2, '0');
      var mm = String(now.getMinutes()).padStart(2, '0');
      list.unshift({
        label: String(label || 'Aktivitas'),
        detail: String(detail || '-'),
        status: String(statusText || 'Selesai'),
        time: hh + ':' + mm
      });
      if (list.length > 10) list = list.slice(0, 10);
      localStorage.setItem(RECENT_ACT_KEY, JSON.stringify(list));
      renderPortalRecentList();
    } catch (e) {}
  }

  function renderPortalRecentList() {
    if (window._pfaServerRecentLoaded) return;
    var box = document.getElementById('pfaPortalRecentList');
    if (!box) return;
    var list = [];
    try { list = JSON.parse(localStorage.getItem(RECENT_ACT_KEY) || '[]'); } catch (e) {}
    if (!Array.isArray(list) || list.length === 0) {
      box.innerHTML = '<div class="pfa-recent-empty"><i class="bi bi-clock-history me-2"></i>Belum ada aktivitas lokal hari ini.</div>';
      return;
    }
    var statLap = document.getElementById('pfaStatLaporan');
    if (statLap) statLap.textContent = String(list.length);

    box.innerHTML = list.slice(0, 3).map(function (it) {
      var safeLabel = String(it.label || '').replace(/</g, '&lt;');
      var safeDet = String(it.detail || '').replace(/</g, '&lt;');
      var safeSt = String(it.status || '').replace(/</g, '&lt;');
      var safeTm = String(it.time || '').replace(/</g, '&lt;');
      return (
        '<div class="pfa-recent-row">' +
          '<div class="min-w-0">' +
            '<div class="fw-bold text-truncate">' + safeLabel + '</div>' +
            '<div class="text-muted text-truncate" style="font-size:0.7rem;">' + safeDet + ' • ' + safeTm + '</div>' +
          '</div>' +
          '<span class="badge rounded-pill text-bg-primary flex-shrink-0" style="font-size:0.65rem;">' + safeSt + '</span>' +
        '</div>'
      );
    }).join('');
  }

  function countOfflineQueueItems(cb) {
    try {
      var req = indexedDB.open('pfa_offline_queue_db', 1);
      req.onsuccess = function (ev) {
        try {
          var db = ev.target.result;
          if (!db.objectStoreNames.contains('pending_submissions')) { cb(0); return; }
          var tx = db.transaction('pending_submissions', 'readonly');
          var cntReq = tx.objectStore('pending_submissions').count();
          cntReq.onsuccess = function () { cb(Number(cntReq.result || 0)); };
          cntReq.onerror = function () { cb(0); };
        } catch (e) { cb(0); }
      };
      req.onerror = function () { cb(0); };
    } catch (e) { cb(0); }
  }

  function refreshPortalDashboard() {
    var navNama = document.getElementById('navUserNama');
    var greetEl = document.getElementById('pfaPortalGreetingName');
    if (greetEl) {
      var nama = (navNama && navNama.textContent && navNama.textContent.trim() !== 'Petugas')
        ? navNama.textContent.trim()
        : (getCurrentUserObj() && getCurrentUserObj().nama) || 'Petugas';
      greetEl.textContent = getGreetingByHour() + ', ' + nama;
    }

    var isOnline = navigator.onLine !== false;
    var onlinePill = document.getElementById('pfaPortalOnlinePill');
    var statServer = document.getElementById('pfaStatServer');
    if (onlinePill) {
      onlinePill.classList.toggle('is-offline', !isOnline);
      onlinePill.innerHTML = '<span class="pfa-online-dot"></span>' + (isOnline ? 'Online' : 'Offline');
    }
    if (statServer) {
      statServer.textContent = isOnline ? 'Aktif' : 'Offline';
      statServer.classList.toggle('pfa-stat-ok', isOnline);
      statServer.classList.toggle('pfa-stat-warn', !isOnline);
    }

    countOfflineQueueItems(function (cnt) {
      var statAnt = document.getElementById('pfaStatAntrean');
      var subOff = document.getElementById('pfaPortalOfflineSub');
      if (statAnt) {
        statAnt.textContent = String(cnt);
        statAnt.classList.toggle('pfa-stat-warn', cnt > 0);
      }
      if (subOff) {
        subOff.textContent = cnt > 0 ? (cnt + ' menunggu sinkron') : 'Semua tersinkron';
      }
    });

    renderPortalRecentList();
    syncAdminBetaMenuVisibility();
  }

  // --------------------------------------------------------------------------
  // 4. PORTAL QUICK SEARCH & BARCODE SCAN
  // --------------------------------------------------------------------------
  function executePortalQuickSearch() {
    var inp = document.getElementById('pfaPortalQuickSearch');
    if (!inp) return;
    var raw = String(inp.value || '').trim();
    if (!raw) {
      inp.focus();
      return;
    }
    var lower = raw.toLowerCase();
    var targetTab = 'gangguan';
    var keyword = raw.replace(/\s+/g, '');
    if (lower.indexOf('kct ') === 0) {
      targetTab = 'kct';
      keyword = raw.slice(4).trim();
    }
    if (typeof window.switchTab === 'function') window.switchTab(targetTab);
    setTimeout(function () {
      if (targetTab === 'kct') {
        var kInp = document.getElementById('kctKeywordInput');
        if (kInp) {
          kInp.value = keyword;
          kInp.dispatchEvent(new Event('input', { bubbles: true }));
          var kBtn = document.querySelector('#tab-kct button[onclick*="cariKct"], #tab-kct button[type="submit"]');
          if (kBtn) kBtn.click();
        }
      } else {
        var gInp = document.getElementById('cariPelangganInput');
        if (gInp) {
          gInp.value = keyword;
          gInp.dispatchEvent(new Event('input', { bubbles: true }));
          var gBtn = document.querySelector('#tab-gangguan button[onclick*="cariDataPelanggan"]');
          if (gBtn) gBtn.click();
        }
      }
    }, 180);
  }

  function initPortalQuickSearch() {
    var inp = document.getElementById('pfaPortalQuickSearch');
    var goBtn = document.getElementById('pfaPortalQuickSearchGo');
    var scanBtn = document.getElementById('pfaPortalQuickScan');

    if (goBtn && !goBtn._pfaBound) {
      goBtn._pfaBound = true;
      goBtn.addEventListener('click', executePortalQuickSearch);
    }
    if (inp && !inp._pfaBound) {
      inp._pfaBound = true;
      inp.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          executePortalQuickSearch();
        }
      });
    }
    if (scanBtn && !scanBtn._pfaBound) {
      scanBtn._pfaBound = true;
      scanBtn.addEventListener('click', function () {
        if (typeof window.openBarcodeScanner === 'function') {
          window.openBarcodeScanner('pfaPortalQuickSearch');
        } else if (typeof window.showToast === 'function') {
          window.showToast('Scanner barcode belum siap.', 'warning');
        }
      });
    }
  }

  // --------------------------------------------------------------------------
  // 5. AI NEON INSIGHT BUTTON DI TAB PENGUKURAN
  // --------------------------------------------------------------------------
  function injectPengukuranAiInsightBtn() {
    var tabUkur = document.getElementById('tab-pengukuran');
    if (!tabUkur || document.getElementById('pfaBtnAiInsightUkur')) return;
    var resultBox = tabUkur.querySelector('#hasilPengukuranBox, #boxHasilPengukuran, .alert-info, .card-body');
    if (!resultBox) return;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'pfaBtnAiInsightUkur';
    btn.className = 'btn btn-sm pfa-ai-insight-btn rounded-3 mt-2 w-100';
    btn.innerHTML = '<i class="bi bi-lightning-charge-fill text-warning me-1"></i> Analisa Hasil Pengukuran dengan PFA AI';
    btn.addEventListener('click', function () {
      var idpel = (document.getElementById('u_idpel') && document.getElementById('u_idpel').value) || '-';
      var errEl = document.getElementById('u_error_kwh') || document.getElementById('u_hasil_error');
      var errVal = errEl ? (errEl.value || errEl.textContent || '-') : '-';
      var p1El = document.getElementById('u_p1');
      var p2El = document.getElementById('u_p2');
      var promptText =
        'Tolong analisa hasil pengukuran kWh meter berikut sesuai SPLN & Perdir P2TL: ' +
        'IDPEL ' + idpel + ', Error kWh = ' + errVal +
        (p1El && p1El.value ? ', P1 = ' + p1El.value + ' kW' : '') +
        (p2El && p2El.value ? ', P2 = ' + p2El.value + ' kW' : '') +
        '. Apa indikasi kelainan dan tindak lanjut lapangannya?';

      if (typeof window.switchTab === 'function') window.switchTab('chatbot');
      setTimeout(function () {
        var chatInp = document.getElementById('chatPromptInput');
        if (chatInp) {
          chatInp.value = promptText;
          chatInp.focus();
        }
      }, 220);
    });
    resultBox.appendChild(btn);
  }

  // --------------------------------------------------------------------------
  // 6. WAVE 2 RELIABILITY WRAPPER (IDEMPOTENCY, BACKOFF, CACHE 24H, PAYLOAD GUARD)
  // --------------------------------------------------------------------------
  function sleepMs(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  function isRetryableNetworkError(err) {
    var msg = String((err && err.message) || err || '').toLowerCase();
    if (msg.indexOf('session_expired') !== -1 || msg.indexOf('password') !== -1 || msg.indexOf('terkunci') !== -1) {
      return false;
    }
    return (
      msg.indexOf('network') !== -1 ||
      msg.indexOf('timeout') !== -1 ||
      msg.indexOf('failed to fetch') !== -1 ||
      msg.indexOf('503') !== -1 ||
      msg.indexOf('502') !== -1 ||
      msg.indexOf('504') !== -1 ||
      msg.indexOf('unavailable') !== -1
    );
  }

  function wrapCallApiReliability() {
    if (typeof window.callApi !== 'function' || window._pfaV208ApiWrapped) return;
    window._pfaV208ApiWrapped = true;
    var origCallApi = window.callApi;

    window.callApi = async function (payload) {
      var req = payload && typeof payload === 'object' ? Object.assign({}, payload) : payload;
      var action = req && req.action ? String(req.action).trim() : '';

      // 1. TTL Cache 24 jam untuk data master (buka form instan)
      if (CACHEABLE_ACTIONS[action] && !req._bypassCache) {
        var cached = readTtlCache(action);
        if (cached) return cached;
      }

      // 2. Idempotency Key otomatis untuk aksi simpan/mutasi
      if (MUTATING_ACTIONS.indexOf(action) !== -1 && !req.clientRequestId) {
        req.clientRequestId = generateClientRequestId(action);
      }

      // 3. Dynamic Timeout Hint (25s baca / 90s upload multi-foto)
      if (!req._timeoutMs) {
        req._timeoutMs = MUTATING_ACTIONS.indexOf(action) !== -1 ? 90000 : 25000;
      }

      // 4. Payload > 2.5MB Guard
      try {
        var bytes = JSON.stringify(req).length;
        if (bytes > 2621440 && typeof window.showToast === 'function') {
          window.showToast('Ukuran foto cukup besar (' + (bytes / 1048576).toFixed(1) + ' MB). Aktifkan Mode Sinyal Lemah agar lebih cepat.', 'warning');
        }
      } catch (eSize) {}

      // 5. Exponential Backoff Auto-Retry (maks 2x retry untuk gangguan jaringan/503)
      var maxRetries = MUTATING_ACTIONS.indexOf(action) !== -1 ? 1 : 2;
      var attempt = 0;
      while (true) {
        try {
          var res = await origCallApi(req);

          if (CACHEABLE_ACTIONS[action] && res && res.status === 'success') {
            writeTtlCache(action, res, CACHEABLE_ACTIONS[action]);
          }
          if (MUTATING_ACTIONS.indexOf(action) !== -1 && res && res.status === 'success') {
            var lblMap = {
              simpan_gangguan: 'Laporan Meter Rusak',
              simpan_pengukuran: 'Pengukuran Deviasi',
              simpan_p2tl: 'Temuan P2TL',
              ajukan_material: 'Transaksi Material'
            };
            var det = (req.data && (req.data.idpel || req.data.noSurat || req.data.nama)) || 'Terkirim';
            recordRecentActivity(lblMap[action] || action, String(det), res.queuedOffline ? 'Antrean' : 'Terkirim');
            setTimeout(refreshPortalDashboard, 300);
          }
          return res;
        } catch (err) {
          attempt++;
          if (attempt <= maxRetries && isRetryableNetworkError(err)) {
            await sleepMs(1200 * attempt);
            continue;
          }
          throw err;
        }
      }
    };
  }

  // --------------------------------------------------------------------------
  // 7. AUTO-SYNC SAAT SINYAL KEMBALI, SILENT HEARTBEAT & LOGOUT GUARD
  // --------------------------------------------------------------------------
  function initNetworkAutoSyncAndHeartbeat() {
    function triggerAutoSync() {
      refreshPortalDashboard();
      countOfflineQueueItems(function (cnt) {
        if (cnt > 0 && typeof window.pfaSyncOfflineQueue === 'function') {
          if (typeof window.showToast === 'function') {
            window.showToast('Koneksi kembali! Menyinkronkan ' + cnt + ' antrean offline...', 'info');
          }
          window.pfaSyncOfflineQueue();
        }
      });
    }

    window.addEventListener('online', triggerAutoSync);
    window.addEventListener('offline', refreshPortalDashboard);

    // @capacitor/network listener jika tersedia di APK native
    try {
      var capNet = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Network;
      if (capNet && typeof capNet.addListener === 'function') {
        capNet.addListener('networkStatusChange', function (st) {
          if (st && st.connected) triggerAutoSync();
          else refreshPortalDashboard();
        });
      }
    } catch (e) {}

    // Silent Session Heartbeat (event-driven saat kembali ke aplikasi > 15 menit, ZERO polling)
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'visible') {
        var idleMs = Date.now() - LAST_VISIBLE_TS;
        LAST_VISIBLE_TS = Date.now();
        refreshPortalDashboard();
        if (idleMs > 900000 && navigator.onLine !== false && typeof window.callApi === 'function') {
          window.callApi({ action: 'api_version_check' }).catch(function () {});
        }
      } else {
        LAST_VISIBLE_TS = Date.now();
      }
    });
  }

  function wrapLogoutGuard() {
    if (typeof window.logoutApp !== 'function' || window._pfaLogoutGuarded) return;
    window._pfaLogoutGuarded = true;
    var origLogout = window.logoutApp;
    window.logoutApp = function () {
      countOfflineQueueItems(function (cnt) {
        if (cnt > 0) {
          var ok = window.confirm(
            'Masih ada ' + cnt + ' laporan di Antrean Offline yang belum terkirim ke server.\n\n' +
            'Yakin tetap ingin keluar sekarang?'
          );
          if (!ok) return;
        }
        origLogout();
      });
    };
  }

  // --------------------------------------------------------------------------
  // 8. WEBP PHOTO COMPRESSOR, LAZY THUMBNAILS & DEBOUNCED SEARCH
  // --------------------------------------------------------------------------
  window.pfaCompressImageWebp = function (file, maxWidth, quality) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onerror = reject;
      reader.onload = function (e) {
        var img = new Image();
        img.onerror = reject;
        img.onload = function () {
          var mw = maxWidth || 1280;
          var ratio = img.width > mw ? mw / img.width : 1;
          var canvas = document.createElement('canvas');
          canvas.width = Math.round(img.width * ratio);
          canvas.height = Math.round(img.height * ratio);
          var ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          var webp = canvas.toDataURL('image/webp', quality || 0.78);
          if (webp && webp.indexOf('data:image/webp') === 0) {
            resolve(webp);
          } else {
            resolve(canvas.toDataURL('image/jpeg', quality || 0.8));
          }
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    });
  };

  function enableLazyImagesAndPagination() {
    try {
      var imgs = document.querySelectorAll('img.foto-preview, img.rekap-foto-img');
      imgs.forEach(function (im) {
        im.setAttribute('loading', 'lazy');
        im.setAttribute('decoding', 'async');
      });
    } catch (e) {}
  }

  // --------------------------------------------------------------------------
  // 9. SILENT CRASH REPORTER -> System_Logs (Maks 3x/sesi)
  // --------------------------------------------------------------------------
  function reportSilentCrash(msg, src) {
    if (CRASH_REPORTS_SENT >= 3 || navigator.onLine === false) return;
    if (typeof window.callApi !== 'function') return;
    CRASH_REPORTS_SENT++;
    var u = getCurrentUserObj();
    window.callApi({
      action: 'log_client_error',
      versi: PFA_V208_VERSION,
      username: (u && u.username) || '-',
      message: String(msg || 'Unknown error').slice(0, 300),
      source: String(src || '-').slice(0, 120)
    }).catch(function () {});
  }

  window.addEventListener('error', function (ev) {
    if (ev && ev.message) reportSilentCrash(ev.message, ev.filename + ':' + ev.lineno);
  });

  window.addEventListener('unhandledrejection', function (ev) {
    var reason = ev && ev.reason ? (ev.reason.message || String(ev.reason)) : '';
    if (reason && reason.toLowerCase().indexOf('network') === -1) {
      reportSilentCrash('Promise: ' + reason, 'unhandledrejection');
    }
  });

  // --------------------------------------------------------------------------
  // 10. MENU ☰: DARK MODE, RIWAYAT RILIS & SAFE MODE, BETA CHANNEL (ADMIN ONLY)
  // --------------------------------------------------------------------------
  function openReleaseHistoryModal() {
    var modalId = 'pfaReleaseHistoryModal';
    var el = document.getElementById(modalId);
    if (!el) {
      var htmlList = V208_RELEASE_HISTORY.map(function (r) {
        var bullets = r.items.map(function (it) {
          return '<li class="mb-1">' + it + '</li>';
        }).join('');
        return (
          '<div class="mb-3 pb-2 border-bottom">' +
            '<div class="d-flex justify-content-between align-items-center mb-1">' +
              '<span class="fw-bold text-primary">v' + r.ver + ' — ' + r.title + '</span>' +
            '</div>' +
            '<ul class="small mb-0 ps-3">' + bullets + '</ul>' +
          '</div>'
        );
      }).join('');

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">' +
          '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
            '<div class="modal-content rounded-4 border-0 shadow">' +
              '<div class="modal-header border-0 pb-1">' +
                '<h6 class="modal-title fw-bold"><i class="bi bi-clock-history me-2 text-primary"></i>Riwayat Rilis &amp; Safe Mode</h6>' +
                '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
              '</div>' +
              '<div class="modal-body pt-2">' +
                htmlList +
                '<div class="p-2 rounded-3 bg-light small mb-2">' +
                  '<div class="fw-bold">Pengembang Aplikasi</div>' +
                  '<div>JODI SETIAWAN — PLN ULP Pelabuhan Ratu</div>' +
                '</div>' +
                '<button type="button" id="pfaSafeModeResetBtn" class="btn btn-outline-warning btn-sm w-100 fw-semibold">' +
                  '<i class="bi bi-shield-exclamation me-1"></i> Safe Mode: Bersihkan Cache &amp; Muat Ulang' +
                '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';
      document.body.appendChild(wrap.firstElementChild);
      el = document.getElementById(modalId);

      var safeBtn = document.getElementById('pfaSafeModeResetBtn');
      if (safeBtn) {
        safeBtn.addEventListener('click', function () {
          if (!window.confirm('Bersihkan cache master & muat ulang aplikasi? (Antrean offline tetap aman)')) return;
          try {
            Object.keys(localStorage).forEach(function (k) {
              if (k.indexOf(TTL_CACHE_PREFIX) === 0) localStorage.removeItem(k);
            });
          } catch (e) {}
          window.location.reload();
        });
      }
    }
    if (window.bootstrap && window.bootstrap.Modal) {
      window.bootstrap.Modal.getOrCreateInstance(el).show();
    }
  }

  function syncAdminBetaMenuVisibility() {
    var betaLi = document.getElementById('pfaMenuBetaLi');
    if (!betaLi) return;
    if (isCurrentUserAdmin()) {
      betaLi.classList.remove('d-none');
    } else {
      betaLi.classList.add('d-none');
    }
  }

  function injectV208DropdownMenuItems() {
    var menuUl = document.querySelector('#appScreen .topbar-pln .dropdown-menu');
    if (!menuUl || document.getElementById('pfaMenuDarkLi')) return;

    var divider = menuUl.querySelector('.dropdown-divider');
    var anchorLi = divider ? divider.closest('li') : menuUl.lastElementChild;

    // 1. Toggle Dark Mode
    var darkLi = document.createElement('li');
    darkLi.id = 'pfaMenuDarkLi';
    darkLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2" id="pfaMenuDarkBtn">' +
        '<i class="bi bi-moon-stars-fill me-2 text-warning"></i>' +
        '<span id="pfaMenuDarkLabel">Tema: PLN Pro (Terang)</span>' +
      '</button>';
    darkLi.querySelector('button').addEventListener('click', function () {
      var next = !document.documentElement.classList.contains('pfa-dark-mode');
      applyDarkMode(next, true);
    });

    // 2. Riwayat Rilis & Safe Mode
    var relLi = document.createElement('li');
    relLi.id = 'pfaMenuReleaseLi';
    relLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2">' +
        '<i class="bi bi-stars me-2 text-info"></i> Riwayat Rilis &amp; Safe Mode' +
      '</button>';
    relLi.querySelector('button').addEventListener('click', openReleaseHistoryModal);

    // 3. Beta Tester Channel (KHUSUS ADMIN)
    var betaLi = document.createElement('li');
    betaLi.id = 'pfaMenuBetaLi';
    betaLi.className = 'd-none';
    var isBeta = false;
    try { isBeta = localStorage.getItem(BETA_CHANNEL_KEY) === '1'; } catch (e) {}
    betaLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2" id="pfaMenuBetaBtn">' +
        '<i class="bi bi-rocket-takeoff-fill me-2 text-primary"></i>' +
        '<span id="pfaMenuBetaLabel">Channel Beta (Admin): ' + (isBeta ? 'AKTIF' : 'OFF') + '</span>' +
      '</button>';
    betaLi.querySelector('button').addEventListener('click', function () {
      if (!isCurrentUserAdmin()) return;
      var cur = localStorage.getItem(BETA_CHANNEL_KEY) === '1';
      var next = !cur;
      try { localStorage.setItem(BETA_CHANNEL_KEY, next ? '1' : '0'); } catch (e) {}
      var lbl = document.getElementById('pfaMenuBetaLabel');
      if (lbl) lbl.textContent = 'Channel Beta (Admin): ' + (next ? 'AKTIF' : 'OFF');
      if (typeof window.showToast === 'function') {
        window.showToast('Beta Tester Channel ' + (next ? 'diaktifkan — memeriksa update Beta...' : 'dinonaktifkan') + ' (Khusus Admin).', 'info');
      }
      if (next && typeof window.pfaCheckAppUpdate === 'function') {
        setTimeout(function () { window.pfaCheckAppUpdate(true); }, 350);
      }
    });

    if (anchorLi && anchorLi.parentNode) {
      anchorLi.parentNode.insertBefore(darkLi, anchorLi);
      anchorLi.parentNode.insertBefore(relLi, anchorLi);
      anchorLi.parentNode.insertBefore(betaLi, anchorLi);
    } else {
      menuUl.appendChild(darkLi);
      menuUl.appendChild(relLi);
      menuUl.appendChild(betaLi);
    }
    applyDarkMode(document.documentElement.classList.contains('pfa-dark-mode'), false);
    syncAdminBetaMenuVisibility();
  }

  // Hook switchTab agar Portal selalu refresh saat dibuka kembali
  function hookSwitchTabForPortal() {
    if (typeof window.switchTab !== 'function' || window._pfaV208TabHooked) return;
    window._pfaV208TabHooked = true;
    var origSwitch = window.switchTab;
    window.switchTab = function (tabName) {
      var r = origSwitch.apply(this, arguments);
      if (tabName === 'portal') setTimeout(refreshPortalDashboard, 80);
      if (tabName === 'pengukuran') setTimeout(injectPengukuranAiInsightBtn, 120);
      return r;
    };
  }

  // Bootstrap seluruh fitur v2.0.8 setelah DOM siap
  function bootV208() {
    initDarkMode();
    initPortalQuickSearch();
    injectV208DropdownMenuItems();
    wrapCallApiReliability();
    wrapLogoutGuard();
    hookSwitchTabForPortal();
    initNetworkAutoSyncAndHeartbeat();
    enableLazyImagesAndPagination();
    setTimeout(refreshPortalDashboard, 350);
    setTimeout(injectPengukuranAiInsightBtn, 500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootV208);
  } else {
    bootV208();
  }
  window.addEventListener('load', function () {
    setTimeout(refreshPortalDashboard, 450);
  });
})();

/* ==========================================================================
   PFA v2.0.8 — Portal Live Summary Berbasis Role (Admin Semua / Petugas Sendiri)
   ========================================================================== */
(function () {
  'use strict';
  var LAST_SUMMARY_FETCH_TS = 0;
  var IS_FETCHING_SUMMARY = false;

  function getUserObjSafe() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.user ? parsed.user : parsed;
    } catch (e) { return null; }
  }

  function isAdminRole() {
    var u = getUserObjSafe();
    var r = u && (u.role || u.Role || u.jabatan) ? String(u.role || u.Role || u.jabatan).toUpperCase() : '';
    if (r.indexOf('ADMIN') !== -1) return true;
    var el = document.getElementById('portalRoleText');
    return Boolean(el && String(el.textContent || '').toUpperCase().indexOf('ADMIN') !== -1);
  }

  function renderServerRecent(items, scope) {
    window._pfaServerRecentLoaded = true;
    var box = document.getElementById('pfaPortalRecentList');
    if (!box) return;
    if (!Array.isArray(items) || items.length === 0) {
      box.innerHTML = '<div class="pfa-recent-empty"><i class="bi bi-clock-history me-2"></i>' +
        (scope === 'ALL_PETUGAS' ? 'Belum ada laporan petugas masuk.' : 'Belum ada laporan yang kamu kirim.') +
        '</div>';
      return;
    }
    box.innerHTML = items.slice(0, 5).map(function (it) {
      var m = String(it.modul || 'Laporan').replace(/</g, '&lt;');
      var d = String(it.detail || '-').replace(/</g, '&lt;');
      var t = String(it.timestamp || '').replace(/</g, '&lt;');
      var s = String(it.status || 'Terkirim').replace(/</g, '&lt;');
      return (
        '<div class="pfa-recent-row">' +
          '<div class="pfa-recent-top">' +
            '<span class="pfa-recent-title">' + m + '</span>' +
            '<span class="badge rounded-pill text-bg-primary pfa-recent-badge">' + s + '</span>' +
          '</div>' +
          '<div class="pfa-recent-detail">' + d + (t ? ' • ' + t : '') + '</div>' +
        '</div>'
      );
    }).join('');
  }

  function syncPortalSummaryFromServer(force) {
    if (IS_FETCHING_SUMMARY || navigator.onLine === false) return;
    if (typeof window.callApi !== 'function') return;
    var u = getUserObjSafe();
    if (!u) return;

    var now = Date.now();
    if (!force && (now - LAST_SUMMARY_FETCH_TS) < 45000) return;

    IS_FETCHING_SUMMARY = true;
    LAST_SUMMARY_FETCH_TS = now;

    window.callApi({
      action: 'get_portal_summary',
      petugasNama: u.nama || '',
      username: u.username || '',
      userRole: u.role || '',
      forceRefresh: Boolean(force)
    }).then(function (res) {
      IS_FETCHING_SUMMARY = false;
      if (!res || res.status !== 'success') return;

      var statLap = document.getElementById('pfaStatLaporan');
      if (statLap && res.counts) {
        statLap.textContent = String(res.counts.total || 0);
        var lblEl = statLap.parentElement && statLap.parentElement.querySelector('.pfa-stat-lbl');
        if (lblEl) {
          lblEl.textContent = (res.scope === 'ALL_PETUGAS') ? 'Semua Laporan' : 'Laporan Saya';
        }
        // Klik angka Laporan: Admin -> Backoffice Admin, Petugas -> Histori Saya
        if (statLap.parentElement) {
          statLap.parentElement.onclick = function () {
            if (res.scope === 'ALL_PETUGAS' && typeof window.switchTab === 'function') {
              window.switchTab('admin');
            } else if (typeof window.openHistoriSayaModal === 'function') {
              window.openHistoriSayaModal();
            }
          };
        }
      }
      renderServerRecent(res.recent || [], res.scope);
    }).catch(function () {
      IS_FETCHING_SUMMARY = false;
    });
  }

  // Hook switchTab & login agar angka langsung sinkron dari server
  function initV209PortalLive() {
    // Hapus kotak greeting putih duplikat jika sempat terbuat
    var dup = document.getElementById('pfaPortalGreeting');
    if (dup && dup.parentNode) dup.parentNode.removeChild(dup);

    if (typeof window.switchTab === 'function' && !window._pfaV209TabHooked) {
      window._pfaV209TabHooked = true;
      var orig = window.switchTab;
      window.switchTab = function (tabName) {
        var r = orig.apply(this, arguments);
        if (tabName === 'portal') setTimeout(function () { syncPortalSummaryFromServer(false); }, 150);
        return r;
      };
    }

    // Jika baru selesai simpan laporan, paksa refresh summary
    if (typeof window.callApi === 'function' && !window._pfaV209SaveHooked) {
      window._pfaV209SaveHooked = true;
      var origApi = window.callApi;
      window.callApi = async function (payload) {
        var res = await origApi(payload);
        var act = payload && payload.action;
        if (res && res.status === 'success' && (act === 'login' || act === 'simpan_gangguan' || act === 'simpan_pengukuran' || act === 'simpan_p2tl' || act === 'ajukan_material')) {
          setTimeout(function () { syncPortalSummaryFromServer(true); }, 450);
        }
        return res;
      };
    }

    setTimeout(function () { syncPortalSummaryFromServer(false); }, 700);
  }

  window.addEventListener('load', initV209PortalLive);
})();

/* ==========================================================================
   PFA v2.0.8 — All-Module PLN Corporate Pro Hero & Photo Checkmark Enhancer
   (Non-destruktif: 0 perubahan ID HTML, 100% aman untuk seluruh form & fungsi)
   ========================================================================== */
(function () {
  'use strict';

  var MODULE_HEROES = [
    {
      tabId: 'tab-gangguan',
      badge: 'OPERASIONAL METER',
      title: 'Input Meter Rusak & Gangguan',
      sub: 'Auto-fill Master DIL, lokasi gardu/tiang & unggah 4 foto bukti',
      icon: 'bi-tools'
    },
    {
      tabId: 'tab-p2tl',
      badge: 'PENERTIBAN P2TL',
      title: 'Temuan Potensi P2TL',
      sub: 'Perdir 0028.P/DIR/2023 + PBJT-TL & dokumentasi lapangan',
      icon: 'bi-exclamation-octagon-fill'
    },
    {
      tabId: 'tab-kct',
      badge: 'TOKEN & KCT',
      title: 'Cek KCT Lintas ULP',
      sub: 'Pencarian cepat token KCT 1A/1B/2A/2B & kirim langsung via WA',
      icon: 'bi-key-fill'
    },
    {
      tabId: 'tab-chatbot',
      badge: 'PFA AI NEON',
      title: 'Asisten AI Petugas Lapangan',
      sub: 'Diagnosa APP, OCR foto meter/CT, DIL, KCT, P2TL & SPLN',
      icon: 'bi-lightning-charge-fill'
    },
    {
      tabId: 'tab-tutorial',
      badge: 'PANDUAN RESMI',
      title: 'Tutorial Penggunaan PFA',
      sub: 'Panduan langkah demi langkah seluruh modul operasional',
      icon: 'bi-book-half'
    }
  ];

  function injectModuleHeroCards() {
    MODULE_HEROES.forEach(function (cfg) {
      var sec = document.getElementById(cfg.tabId);
      if (!sec || sec.querySelector('.pfa-mod-hero')) return;
      var firstBar = sec.querySelector(':scope > .d-flex');
      var hero = document.createElement('div');
      hero.className = 'pfa-mod-hero';
      hero.innerHTML =
        '<div class="min-w-0">' +
          '<span class="pfa-mod-hero-badge">⚡ ' + cfg.badge + '</span>' +
          '<h6 class="pfa-mod-hero-title">' + cfg.title + '</h6>' +
          '<div class="pfa-mod-hero-sub">' + cfg.sub + '</div>' +
        '</div>' +
        '<div class="pfa-mod-hero-icon" aria-hidden="true"><i class="bi ' + cfg.icon + '"></i></div>';

      if (firstBar && firstBar.nextSibling) {
        sec.insertBefore(hero, firstBar.nextSibling);
      } else {
        sec.insertBefore(hero, sec.firstChild);
      }
    });
  }

  function bindPhotoFilledIndicators() {
    document.addEventListener('change', function (ev) {
      var el = ev && ev.target;
      if (!el || el.tagName !== 'INPUT' || el.type !== 'file') return;
      var hasFile = Boolean(el.files && el.files.length > 0);
      el.classList.toggle('pfa-photo-filled', hasFile);

      var wrap = el.closest('.mb-2, .mb-3, .col-6, .col-12, div');
      var lbl = wrap ? wrap.querySelector('label.form-label, label') : null;
      if (lbl) {
        var existing = lbl.querySelector('.pfa-photo-ok-pill');
        if (hasFile && !existing) {
          var pill = document.createElement('span');
          pill.className = 'pfa-photo-ok-pill';
          pill.innerHTML = '<i class="bi bi-check-circle-fill"></i>Siap';
          lbl.appendChild(pill);
        } else if (!hasFile && existing) {
          existing.remove();
        }
      }
    });
  }

  function bootAllModulePolish() {
    injectModuleHeroCards();
    bindPhotoFilledIndicators();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootAllModulePolish);
  } else {
    bootAllModulePolish();
  }
})();

/* ==========================================================================
   PFA v2.0.24 — Menu ☰ Ringkas (5 Item Inti), Modal Pengaturan & Tentang+Saran
   ========================================================================== */
(function () {
  'use strict';

  function getUserSafeV210() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.user ? parsed.user : parsed;
    } catch (e) { return null; }
  }

  function isAdminV210() {
    var u = getUserSafeV210();
    var r = u && (u.role || u.Role || u.jabatan) ? String(u.role || u.Role || u.jabatan).toUpperCase() : '';
    if (r.indexOf('ADMIN') !== -1) return true;
    var el = document.getElementById('portalRoleText');
    return Boolean(el && String(el.textContent || '').toUpperCase().indexOf('ADMIN') !== -1);
  }

  function syncPortalOddGrid() {
    var grid = document.querySelector('#tab-portal .pfa-util-grid');
    var adm = document.getElementById('portalAdminCard');
    if (!grid || !adm) return;
    grid.classList.toggle('pfa-util-odd', adm.classList.contains('d-none'));
  }

  function openCompactSettingsModal() {
    var modalId = 'pfaCompactSettingsModal';
    var existing = document.getElementById(modalId);
    if (existing) existing.remove();

    var isDark = document.documentElement.classList.contains('pfa-dark-mode');
    var isLarge = document.documentElement.classList.contains('pfa-font-large');
    var isBeta = localStorage.getItem('pfa_beta_channel_v1') === '1';
    var showBeta = isAdminV210();

    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">' +
        '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
          '<div class="modal-content rounded-4 border-0 shadow">' +
            '<div class="modal-header border-0 pb-1">' +
              '<h6 class="modal-title fw-bold"><i class="bi bi-sliders2 me-2 text-primary"></i>Pengaturan &amp; Sistem</h6>' +
              '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
            '</div>' +
            '<div class="modal-body pt-2">' +
              '<div class="small fw-bold text-muted mb-1 px-1">TAMPILAN</div>' +
              '<div class="pfa-settings-group">' +
                '<button type="button" class="pfa-settings-row" id="pfaSetDarkBtn">' +
                  '<span><i class="bi bi-moon-stars-fill me-2 text-warning"></i>Mode Tampilan</span>' +
                  '<span class="badge text-bg-primary rounded-pill" id="pfaSetDarkVal">' + (isDark ? 'PLN Night' : 'PLN Pro') + '</span>' +
                '</button>' +
                '<button type="button" class="pfa-settings-row" id="pfaSetFontBtn">' +
                  '<span><i class="bi bi-fonts me-2 text-info"></i>Ukuran Teks</span>' +
                  '<span class="badge text-bg-secondary rounded-pill" id="pfaSetFontVal">' + (isLarge ? 'Besar' : 'Normal') + '</span>' +
                '</button>' +
              '</div>' +

              '<div class="small fw-bold text-muted mb-1 px-1">SESI &amp; PEMBARUAN</div>' +
              '<div class="pfa-settings-group">' +
                '<button type="button" class="pfa-settings-row" id="pfaSetSessionBtn">' +
                  '<span><i class="bi bi-shield-check me-2 text-success"></i>Segarkan Sesi Login</span>' +
                  '<span class="badge text-bg-light border rounded-pill">Segarkan</span>' +
                '</button>' +
                '<button type="button" class="pfa-settings-row" id="pfaSetUpdateBtn">' +
                  '<span><i class="bi bi-cloud-download-fill me-2 text-primary"></i>Cek Update Aplikasi</span>' +
                  '<span class="badge text-bg-light border rounded-pill">v2.1.11</span>' +
                '</button>' +
                (showBeta
                  ? '<button type="button" class="pfa-settings-row" id="pfaSetBetaBtn">' +
                      '<span><i class="bi bi-rocket-takeoff-fill me-2 text-primary"></i>Channel Beta (Admin)</span>' +
                      '<span class="badge ' + (isBeta ? 'text-bg-success' : 'text-bg-secondary') + ' rounded-pill" id="pfaSetBetaVal">' + (isBeta ? 'AKTIF' : 'OFF') + '</span>' +
                    '</button>'
                  : '') +
              '</div>' +

              '<div class="small fw-bold text-muted mb-1 px-1">PEMELIHARAAN</div>' +
              '<div class="pfa-settings-group mb-1">' +
                '<button type="button" class="pfa-settings-row" id="pfaSetSafeBtn">' +
                  '<span><i class="bi bi-shield-exclamation me-2 text-warning"></i>Safe Mode (Bersihkan Cache)</span>' +
                  '<i class="bi bi-chevron-right text-muted"></i>' +
                '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(wrap.firstElementChild);
    var modalEl = document.getElementById(modalId);
    var bsModal = window.bootstrap && window.bootstrap.Modal ? window.bootstrap.Modal.getOrCreateInstance(modalEl) : null;

    document.getElementById('pfaSetDarkBtn').onclick = function () {
      var quickBtn = document.getElementById('pfaQuickThemeBtn');
      if (quickBtn) quickBtn.click();
      var nowDark = document.documentElement.classList.contains('pfa-dark-mode');
      document.getElementById('pfaSetDarkVal').textContent = nowDark ? 'PLN Night' : 'PLN Pro';
    };

    document.getElementById('pfaSetFontBtn').onclick = function () {
      var origFontBtn = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="font"]');
      if (origFontBtn) {
        origFontBtn.click();
      } else {
        var nextLarge = !document.documentElement.classList.contains('pfa-font-large');
        document.documentElement.classList.toggle('pfa-font-large', nextLarge);
        try { localStorage.setItem('pfa_font_large_v1', nextLarge ? '1' : '0'); } catch (e) {}
      }
      var nowLarge = document.documentElement.classList.contains('pfa-font-large');
      document.getElementById('pfaSetFontVal').textContent = nowLarge ? 'Besar' : 'Normal';
    };

    document.getElementById('pfaSetSessionBtn').onclick = function () {
      if (bsModal) bsModal.hide();
      var origSess = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="session"]');
      if (origSess) origSess.click();
    };

    document.getElementById('pfaSetUpdateBtn').onclick = function () {
      if (bsModal) bsModal.hide();
      var origUpd = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="update"]');
      if (origUpd) origUpd.click();
    };

    var betaBtn = document.getElementById('pfaSetBetaBtn');
    if (betaBtn) {
      betaBtn.onclick = function () {
        var cur = localStorage.getItem('pfa_beta_channel_v1') === '1';
        var next = !cur;
        try { localStorage.setItem('pfa_beta_channel_v1', next ? '1' : '0'); } catch (e) {}
        var valEl = document.getElementById('pfaSetBetaVal');
        if (valEl) {
          valEl.textContent = next ? 'AKTIF' : 'OFF';
          valEl.className = 'badge ' + (next ? 'text-bg-success' : 'text-bg-secondary') + ' rounded-pill';
        }
      };
    }

    document.getElementById('pfaSetSafeBtn').onclick = function () {
      if (!window.confirm('Bersihkan cache master & muat ulang aplikasi? (Antrean offline tetap aman)')) return;
      try {
        Object.keys(localStorage).forEach(function (k) {
          if (k.indexOf('pfa_ttl_cache_v1_') === 0) localStorage.removeItem(k);
        });
      } catch (e) {}
      window.location.reload();
    };

    if (bsModal) bsModal.show();
  }

  function openCompactAboutModal() {
    var modalId = 'pfaCompactAboutModal';
    var existing = document.getElementById(modalId);
    if (existing) existing.remove();

    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="' + modalId + '" tabindex="-1" aria-hidden="true">' +
        '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
          '<div class="modal-content rounded-4 border-0 shadow">' +
            '<div class="modal-header border-0 pb-1">' +
              '<h6 class="modal-title fw-bold"><i class="bi bi-info-circle-fill me-2 text-primary"></i>Tentang Aplikasi</h6>' +
              '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
            '</div>' +
            '<div class="modal-body pt-2">' +
              '<div class="p-3 rounded-4 mb-3 text-white" style="background:linear-gradient(135deg,#002850 0%,#003b73 60%,#0077b6 100%);">' +
                '<div class="fw-bold fs-6">PLN Field Assistant (PFA)</div>' +
                '<div class="small opacity-75">Versi 2.1.11 • PLN Corporate Pro</div>' +
                '<div class="small mt-2 pt-2 border-top border-light border-opacity-25">' +
                  'Pengembang: <strong>JODI SETIAWAN</strong><br>' +
                  'Unit: <strong>PLN ULP Pelabuhan Ratu</strong>' +
                '</div>' +
              '</div>' +
              '<div class="d-grid gap-2">' +
                '<button type="button" class="btn btn-primary fw-semibold" id="pfaAboutFeedbackBtn">' +
                  '<i class="bi bi-chat-heart-fill me-1"></i> Lapor Kendala / Kirim Saran' +
                '</button>' +
                '<button type="button" class="btn btn-outline-secondary btn-sm fw-semibold" id="pfaAboutChangelogBtn">' +
                  '<i class="bi bi-clock-history me-1"></i> Lihat Riwayat Rilis' +
                '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(wrap.firstElementChild);
    var modalEl = document.getElementById(modalId);
    var bsModal = window.bootstrap && window.bootstrap.Modal ? window.bootstrap.Modal.getOrCreateInstance(modalEl) : null;

    document.getElementById('pfaAboutFeedbackBtn').onclick = function () {
      if (bsModal) bsModal.hide();
      setTimeout(function () {
        var origFb = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="feedback"]');
        if (origFb) origFb.click();
      }, 220);
    };

    document.getElementById('pfaAboutChangelogBtn').onclick = function () {
      if (bsModal) bsModal.hide();
      setTimeout(function () {
        var origRel = document.querySelector('#appScreen .topbar-pln .dropdown-menu button[data-pfa-orig="release"]');
        if (origRel) origRel.click();
      }, 220);
    };

    if (bsModal) bsModal.show();
  }

  function compactTopDropdownMenu() {
    var menuUl = document.querySelector('#appScreen .topbar-pln .dropdown-menu');
    if (!menuUl) return;

    var lis = Array.prototype.slice.call(menuUl.children);
    lis.forEach(function (li) {
      var btn = li.querySelector('button');
      if (!btn) return;
      var txt = String(btn.textContent || '').toLowerCase();
      var onclk = String(btn.getAttribute('onclick') || '').toLowerCase();

      // Tandai tombol asli lalu sembunyikan item yang dipindah ke Pengaturan & Tentang
      if (txt.indexOf('ukuran teks') !== -1) { btn.setAttribute('data-pfa-orig', 'font'); li.classList.add('d-none'); }
      else if (txt.indexOf('segarkan sesi') !== -1) { btn.setAttribute('data-pfa-orig', 'session'); li.classList.add('d-none'); }
      else if (txt.indexOf('cek update') !== -1) { btn.setAttribute('data-pfa-orig', 'update'); li.classList.add('d-none'); }
      else if (txt.indexOf('lapor kendala') !== -1 || txt.indexOf('masukan') !== -1) { btn.setAttribute('data-pfa-orig', 'feedback'); li.classList.add('d-none'); }
      else if (txt.indexOf('riwayat rilis') !== -1) { btn.setAttribute('data-pfa-orig', 'release'); li.classList.add('d-none'); }
      else if (txt.indexOf('tema:') !== -1 || txt.indexOf('channel beta') !== -1 || txt.indexOf('tentang aplikasi') !== -1 || onclk.indexOf("switchtab('tutorial')") !== -1) {
        li.classList.add('d-none');
      }
    });

    var divider = menuUl.querySelector('.dropdown-divider');
    var anchorLi = divider ? divider.closest('li') : menuUl.lastElementChild;

    if (menuUl.querySelector('[data-pfa-compact-item="settings"]')) return;
    var setLi = document.createElement('li');
    setLi.setAttribute('data-pfa-compact-item', 'settings');
    setLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2">' +
        '<i class="bi bi-sliders2 me-2 text-primary"></i> Pengaturan &amp; Sistem' +
      '</button>';
    setLi.querySelector('button').addEventListener('click', openCompactSettingsModal);

    var aboutLi = document.createElement('li');
    aboutLi.innerHTML =
      '<button type="button" class="dropdown-item small py-2">' +
        '<i class="bi bi-info-circle-fill me-2 text-info"></i> Tentang Aplikasi' +
      '</button>';
    aboutLi.querySelector('button').addEventListener('click', openCompactAboutModal);

    if (anchorLi && anchorLi.parentNode) {
      anchorLi.parentNode.insertBefore(setLi, anchorLi);
      anchorLi.parentNode.insertBefore(aboutLi, anchorLi);
    } else {
      menuUl.appendChild(setLi);
      menuUl.appendChild(aboutLi);
    }
    menuUl.setAttribute('data-pfa-compacted', '1');
  }

  window.addEventListener('load', function () {
    setTimeout(compactTopDropdownMenu, 650);
    setTimeout(compactTopDropdownMenu, 1800);
    var menuToggleBtn = document.querySelector('#appScreen .topbar-pln button[data-bs-toggle="dropdown"]');
    if (menuToggleBtn) {
      menuToggleBtn.addEventListener('click', function () {
        setTimeout(compactTopDropdownMenu, 10);
      });
    }
    setTimeout(syncPortalOddGrid, 500);
    setTimeout(syncPortalOddGrid, 1200);
  });

  if (typeof window.switchTab === 'function') {
    var origSw = window.switchTab;
    window.switchTab = function (t) {
      var r = origSw.apply(this, arguments);
      if (t === 'portal') setTimeout(syncPortalOddGrid, 120);
      return r;
    };
  }
})();

/* ==========================================================================
   PFA v2.0.24 — 3-Step Stepper (Gangguan & P2TL), Collapsible DIL & KPI Ukur
   (100% Non-destruktif: tidak mengubah 1 pun ID input atau fungsi submit)
   ========================================================================== */
(function () {
  'use strict';

  function buildStepper(containerEl, stepsCfg, insertBeforeEl) {
    if (!containerEl || containerEl.querySelector('.pfa-stepper-bar')) return;
    var bar = document.createElement('div');
    bar.className = 'pfa-stepper-bar';
    var currentStep = 0;

    function applyStep(idx) {
      currentStep = idx;
      var btns = bar.querySelectorAll('.pfa-step-btn');
      btns.forEach(function (b, i) { b.classList.toggle('active', i === idx); });
      stepsCfg.forEach(function (st, i) {
        (st.els || []).forEach(function (el) {
          if (el) el.classList.toggle('pfa-step-hidden', i !== idx);
        });
      });
      var prevBtn = navFoot.querySelector('[data-step-prev]');
      var nextBtn = navFoot.querySelector('[data-step-next]');
      if (prevBtn) prevBtn.disabled = idx === 0;
      if (nextBtn) nextBtn.classList.toggle('d-none', idx === stepsCfg.length - 1);
    }

    stepsCfg.forEach(function (st, i) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'pfa-step-btn' + (i === 0 ? ' active' : '');
      btn.textContent = st.label;
      btn.addEventListener('click', function () { applyStep(i); });
      bar.appendChild(btn);
    });

    var navFoot = document.createElement('div');
    navFoot.className = 'pfa-step-nav-footer';
    navFoot.innerHTML =
      '<button type="button" class="btn btn-outline-secondary btn-sm flex-fill fw-semibold" data-step-prev><i class="bi bi-arrow-left me-1"></i>Sebelumnya</button>' +
      '<button type="button" class="btn btn-primary btn-sm flex-fill fw-semibold" data-step-next>Langkah Berikutnya<i class="bi bi-arrow-right ms-1"></i></button>';

    navFoot.querySelector('[data-step-prev]').addEventListener('click', function () {
      if (currentStep > 0) { applyStep(currentStep - 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    });
    navFoot.querySelector('[data-step-next]').addEventListener('click', function () {
      if (currentStep < stepsCfg.length - 1) { applyStep(currentStep + 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    });

    if (insertBeforeEl && insertBeforeEl.parentNode) {
      insertBeforeEl.parentNode.insertBefore(bar, insertBeforeEl);
    } else {
      containerEl.insertBefore(bar, containerEl.firstChild);
    }
    containerEl.appendChild(navFoot);

    // Jika ada field invalid saat submit di langkah lain, otomatis lompat ke langkah tersebut
    var formEl = containerEl.querySelector('form');
    if (formEl) {
      formEl.addEventListener('invalid', function (ev) {
        var target = ev.target;
        for (var i = 0; i < stepsCfg.length; i++) {
          var found = (stepsCfg[i].els || []).some(function (el) { return el && el.contains(target); });
          if (found) { applyStep(i); break; }
        }
      }, true);
    }

    applyStep(0);
  }

  // 1. MODUL GANGGUAN: 3-Step Stepper + Collapsible DIL Summary
  function enhanceGangguanModule() {
    var tab = document.getElementById('tab-gangguan');
    var form = document.getElementById('gangguanForm');
    if (!tab || !form) return;

    var searchCard = tab.querySelector(':scope > .card.card-modern');
    var formCards = Array.prototype.slice.call(form.querySelectorAll(':scope > .card.card-modern'));
    if (formCards.length >= 3) {
      var dilCard = formCards[0];
      var kondisiCard = formCards[1];
      var fotoCards = formCards.slice(2);

      // Collapsible DIL Summary di atas dilCard
      if (!document.getElementById('pfaGangguanDilSummary')) {
        var sumCard = document.createElement('div');
        sumCard.id = 'pfaGangguanDilSummary';
        sumCard.className = 'pfa-dil-summary-card d-none';
        sumCard.innerHTML =
          '<div class="pfa-dil-summary-top">' +
            '<div class="min-w-0">' +
              '<div class="pfa-dil-name text-truncate" id="pfaGgnDilName">-</div>' +
              '<div class="pfa-dil-meta text-truncate" id="pfaGgnDilMeta">-</div>' +
            '</div>' +
            '<button type="button" class="pfa-dil-toggle-btn" id="pfaGgnDilToggle">Detail DIL ▾</button>' +
          '</div>';
        dilCard.parentNode.insertBefore(sumCard, dilCard);

        var expanded = true;
        document.getElementById('pfaGgnDilToggle').addEventListener('click', function () {
          expanded = !expanded;
          dilCard.classList.toggle('d-none', !expanded);
          this.textContent = expanded ? 'Sembunyikan ▴' : 'Detail DIL ▾';
        });

        // Sinkron otomatis saat kolom IDPEL/Nama berubah (misal setelah auto-fill DIL)
        var syncDilSummary = function () {
          var idp = (document.getElementById('idpel') && document.getElementById('idpel').value) || '';
          var nm = (document.getElementById('nama') && document.getElementById('nama').value) || '';
          var trf = (document.getElementById('tarif') && document.getElementById('tarif').value) || '';
          var dy = (document.getElementById('daya') && document.getElementById('daya').value) || '';
          if (idp.trim() || nm.trim()) {
            sumCard.classList.remove('d-none');
            document.getElementById('pfaGgnDilName').textContent = nm || idp;
            document.getElementById('pfaGgnDilMeta').textContent = [idp, [trf, dy].filter(Boolean).join(' / ')].filter(Boolean).join(' • ');
          }
        };
        ['idpel', 'nama', 'tarif', 'daya'].forEach(function (fid) {
          var el = document.getElementById(fid);
          if (el) el.addEventListener('change', syncDilSummary);
        });
        if (typeof window.cariPelanggan === 'function' && !window._pfaGgnDilHooked) {
          window._pfaGgnDilHooked = true;
          var origCari = window.cariPelanggan;
          window.cariPelanggan = function () {
            var r = origCari.apply(this, arguments);
            setTimeout(syncDilSummary, 900);
            setTimeout(syncDilSummary, 2200);
            return r;
          };
        }
      }

      var submitWrap = form.querySelector(':scope > .d-grid, :scope > .row:last-child, :scope > div:last-child');
      if (submitWrap && fotoCards.indexOf(submitWrap) === -1 && !submitWrap.classList.contains('card')) {
        fotoCards.push(submitWrap);
      }

      buildStepper(tab, [
        { label: '1. Pelanggan', els: [searchCard, document.getElementById('pfaGangguanDilSummary'), dilCard] },
        { label: '2. Kondisi', els: [kondisiCard] },
        { label: '3. Foto & Simpan', els: fotoCards }
      ], searchCard);
    }
  }

  // 2. MODUL P2TL: 3-Step Stepper
  function enhanceP2tlModule() {
    var tab = document.getElementById('tab-p2tl');
    var form = document.getElementById('p2tlForm');
    if (!tab || !form) return;

    var formCards = Array.prototype.slice.call(form.querySelectorAll(':scope > .card.card-modern'));
    if (formCards.length >= 3) {
      var step3Els = formCards.slice(2);
      var submitWrap = form.querySelector(':scope > .d-grid, :scope > div:last-child');
      if (submitWrap && step3Els.indexOf(submitWrap) === -1 && !submitWrap.classList.contains('card')) {
        step3Els.push(submitWrap);
      }
      buildStepper(tab, [
        { label: '1. Identitas', els: [formCards[0]] },
        { label: '2. Temuan & TS', els: [formCards[1]] },
        { label: '3. Bukti & Kirim', els: step3Els }
      ], form);
    }
  }

  // 3. MODUL PENGUKURAN: Executive Live KPI Dashboard Card (mirror #hdr_dev_kwh & #hdr_dev_ct)
  function enhancePengukuranModule() {
    var tab = document.getElementById('tab-pengukuran');
    if (!tab || document.getElementById('pfaUkurKpiDash')) return;
    var headerCard = tab.querySelector(':scope > .card.card-modern');
    if (!headerCard) return;

    var kpi = document.createElement('div');
    kpi.id = 'pfaUkurKpiDash';
    kpi.className = 'pfa-kpi-dashboard';
    kpi.innerHTML =
      '<div class="pfa-kpi-box">' +
        '<div class="pfa-kpi-label">Deviasi kWh</div>' +
        '<div class="pfa-kpi-value" id="pfaKpiKwhVal">-</div>' +
        '<span class="pfa-kpi-pill" id="pfaKpiKwhPill">Belum diukur</span>' +
      '</div>' +
      '<div class="pfa-kpi-box">' +
        '<div class="pfa-kpi-label">Avg Error CT</div>' +
        '<div class="pfa-kpi-value" id="pfaKpiCtVal">-</div>' +
        '<span class="pfa-kpi-pill" id="pfaKpiCtPill">Belum diukur</span>' +
      '</div>';

    headerCard.parentNode.insertBefore(kpi, headerCard.nextSibling);

    function syncKpiCard() {
      var kwhEl = document.getElementById('hdr_dev_kwh');
      var ctEl = document.getElementById('hdr_dev_ct');
      var kwhTxt = kwhEl ? String(kwhEl.textContent || '-').trim() : '-';
      var ctTxt = ctEl ? String(ctEl.textContent || '-').trim() : '-';

      var kVal = document.getElementById('pfaKpiKwhVal');
      var kPill = document.getElementById('pfaKpiKwhPill');
      if (kVal && kPill) {
        kVal.textContent = kwhTxt || '-';
        var numK = parseFloat(kwhTxt.replace(/[^0-9.\-]/g, ''));
        if (!isNaN(numK)) {
          var okK = Math.abs(numK) <= 2.0;
          kPill.textContent = okK ? 'Normal (≤2%)' : 'Di Luar Toleransi';
          kPill.className = 'pfa-kpi-pill ' + (okK ? 'is-ok' : 'is-warn');
        } else {
          kPill.textContent = 'Belum diukur';
          kPill.className = 'pfa-kpi-pill';
        }
      }

      var cVal = document.getElementById('pfaKpiCtVal');
      var cPill = document.getElementById('pfaKpiCtPill');
      if (cVal && cPill) {
        cVal.textContent = ctTxt || '-';
        var numC = parseFloat(ctTxt.replace(/[^0-9.\-]/g, ''));
        if (!isNaN(numC)) {
          var okC = Math.abs(numC) <= 2.0;
          cPill.textContent = okC ? 'Normal' : 'Perlu Cek CT';
          cPill.className = 'pfa-kpi-pill ' + (okC ? 'is-ok' : 'is-warn');
        } else {
          cPill.textContent = 'Belum diukur';
          cPill.className = 'pfa-kpi-pill';
        }
      }
    }

    // Event-driven MutationObserver pada #hdr_dev_kwh & #hdr_dev_ct (ZERO polling!)
    ['hdr_dev_kwh', 'hdr_dev_ct'].forEach(function (id) {
      var target = document.getElementById(id);
      if (target && typeof MutationObserver !== 'undefined') {
        new MutationObserver(syncKpiCard).observe(target, { childList: true, characterData: true, subtree: true });
      }
    });
    syncKpiCard();
  }

  window.addEventListener('load', function () {
    setTimeout(enhanceGangguanModule, 320);
    setTimeout(enhanceP2tlModule, 360);
    setTimeout(enhancePengukuranModule, 400);
  });
})();

/* ==========================================================================
   PFA v2.0.24 — MODE OFFLINE OTOMATIS (BANNER, CACHE DIL, UNLOCK MANUAL)
   ========================================================================== */
(function () {
  'use strict';

  var DIL_CACHE_KEY = 'pfa_dil_local_cache_v1';
  var IS_OFFLINE_DETECTED = navigator.onLine === false;

  function isNetworkOrDnsError(err) {
    var msg = String((err && err.message) || err || '').toLowerCase();
    return (
      navigator.onLine === false ||
      msg.indexOf('unable to resolve host') !== -1 ||
      msg.indexOf('no address associated') !== -1 ||
      msg.indexOf('unknownhostexception') !== -1 ||
      msg.indexOf('failed to fetch') !== -1 ||
      msg.indexOf('network error') !== -1 ||
      msg.indexOf('network request failed') !== -1 ||
      msg.indexOf('internet') !== -1 ||
      msg.indexOf('offline') !== -1
    );
  }

  function loadDilCache() {
    try {
      var raw = localStorage.getItem(DIL_CACHE_KEY);
      var parsed = raw ? JSON.parse(raw) : {};
      return (parsed && typeof parsed === 'object') ? parsed : {};
    } catch (e) { return {}; }
  }

  function saveDilToCache(keyword, res) {
    try {
      if (!res || res.status !== 'success') return;
      var data = res.data || res.pelanggan || null;
      if (!data) return;
      var cache = loadDilCache();
      var keys = Object.keys(cache);
      if (keys.length > 180) {
        keys.slice(0, 40).forEach(function (k) { delete cache[k]; });
      }
      var k1 = String(keyword || '').replace(/\s+/g, '').toUpperCase();
      var k2 = String(data.idpel || data.IDPEL || '').replace(/\s+/g, '').toUpperCase();
      var k3 = String(data.noMeter || data.no_meter || data.NOMOR_METER_KWH || '').replace(/\s+/g, '').toUpperCase();
      if (k1) cache[k1] = res;
      if (k2) cache[k2] = res;
      if (k3) cache[k3] = res;
      localStorage.setItem(DIL_CACHE_KEY, JSON.stringify(cache));
    } catch (e) {}
  }

  function findDilInCache(keyword) {
    var k = String(keyword || '').replace(/\s+/g, '').toUpperCase();
    if (!k) return null;
    var cache = loadDilCache();
    return cache[k] || null;
  }

  function unlockManualCustomerFields(keyword) {
    var ids = [
      'idpel', 'nama', 'alamat', 'tarif', 'daya', 'gardu', 'tiang', 'noMeterLama', 'merkMeterLama',
      'u_idpel', 'u_nama', 'u_alamat', 'u_tarif_daya',
      'p2tlIdpel', 'p2tlNama', 'p2tlAlamat', 'p2tlTarifDaya', 'p2tlNoMeter', 'p2tlGarduTiang'
    ];
    ids.forEach(function (id) {
      var el = document.getElementById(id);
      if (el) {
        el.removeAttribute('readonly');
        el.readOnly = false;
      }
    });
    // Isi otomatis IDPEL jika petugas baru saja mengetik angka di kolom pencarian
    var kw = String(keyword || '').trim();
    if (kw) {
      ['idpel', 'u_idpel', 'p2tlIdpel'].forEach(function (id) {
        var el = document.getElementById(id);
        if (el && !el.value) el.value = kw;
      });
    }
  }

  function renderOfflineBanner(isOffline) {
    IS_OFFLINE_DETECTED = Boolean(isOffline);
    var container = document.querySelector('#appScreen > .container');
    if (!container) return;
    var banner = document.getElementById('pfaOfflineModeBanner');

    if (IS_OFFLINE_DETECTED) {
      unlockManualCustomerFields('');
      if (!banner) {
        banner = document.createElement('div');
        banner.id = 'pfaOfflineModeBanner';
        banner.innerHTML =
          '<div class="d-flex align-items-center gap-2 min-w-0">' +
            '<i class="bi bi-wifi-off fs-6 flex-shrink-0 text-warning"></i>' +
            '<div class="lh-sm"><strong>Mode Offline Aktif</strong> — Input manual dibuka &amp; laporan masuk Antrean Offline.</div>' +
          '</div>' +
          '<button type="button" id="pfaOfflineBannerBtn" class="btn btn-sm btn-warning fw-bold flex-shrink-0 py-0 px-2" style="font-size:0.72rem;">Antrean</button>';
        container.insertBefore(banner, container.firstChild);
        var ob = document.getElementById('pfaOfflineBannerBtn');
        if (ob) ob.addEventListener('click', function () {
          if (typeof window.pfaOpenOfflineQueueModal === 'function') window.pfaOpenOfflineQueueModal();
        });
      }
    } else if (banner) {
      banner.remove();
    }
  }

  function wrapCallApiForTrueOfflineMode() {
    if (typeof window.callApi !== 'function' || window._pfaV214OfflineWrapped) return;
    window._pfaV214OfflineWrapped = true;
    var origCall = window.callApi;

    window.callApi = async function (payload) {
      var req = payload && typeof payload === 'object' ? Object.assign({}, payload) : payload;
      var act = req && req.action ? String(req.action).trim() : '';

      // 1. Jika offline & cek duplikat IDPEL -> langsung loloskan agar bisa simpan ke Antrean Offline
      if (act === 'cek_duplikat_idpel' && navigator.onLine === false) {
        renderOfflineBanner(true);
        return { status: 'success', isDuplicate: false, offlineBypass: true };
      }

      // 2. Jika offline & cari_pelanggan -> cek cache HP dulu, jika tidak ada buka input manual ramah
      if (act === 'cari_pelanggan' && navigator.onLine === false) {
        renderOfflineBanner(true);
        var cached = findDilInCache(req.keyword);
        if (cached) {
          if (typeof window.showToast === 'function') {
            window.showToast('Mode Offline: data pelanggan ditemukan dari cache HP.', 'info');
          }
          return cached;
        }
        unlockManualCustomerFields(req.keyword);
        if (typeof window.showToast === 'function') {
          window.showToast('Mode Offline aktif — silakan isi data pelanggan secara manual. Laporan akan masuk Antrean Offline.', 'warning');
        }
        return { status: 'not_found', offlineManual: true, message: 'Mode Offline: silakan isi data pelanggan secara manual.' };
      }

      try {
        var res = await origCall(req);
        if (IS_OFFLINE_DETECTED && navigator.onLine !== false) renderOfflineBanner(false);
        if (act === 'cari_pelanggan' && res && res.status === 'success') {
          saveDilToCache(req.keyword, res);
        }
        return res;
      } catch (err) {
        if (isNetworkOrDnsError(err)) {
          renderOfflineBanner(true);

          if (act === 'cek_duplikat_idpel') {
            return { status: 'success', isDuplicate: false, offlineBypass: true };
          }
          if (act === 'cari_pelanggan') {
            var cachedFallback = findDilInCache(req.keyword);
            if (cachedFallback) {
              if (typeof window.showToast === 'function') {
                window.showToast('Sinyal terputus: data pelanggan dimuat dari cache HP.', 'info');
              }
              return cachedFallback;
            }
            unlockManualCustomerFields(req.keyword);
            if (typeof window.showToast === 'function') {
              window.showToast('Tidak ada internet — Mode Offline aktif. Silakan isi data pelanggan secara manual.', 'warning');
            }
            return { status: 'not_found', offlineManual: true, message: 'Mode Offline aktif: silakan isi data secara manual.' };
          }
        }
        throw err;
      }
    };
  }

  window.addEventListener('offline', function () { renderOfflineBanner(true); });
  window.addEventListener('online', function () { renderOfflineBanner(false); });

  window.addEventListener('load', function () {
    wrapCallApiForTrueOfflineMode();
    if (navigator.onLine === false) renderOfflineBanner(true);
  });
})();

/* ==========================================================================
   PFA v2.0.24 SUPER PRO — 17 Field & Admin Enhancements (Event-Driven, Zero-Lag)
   Pengembang: JODI SETIAWAN — PLN ULP Pelabuhan Ratu
   ========================================================================== */
(function () {
  'use strict';

  var WATERMARK_PREF_KEY = 'pfa_photo_watermark_v1';
  var SEARCH_HIST_KEY = 'pfa_quick_search_hist_v1';
  var LAST_PORTAL_SUMMARY = null;
  var WAKE_LOCK_SENTINEL = null;

  function escHtml(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function copyTextQuick(text, label) {
    var val = String(text || '').trim();
    if (!val) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(val).then(function () {
        if (typeof window.showToast === 'function') window.showToast((label || 'Teks') + ' disalin: ' + val, 'success');
      }).catch(function () {});
    } else {
      var ta = document.createElement('textarea');
      ta.value = val;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      ta.remove();
      if (typeof window.showToast === 'function') window.showToast((label || 'Teks') + ' disalin.', 'success');
    }
  }

  function getUserObjV214() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.user ? parsed.user : parsed;
    } catch (e) { return null; }
  }

  function isAdminV214() {
    var u = getUserObjV214();
    var r = u && (u.role || u.Role) ? String(u.role || u.Role).toUpperCase() : '';
    if (r.indexOf('ADMIN') !== -1) return true;
    var el = document.getElementById('portalRoleText');
    return Boolean(el && String(el.textContent || '').toUpperCase().indexOf('ADMIN') !== -1);
  }

  // --------------------------------------------------------------------------
  // 1. OFFLINE SESSION BLANK SPOT (Buka app tanpa internet tetap masuk Portal)
  // --------------------------------------------------------------------------
  function ensureOfflineSessionEntry() {
    if (navigator.onLine !== false) return;
    var u = getUserObjV214();
    var loginEl = document.getElementById('loginScreen');
    var appEl = document.getElementById('appScreen');
    if (u && loginEl && appEl && !loginEl.classList.contains('d-none')) {
      loginEl.classList.add('d-none');
      appEl.classList.remove('d-none');
      var navNama = document.getElementById('navUserNama');
      if (navNama && u.nama) navNama.textContent = u.nama;
      if (typeof window.showToast === 'function') {
        window.showToast('Sesi terakhir dipulihkan (Mode Offline Blank Spot).', 'info');
      }
    }
  }

  // --------------------------------------------------------------------------
  // 2. SHARE KE WHATSAPP INSTAN SETELAH SIMPAN (Gangguan, Pengukuran, P2TL)
  // --------------------------------------------------------------------------
  function buildWaReportText(action, data, queuedOffline) {
    var d = data || {};
    var u = getUserObjV214();
    var petugas = (u && u.nama) || d.petugas || 'Petugas';
    var statusTag = queuedOffline ? ' (Antrean Offline)' : '';
    var gps = d.koordinat || d.gps || d.lokasiGps || '';
    var mapUrl = gps && gps.indexOf(',') !== -1 ? ('https://maps.google.com/?q=' + encodeURIComponent(gps.replace(/\s+/g, ''))) : '';

    if (action === 'simpan_gangguan') {
      return [
        '*LAPORAN METER RUSAK — PLN ULP PELABUHAN RATU*' + statusTag,
        '• IDPEL: ' + (d.idpel || '-'),
        '• Nama: ' + (d.nama || '-'),
        '• Tarif/Daya: ' + [d.tarif, d.daya].filter(Boolean).join(' / '),
        '• Gardu/Tiang: ' + [d.gardu, d.tiang].filter(Boolean).join(' / '),
        '• Kerusakan: ' + (d.sebabKerusakan || d.kerusakan || '-'),
        '• No. Meter Baru: ' + (d.noMeterBaru || '-'),
        mapUrl ? ('• Lokasi: ' + mapUrl) : '',
        '• Petugas: ' + petugas
      ].filter(Boolean).join('\n');
    }
    if (action === 'simpan_pengukuran') {
      return [
        '*LAPORAN PENGUKURAN DEVIASI — PLN ULP PELABUHAN RATU*' + statusTag,
        '• IDPEL: ' + (d.idpel || '-'),
        '• Nama: ' + (d.nama || '-'),
        '• Deviasi kWh: ' + (d.deviasiKwh || d.errorKwh || '-'),
        '• Avg Error CT: ' + (d.avgErrorCt || '-'),
        mapUrl ? ('• Lokasi: ' + mapUrl) : '',
        '• Petugas: ' + petugas
      ].filter(Boolean).join('\n');
    }
    return [
      '*LAPORAN POTENSI P2TL — PLN ULP PELABUHAN RATU*' + statusTag,
      '• IDPEL: ' + (d.idpel || 'Non Pelanggan (P4)'),
      '• Nama: ' + (d.nama || '-'),
      '• Golongan/Indikasi: ' + (d.golongan || d.indikasi || '-'),
      d.rupiah ? ('• Estimasi TS: ' + d.rupiah) : '',
      mapUrl ? ('• Lokasi: ' + mapUrl) : '',
      '• Petugas: ' + petugas
    ].filter(Boolean).join('\n');
  }

  function showInstantWaShareBar(waText) {
    var old = document.getElementById('pfaWaShareToast');
    if (old) old.remove();
    var bar = document.createElement('div');
    bar.id = 'pfaWaShareToast';
    bar.className = 'pfa-wa-share-bar';
    bar.innerHTML =
      '<div class="small fw-semibold"><i class="bi bi-whatsapp text-success me-1"></i>Laporan tercatat! Kirim ringkasan ke WA?</div>' +
      '<div class="d-flex gap-1 flex-shrink-0">' +
        '<button type="button" class="btn btn-sm btn-success fw-bold py-1 px-2" id="pfaWaSendNowBtn">Share WA</button>' +
        '<button type="button" class="btn btn-sm btn-outline-secondary py-1 px-2" id="pfaWaCloseBtn">✕</button>' +
      '</div>';
    document.body.appendChild(bar);
    document.getElementById('pfaWaSendNowBtn').onclick = function () {
      window.open('https://wa.me/?text=' + encodeURIComponent(waText), '_blank');
      bar.remove();
    };
    document.getElementById('pfaWaCloseBtn').onclick = function () { bar.remove(); };
    setTimeout(function () { if (bar.parentNode) bar.remove(); }, 12000);
  }

  // --------------------------------------------------------------------------
  // 3. WATERMARK OTOMATIS FOTO BUKTI (Opsional On/Off)
  // --------------------------------------------------------------------------
  window.pfaApplyPhotoWatermark = function (dataUrl, extraLabel) {
    return new Promise(function (resolve) {
      if (localStorage.getItem(WATERMARK_PREF_KEY) !== '1') { resolve(dataUrl); return; }
      var img = new Image();
      img.onerror = function () { resolve(dataUrl); };
      img.onload = function () {
        try {
          var canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          var ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0);
          var now = new Date();
          var stamp = now.toLocaleDateString('id-ID') + ' ' + now.toLocaleTimeString('id-ID');
          var idpel = (document.getElementById('idpel') && document.getElementById('idpel').value) ||
            (document.getElementById('u_idpel') && document.getElementById('u_idpel').value) ||
            (document.getElementById('p2tlIdpel') && document.getElementById('p2tlIdpel').value) || '-';
          var gpsEl = document.querySelector('#koordinat, #u_gps, #p2tlGps');
          var gps = (gpsEl && gpsEl.value) ? gpsEl.value : '-';
          var lines = [
            'PLN ULP PELABUHAN RATU • PFA',
            'Waktu: ' + stamp + ' | IDPEL: ' + idpel,
            'GPS: ' + gps + (extraLabel ? (' • ' + extraLabel) : '')
          ];
          var fs = Math.max(14, Math.round(canvas.width * 0.022));
          var boxH = fs * 4.2;
          ctx.fillStyle = 'rgba(0, 24, 52, 0.68)';
          ctx.fillRect(0, canvas.height - boxH, canvas.width, boxH);
          ctx.fillStyle = '#ffd100';
          ctx.font = 'bold ' + fs + 'px sans-serif';
          ctx.fillText(lines[0], 14, canvas.height - boxH + fs * 1.25);
          ctx.fillStyle = '#ffffff';
          ctx.font = Math.round(fs * 0.88) + 'px sans-serif';
          ctx.fillText(lines[1], 14, canvas.height - boxH + fs * 2.45);
          ctx.fillText(lines[2], 14, canvas.height - boxH + fs * 3.55);
          resolve(canvas.toDataURL('image/jpeg', 0.82));
        } catch (e) { resolve(dataUrl); }
      };
      img.src = dataUrl;
    });
  };

  // --------------------------------------------------------------------------
  // 4. AUTO-GPS + AKURASI + TOMBOL CEK DI MAPS
  // --------------------------------------------------------------------------
  function enhanceGpsFields() {
    var gpsIds = ['koordinat', 'u_gps', 'p2tlGps'];
    gpsIds.forEach(function (id) {
      var inp = document.getElementById(id);
      if (!inp || inp.getAttribute('data-pfa-gps-enhanced') === '1') return;
      inp.setAttribute('data-pfa-gps-enhanced', '1');
      var wrap = inp.parentElement;
      if (!wrap) return;
      var helper = document.createElement('div');
      helper.className = 'd-flex align-items-center justify-content-between gap-2 mt-1';
      helper.innerHTML =
        '<span class="small text-muted" id="pfaGpsAcc_' + id + '" style="font-size:0.7rem;">GPS: siap ambil lokasi</span>' +
        '<div class="d-flex gap-1">' +
          '<button type="button" class="btn btn-outline-primary btn-sm py-0 px-2" style="font-size:0.7rem;" id="pfaGpsGet_' + id + '"><i class="bi bi-crosshair me-1"></i>Ambil GPS</button>' +
          '<button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2" style="font-size:0.7rem;" id="pfaGpsMap_' + id + '"><i class="bi bi-geo-alt-fill me-1"></i>Cek Maps</button>' +
        '</div>';
      wrap.insertAdjacentElement('afterend', helper);

      document.getElementById('pfaGpsGet_' + id).onclick = function () {
        if (!navigator.geolocation) return;
        var accEl = document.getElementById('pfaGpsAcc_' + id);
        if (accEl) accEl.textContent = 'Mengambil titik GPS...';
        navigator.geolocation.getCurrentPosition(function (pos) {
          var lat = pos.coords.latitude.toFixed(6);
          var lng = pos.coords.longitude.toFixed(6);
          var acc = Math.round(pos.coords.accuracy || 0);
          inp.value = lat + ', ' + lng;
          inp.dispatchEvent(new Event('change', { bubbles: true }));
          if (accEl) accEl.textContent = 'Akurasi: ±' + acc + ' meter';
        }, function () {
          if (accEl) accEl.textContent = 'GPS gagal, pastikan lokasi HP aktif.';
        }, { enableHighAccuracy: true, timeout: 12000 });
      };

      document.getElementById('pfaGpsMap_' + id).onclick = function () {
        var v = String(inp.value || '').trim();
        if (!v) {
          if (typeof window.showToast === 'function') window.showToast('Koordinat GPS masih kosong.', 'warning');
          return;
        }
        window.open('https://maps.google.com/?q=' + encodeURIComponent(v.replace(/\s+/g, '')), '_blank');
      };
    });
  }

  // --------------------------------------------------------------------------
  // 5. FILTER CEPAT & PENCARIAN DI MODAL HISTORI INPUT SAYA
  // --------------------------------------------------------------------------
  function injectHistoriSearchFilter() {
    var modalBody = document.querySelector('#historiSayaModal .modal-body');
    if (!modalBody || document.getElementById('pfaHistoriFilterBar')) return;
    var bar = document.createElement('div');
    bar.id = 'pfaHistoriFilterBar';
    bar.className = 'd-flex gap-1 mb-2';
    bar.innerHTML =
      '<input type="text" id="pfaHistSearchInp" class="form-control form-control-sm" placeholder="Cari IDPEL / Nama di histori...">' +
      '<button type="button" id="pfaHistTodayBtn" class="btn btn-sm btn-outline-primary flex-shrink-0" style="font-size:0.74rem;">Hari Ini</button>';
    modalBody.insertBefore(bar, modalBody.firstChild);

    var onlyToday = false;
    function applyHistFilter() {
      var q = String(document.getElementById('pfaHistSearchInp').value || '').toLowerCase().trim();
      var todayStr = new Date().toISOString().slice(0, 10);
      var rows = modalBody.querySelectorAll('.card, .list-group-item, tr');
      rows.forEach(function (r) {
        if (r.id === 'pfaHistoriFilterBar' || r.querySelector('th')) return;
        var txt = String(r.textContent || '').toLowerCase();
        var matchQ = !q || txt.indexOf(q) !== -1;
        var matchToday = !onlyToday || txt.indexOf(todayStr) !== -1;
        r.style.display = (matchQ && matchToday) ? '' : 'none';
      });
    }
    document.getElementById('pfaHistSearchInp').addEventListener('input', applyHistFilter);
    document.getElementById('pfaHistTodayBtn').addEventListener('click', function () {
      onlyToday = !onlyToday;
      this.classList.toggle('btn-primary', onlyToday);
      this.classList.toggle('btn-outline-primary', !onlyToday);
      applyHistFilter();
    });
  }

  // --------------------------------------------------------------------------
  // 6. LINTAS MODUL 1-KLIK (Pengukuran -> P2TL / Meter Rusak) & TABEL REFERENSI SPLN
  // --------------------------------------------------------------------------
  function openSplnReferenceModal() {
    var mid = 'pfaSplnRefModal';
    var el = document.getElementById(mid);
    if (!el) {
      var rows = [
        ['450 VA (1Φ)', '2 A', 'Langsung'],
        ['900 VA (1Φ)', '4 A', 'Langsung'],
        ['1.300 VA (1Φ)', '6 A', 'Langsung'],
        ['2.200 VA (1Φ)', '10 A', 'Langsung'],
        ['3.500 VA (1Φ)', '16 A', 'Langsung'],
        ['4.400 VA (1Φ)', '20 A', 'Langsung'],
        ['5.500 VA (1Φ)', '25 A', 'Langsung'],
        ['6.600 VA (3Φ)', '3×10 A', 'Langsung'],
        ['10.600 VA (3Φ)', '3×16 A', 'Langsung'],
        ['16.500 VA (3Φ)', '3×25 A', 'Langsung'],
        ['23.000 VA (3Φ)', '3×35 A', 'Langsung'],
        ['33.000 VA (3Φ)', '3×50 A', 'Langsung'],
        ['41.500 VA (3Φ)', '3×63 A', 'Langsung'],
        ['53 kVA (3Φ)', '3×80 A', '75/5 (FKM 15)'],
        ['66 kVA (3Φ)', '3×100 A', '100/5 (FKM 20)'],
        ['82,5 & 105 kVA', '3×125 / 160 A', '150/5 (FKM 30)'],
        ['131 & 147 kVA', '3×200 / 225 A', '200/5 (FKM 40)'],
        ['164 kVA (3Φ)', '3×250 A', '250/5 (FKM 50)'],
        ['197 kVA (3Φ)', '3×300 A', '300/5 (FKM 60)']
      ].map(function (r) {
        return '<tr><td class="fw-semibold">' + r[0] + '</td><td>' + r[1] + '</td><td class="text-primary fw-semibold">' + r[2] + '</td></tr>';
      }).join('');

      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="' + mid + '" tabindex="-1" aria-hidden="true">' +
          '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
            '<div class="modal-content rounded-4 border-0 shadow">' +
              '<div class="modal-header border-0 pb-1">' +
                '<h6 class="modal-title fw-bold"><i class="bi bi-table me-2 text-primary"></i>Referensi Daya → MCB &amp; CT (SPLN D3.015-2:2023)</h6>' +
                '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
              '</div>' +
              '<div class="modal-body pt-2">' +
                '<div class="table-responsive"><table class="table table-sm table-striped mb-0 small">' +
                  '<thead><tr><th>Daya</th><th>MCB</th><th>Rasio CT / FKM</th></tr></thead>' +
                  '<tbody>' + rows + '</tbody>' +
                '</table></div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';
      document.body.appendChild(wrap.firstElementChild);
      el = document.getElementById(mid);
    }
    if (window.bootstrap && window.bootstrap.Modal) window.bootstrap.Modal.getOrCreateInstance(el).show();
  }

  function injectPengukuranQuickTools() {
    var kpi = document.getElementById('pfaUkurKpiDash');
    if (!kpi || document.getElementById('pfaUkurQuickToolsBar')) return;
    var bar = document.createElement('div');
    bar.id = 'pfaUkurQuickToolsBar';
    bar.className = 'd-flex flex-wrap gap-1 mb-2';
    bar.innerHTML =
      '<button type="button" class="btn btn-outline-primary btn-sm flex-fill" style="font-size:0.72rem;" id="pfaUkurToP2tlBtn"><i class="bi bi-arrow-right-circle me-1"></i>Lanjut P2TL</button>' +
      '<button type="button" class="btn btn-outline-primary btn-sm flex-fill" style="font-size:0.72rem;" id="pfaUkurToGgnBtn"><i class="bi bi-tools me-1"></i>Lanjut Meter Rusak</button>' +
      '<button type="button" class="btn btn-outline-secondary btn-sm flex-fill" style="font-size:0.72rem;" id="pfaUkurRefSplnBtn"><i class="bi bi-table me-1"></i>Tabel MCB/CT</button>';
    kpi.insertAdjacentElement('afterend', bar);

    document.getElementById('pfaUkurToP2tlBtn').onclick = function () {
      var idp = (document.getElementById('u_idpel') && document.getElementById('u_idpel').value) || '';
      if (typeof window.switchTab === 'function') window.switchTab('p2tl');
      setTimeout(function () {
        var inp = document.getElementById('p2tlCariInput');
        if (inp && idp) { inp.value = idp; }
        var dst = document.getElementById('p2tlIdpel');
        if (dst && idp) dst.value = idp;
        if (typeof window.showToast === 'function' && idp) window.showToast('IDPEL ' + idp + ' dibawa ke Potensi P2TL.', 'info');
      }, 200);
    };

    document.getElementById('pfaUkurToGgnBtn').onclick = function () {
      var idp = (document.getElementById('u_idpel') && document.getElementById('u_idpel').value) || '';
      if (typeof window.switchTab === 'function') window.switchTab('gangguan');
      setTimeout(function () {
        var inp = document.getElementById('cariPelangganInput');
        if (inp && idp) { inp.value = idp; }
        if (typeof window.showToast === 'function' && idp) window.showToast('IDPEL ' + idp + ' dibawa ke Meter Rusak.', 'info');
      }, 200);
    };

    document.getElementById('pfaUkurRefSplnBtn').onclick = openSplnReferenceModal;
  }

  // --------------------------------------------------------------------------
  // 7. SCREEN WAKE LOCK SAAT STOPWATCH PENGUKURAN BERJALAN
  // --------------------------------------------------------------------------
  function initStopwatchWakeLock() {
    document.addEventListener('click', function (ev) {
      var btn = ev.target && ev.target.closest ? ev.target.closest('button') : null;
      if (!btn || !btn.closest('#tab-pengukuran')) return;
      var txt = String(btn.textContent || '').toLowerCase();
      if (txt.indexOf('mulai') !== -1 || txt.indexOf('start') !== -1) {
        if (navigator.wakeLock && navigator.wakeLock.request) {
          navigator.wakeLock.request('screen').then(function (s) { WAKE_LOCK_SENTINEL = s; }).catch(function () {});
        }
      } else if (txt.indexOf('stop') !== -1 || txt.indexOf('henti') !== -1 || txt.indexOf('reset') !== -1) {
        if (WAKE_LOCK_SENTINEL && WAKE_LOCK_SENTINEL.release) {
          WAKE_LOCK_SENTINEL.release().catch(function () {});
          WAKE_LOCK_SENTINEL = null;
        }
      }
    });
  }

  // --------------------------------------------------------------------------
  // 8. SALIN 1-KETUK IDPEL/GPS, RIWAYAT 5 SEARCH PORTAL, VALIDASI 12/11 DIGIT, SALIN TOKEN KCT
  // --------------------------------------------------------------------------
  function injectDilCopyButtons() {
    var sum = document.getElementById('pfaGangguanDilSummary');
    if (!sum || document.getElementById('pfaDilCopyIdBtn')) return;
    var row = document.createElement('div');
    row.className = 'd-flex gap-1 mt-2';
    row.innerHTML =
      '<button type="button" id="pfaDilCopyIdBtn" class="btn btn-outline-primary btn-sm py-0 px-2" style="font-size:0.7rem;"><i class="bi bi-clipboard me-1"></i>Salin IDPEL</button>' +
      '<button type="button" id="pfaDilCopyGpsBtn" class="btn btn-outline-secondary btn-sm py-0 px-2" style="font-size:0.7rem;"><i class="bi bi-geo-alt me-1"></i>Salin GPS</button>';
    sum.appendChild(row);
    document.getElementById('pfaDilCopyIdBtn').onclick = function () {
      copyTextQuick(document.getElementById('idpel') && document.getElementById('idpel').value, 'IDPEL');
    };
    document.getElementById('pfaDilCopyGpsBtn').onclick = function () {
      copyTextQuick(document.getElementById('koordinat') && document.getElementById('koordinat').value, 'GPS');
    };
  }

  function initPortalSearchHistoryAndValidation() {
    var inp = document.getElementById('pfaPortalQuickSearch');
    if (!inp || inp.getAttribute('data-pfa-hist-bound') === '1') return;
    inp.setAttribute('data-pfa-hist-bound', '1');

    var chipWrap = document.createElement('div');
    chipWrap.id = 'pfaQuickSearchChips';
    chipWrap.className = 'd-flex flex-wrap gap-1 mt-1 d-none';
    inp.closest('.pfa-quick-search-wrap').appendChild(chipWrap);

    function renderChips() {
      var list = [];
      try { list = JSON.parse(localStorage.getItem(SEARCH_HIST_KEY) || '[]'); } catch (e) {}
      if (!list.length) { chipWrap.classList.add('d-none'); return; }
      chipWrap.classList.remove('d-none');
      chipWrap.innerHTML = list.slice(0, 5).map(function (v) {
        return '<button type="button" class="btn btn-sm btn-outline-secondary rounded-pill py-0 px-2" style="font-size:0.68rem;" data-qchip="' + escHtml(v) + '">' + escHtml(v) + '</button>';
      }).join('');
      chipWrap.querySelectorAll('[data-qchip]').forEach(function (b) {
        b.onclick = function () {
          inp.value = b.getAttribute('data-qchip');
          var go = document.getElementById('pfaPortalQuickSearchGo');
          if (go) go.click();
        };
      });
    }

    inp.addEventListener('focus', renderChips);
    inp.addEventListener('input', function () {
      var digits = String(inp.value || '').replace(/\D/g, '');
      if (digits.length > 0 && digits.length !== 11 && digits.length !== 12) {
        inp.setAttribute('title', 'IDPEL umumnya 12 digit atau No. Meter 11 digit');
      }
    });

    var goBtn = document.getElementById('pfaPortalQuickSearchGo');
    if (goBtn) {
      goBtn.addEventListener('click', function () {
        var val = String(inp.value || '').trim();
        if (val.length >= 6) {
          var list = [];
          try { list = JSON.parse(localStorage.getItem(SEARCH_HIST_KEY) || '[]'); } catch (e) {}
          list = [val].concat(list.filter(function (x) { return x !== val; })).slice(0, 5);
          try { localStorage.setItem(SEARCH_HIST_KEY, JSON.stringify(list)); } catch (e) {}
        }
      });
    }
  }

  function enhanceKctCopyTokens() {
    var box = document.getElementById('kctResultContainer');
    if (!box || typeof MutationObserver === 'undefined') return;
    new MutationObserver(function () {
      box.querySelectorAll('code, .kct-token, td').forEach(function (el) {
        if (el.getAttribute('data-pfa-tok-copy') === '1') return;
        var txt = String(el.textContent || '').replace(/\s+/g, '');
        if (/^\d{20}$/.test(txt)) {
          el.setAttribute('data-pfa-tok-copy', '1');
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'btn btn-outline-primary btn-sm py-0 px-1 ms-1';
          btn.style.fontSize = '0.68rem';
          btn.innerHTML = '<i class="bi bi-clipboard"></i>';
          btn.title = 'Salin Token 20 Digit';
          btn.onclick = function () { copyTextQuick(txt, 'Token KCT'); };
          el.appendChild(btn);
        }
      });
    }).observe(box, { childList: true, subtree: true });
  }

  // --------------------------------------------------------------------------
  // 9. PULL-TO-REFRESH PORTAL, LATENSI SERVER, BREAKDOWN ADMIN + WA REKAP, BANNER KIRIM ANTREAN
  // --------------------------------------------------------------------------
  function initPortalPullToRefresh() {
    var startY = 0;
    document.addEventListener('touchstart', function (e) {
      if (window.scrollY === 0 && e.touches && e.touches.length === 1) startY = e.touches[0].clientY;
    }, { passive: true });
    document.addEventListener('touchend', function (e) {
      var portal = document.getElementById('tab-portal');
      if (!portal || portal.classList.contains('d-none')) return;
      var endY = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0].clientY : 0;
      if (startY > 0 && window.scrollY === 0 && (endY - startY) > 95) {
        if (typeof window.showToast === 'function') window.showToast('Menyegarkan data Portal...', 'info');
        measureServerLatencyAndSummary();
      }
      startY = 0;
    }, { passive: true });
  }

  function measureServerLatencyAndSummary() {
    if (navigator.onLine === false || typeof window.callApi !== 'function') return;
    var t0 = Date.now();
    window.callApi({ action: 'get_portal_summary', forceRefresh: true }).then(function (res) {
      var ms = Date.now() - t0;
      var stEl = document.getElementById('pfaStatServer');
      if (stEl) stEl.textContent = ms < 2000 ? ('Aktif • ' + ms + 'ms') : ('Lambat • ' + (ms / 1000).toFixed(1) + 's');
      if (ms > 2500 && typeof window.showToast === 'function') {
        window.showToast('Koneksi server agak lambat (' + (ms / 1000).toFixed(1) + 's). Disarankan aktifkan Mode Sinyal Lemah.', 'warning');
      }
      if (res && res.status === 'success') {
        LAST_PORTAL_SUMMARY = res;
        renderAdminBreakdownStrip(res);
      }
    }).catch(function () {});
  }

  function renderAdminBreakdownStrip(res) {
    if (!res || res.scope !== 'ALL_PETUGAS' || !res.counts) return;
    var hero = document.querySelector('#tab-portal .pfa-portal-hero');
    if (!hero) return;
    var strip = document.getElementById('pfaAdminBreakdownStrip');
    if (!strip) {
      strip = document.createElement('div');
      strip.id = 'pfaAdminBreakdownStrip';
      strip.className = 'd-flex align-items-center justify-content-between gap-2 mt-2 pt-2';
      strip.style.borderTop = '1px solid rgba(255,255,255,0.16)';
      strip.style.fontSize = '0.7rem';
      hero.appendChild(strip);
    }
    var c = res.counts;
    strip.innerHTML =
      '<div class="opacity-90 text-truncate">DG: <strong>' + (c.gangguan || 0) + '</strong> • Ukur: <strong>' + (c.pengukuran || 0) + '</strong> • P2TL: <strong>' + (c.p2tl || 0) + '</strong> • Mat: <strong>' + (c.material || 0) + '</strong></div>' +
      '<button type="button" id="pfaAdminCopyWaRekap" class="btn btn-sm py-0 px-2 fw-bold flex-shrink-0" style="background:#ffd100;color:#091a32;font-size:0.68rem;border-radius:999px;">Rekap WA</button>';

    document.getElementById('pfaAdminCopyWaRekap').onclick = function () {
      var tgl = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
      var txt = [
        '*REKAP OPERASIONAL PFA — PLN ULP PELABUHAN RATU*',
        'Tanggal: ' + tgl,
        '• Meter Rusak / Gangguan: ' + (c.gangguan || 0),
        '• Pengukuran Deviasi: ' + (c.pengukuran || 0),
        '• Potensi P2TL: ' + (c.p2tl || 0),
        '• Transaksi Material: ' + (c.material || 0),
        '*Total Laporan Tercatat: ' + (c.total || 0) + '*'
      ].join('\n');
      copyTextQuick(txt, 'Rekap Harian WA');
    };
  }

  // --------------------------------------------------------------------------
  // 10. DASHBOARD SALDO KWH METER PER POSKO YANTEK (KHUSUS ADMIN)
  // --------------------------------------------------------------------------
  function injectAdminPoskoKwhDashboard() {
    var admTab = document.getElementById('tab-admin');
    if (!admTab || document.getElementById('subnav-adm-posko')) return;
    var navWrap = admTab.querySelector('#subnav-adm-gangguan') && admTab.querySelector('#subnav-adm-gangguan').parentElement;
    if (!navWrap) return;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'subnav-adm-posko';
    btn.className = 'adm-nav-tile';
    btn.innerHTML = '<i class="bi bi-speedometer text-warning"></i><span>Saldo kWh</span>';
    navWrap.appendChild(btn);

    var panel = document.createElement('div');
    panel.id = 'admSubTab-posko';
    panel.className = 'adm-subtab d-none';
    panel.innerHTML =
      '<div class="card card-modern mb-3"><div class="card-body p-3">' +
        '<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">' +
          '<div class="section-title mb-0">Dashboard Saldo kWh Meter per Posko Petugas</div>' +
          '<div class="d-flex gap-1">' +
            '<button type="button" id="pfaPoskoCopyWaBtn" class="btn btn-sm btn-success fw-semibold"><i class="bi bi-whatsapp me-1"></i>Salin WA</button>' +
            '<button type="button" id="pfaPoskoRefreshBtn" class="btn btn-sm btn-primary fw-semibold"><i class="bi bi-arrow-clockwise me-1"></i>Muat</button>' +
          '</div>' +
        '</div>' +
        '<div class="row g-2 mb-3 text-center" id="pfaPoskoTotalsRow">' +
          '<div class="col-3"><div class="p-2 rounded-3 bg-primary-subtle"><div class="small text-muted" style="font-size:0.68rem;">Drop Masuk</div><div class="fw-bold fs-6" id="pfaPkTotDrop">0</div></div></div>' +
          '<div class="col-3"><div class="p-2 rounded-3 bg-info-subtle"><div class="small text-muted" style="font-size:0.68rem;">Terpakai</div><div class="fw-bold fs-6" id="pfaPkTotPakai">0</div></div></div>' +
          '<div class="col-3"><div class="p-2 rounded-3 bg-warning-subtle"><div class="small text-muted" style="font-size:0.68rem;">Retur</div><div class="fw-bold fs-6" id="pfaPkTotRetur">0</div></div></div>' +
          '<div class="col-3"><div class="p-2 rounded-3 bg-success-subtle"><div class="small text-muted" style="font-size:0.68rem;">Sisa Saldo</div><div class="fw-bold fs-6" id="pfaPkTotSisa">0</div></div></div>' +
        '</div>' +
        '<div id="pfaPoskoCardsContainer" class="mb-3"><div class="small text-muted text-center py-2">Klik Muat untuk mengambil saldo posko...</div></div>' +
        '<hr>' +
        '<div class="section-title">Catat Drop Masuk / Retur kWh Meter Posko</div>' +
        '<div class="row g-2 mb-3">' +
          '<div class="col-6"><input type="text" id="pfaMutPosko" class="form-control form-control-sm" placeholder="Nama Posko (mis: Posko Cisolok)"></div>' +
          '<div class="col-6"><select id="pfaMutJenis" class="form-select form-select-sm"><option value="DROP_MASUK">Drop Masuk (+)</option><option value="RETUR_KEMBALI">Retur Kembali (-)</option><option value="KOREKSI">Koreksi Opname</option></select></div>' +
          '<div class="col-6"><input type="text" id="pfaMutTipe" class="form-control form-control-sm" value="Prabayar 1 Fasa" placeholder="Tipe Meter"></div>' +
          '<div class="col-3"><input type="number" id="pfaMutQty" class="form-control form-control-sm" placeholder="Jml"></div>' +
          '<div class="col-3 d-grid"><button type="button" id="pfaMutSaveBtn" class="btn btn-sm btn-primary fw-bold">Simpan</button></div>' +
          '<div class="col-12"><input type="text" id="pfaMutKet" class="form-control form-control-sm" placeholder="No. Surat Jalan / Keterangan (opsional)"></div>' +
        '</div>' +
        '<div class="section-title">Atur Identitas Posko Petugas Petugas</div>' +
        '<div class="row g-2">' +
          '<div class="col-6"><select id="pfaMapUserSel" class="form-select form-select-sm"><option value="">-- Pilih Petugas --</option></select></div>' +
          '<div class="col-4"><input type="text" id="pfaMapPoskoInp" class="form-control form-control-sm" placeholder="Nama Posko"></div>' +
          '<div class="col-2 d-grid"><button type="button" id="pfaMapSaveBtn" class="btn btn-sm btn-success fw-bold">Set</button></div>' +
        '</div>' +
      '</div></div>';

    admTab.appendChild(panel);

    var lastPoskoData = null;
    function loadPoskoDashboard() {
      var box = document.getElementById('pfaPoskoCardsContainer');
      if (box) box.innerHTML = '<div class="small text-muted text-center py-2">Memuat data saldo kWh per posko...</div>';
      window.callApi({ action: 'admin_get_saldo_kwh_posko' }).then(function (res) {
        if (!res || res.status !== 'success') {
          if (box) box.innerHTML = '<div class="alert alert-warning py-2 small mb-0">' + escHtml((res && res.message) || 'Pastikan PoskoKwh_v214.gs sudah dipasang di GAS.') + '</div>';
          return;
        }
        lastPoskoData = res;
        var t = res.totals || {};
        document.getElementById('pfaPkTotDrop').textContent = String(t.dropMasuk || 0);
        document.getElementById('pfaPkTotPakai').textContent = String(t.terpakai || 0);
        document.getElementById('pfaPkTotRetur').textContent = String(t.returKembali || 0);
        document.getElementById('pfaPkTotSisa').textContent = String(t.sisaSaldo || 0);

        var rowsHtml = (res.poskoList || []).map(function (p) {
          var badgeCls = p.sisaSaldo <= 2 ? 'text-bg-danger' : (p.sisaSaldo <= 5 ? 'text-bg-warning' : 'text-bg-success');
          return (
            '<tr>' +
              '<td class="fw-bold">' + escHtml(p.posko) + '<div class="text-muted" style="font-size:0.66rem;">' + (p.jumlahPetugas || 0) + ' petugas</div></td>' +
              '<td class="text-center">' + p.dropMasuk + '</td>' +
              '<td class="text-center">' + p.terpakai + '</td>' +
              '<td class="text-center">' + p.returKembali + '</td>' +
              '<td class="text-center"><span class="badge ' + badgeCls + ' rounded-pill">' + p.sisaSaldo + '</span></td>' +
            '</tr>'
          );
        }).join('');

        box.innerHTML =
          '<div class="table-responsive"><table class="table table-sm align-middle mb-0 small">' +
            '<thead><tr><th>Posko</th><th class="text-center">Drop</th><th class="text-center">Pakai</th><th class="text-center">Retur</th><th class="text-center">Sisa</th></tr></thead>' +
            '<tbody>' + (rowsHtml || '<tr><td colspan="5" class="text-center text-muted">Belum ada data posko.</td></tr>') + '</tbody>' +
          '</table></div>';

        var sel = document.getElementById('pfaMapUserSel');
        if (sel && Array.isArray(res.petugasList)) {
          sel.innerHTML = '<option value="">-- Pilih Petugas --</option>' + res.petugasList.map(function (u) {
            return '<option value="' + escHtml(u.username) + '" data-nama="' + escHtml(u.nama) + '" data-role="' + escHtml(u.role) + '">' +
              escHtml(u.nama) + (u.posko ? ' [' + escHtml(u.posko) + ']' : '') + '</option>';
          }).join('');
        }
      }).catch(function (err) {
        if (box) box.innerHTML = '<div class="alert alert-danger py-2 small mb-0">' + escHtml(err.message || err) + '</div>';
      });
    }

    btn.onclick = function () {
      admTab.querySelectorAll('.adm-subtab, [id^="adm-sub-"]').forEach(function (s) { s.classList.add('d-none'); });
      navWrap.querySelectorAll('button').forEach(function (b) {
        b.classList.remove('btn-primary');
        b.classList.add('btn-outline-secondary');
      });
      btn.classList.remove('btn-outline-secondary');
      btn.classList.add('btn-primary');
      panel.classList.remove('d-none');
      loadPoskoDashboard();
    };

    if (typeof window.switchAdminSubTab === 'function' && !window._pfaAdmPoskoHooked) {
      window._pfaAdmPoskoHooked = true;
      var origAdmSw = window.switchAdminSubTab;
      window.switchAdminSubTab = function () {
        panel.classList.add('d-none');
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-secondary');
        return origAdmSw.apply(this, arguments);
      };
    }

    document.getElementById('pfaPoskoRefreshBtn').onclick = loadPoskoDashboard;
    document.getElementById('pfaPoskoCopyWaBtn').onclick = function () {
      if (!lastPoskoData) return;
      var lines = ['*SALDO KWH METER PER POSKO YANTEK — ULP PELABUHAN RATU*'];
      (lastPoskoData.poskoList || []).forEach(function (p) {
        lines.push('• ' + p.posko + ': Sisa *' + p.sisaSaldo + '* (Drop ' + p.dropMasuk + ' | Pakai ' + p.terpakai + ' | Retur ' + p.returKembali + ')');
      });
      copyTextQuick(lines.join('\n'), 'Saldo kWh Posko WA');
    };

    document.getElementById('pfaMutSaveBtn').onclick = function () {
      var posko = document.getElementById('pfaMutPosko').value.trim();
      var jenis = document.getElementById('pfaMutJenis').value;
      var tipeMeter = document.getElementById('pfaMutTipe').value.trim();
      var jumlah = Number(document.getElementById('pfaMutQty').value || 0);
      var keterangan = document.getElementById('pfaMutKet').value.trim();
      if (!posko || !jumlah) {
        if (typeof window.showToast === 'function') window.showToast('Isi nama Posko dan jumlah unit.', 'warning');
        return;
      }
      window.callApi({
        action: 'admin_simpan_mutasi_kwh_posko',
        data: { posko: posko, jenis: jenis, tipeMeter: tipeMeter, jumlah: jumlah, keterangan: keterangan }
      }).then(function (r) {
        if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Tersimpan.', r && r.status === 'success' ? 'success' : 'danger');
        if (r && r.status === 'success') {
          document.getElementById('pfaMutQty').value = '';
          loadPoskoDashboard();
        }
      });
    };

    document.getElementById('pfaMapSaveBtn').onclick = function () {
      var sel = document.getElementById('pfaMapUserSel');
      var opt = sel.options[sel.selectedIndex];
      var uname = sel.value;
      var posko = document.getElementById('pfaMapPoskoInp').value.trim();
      if (!uname || !posko) {
        if (typeof window.showToast === 'function') window.showToast('Pilih petugas dan isi nama Posko.', 'warning');
        return;
      }
      window.callApi({
        action: 'admin_set_posko_petugas',
        username: uname,
        namaPetugas: opt ? opt.getAttribute('data-nama') : uname,
        rolePetugas: opt ? opt.getAttribute('data-role') : 'Petugas',
        posko: posko
      }).then(function (r) {
        if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Posko tersimpan.', r && r.status === 'success' ? 'success' : 'danger');
        if (r && r.status === 'success') loadPoskoDashboard();
      });
    };
  }

  // Hook callApi untuk Share WA instan setelah simpan
  function hookWaShareOnSave() {
    if (typeof window.callApi !== 'function' || window._pfaV214WaHooked) return;
    window._pfaV214WaHooked = true;
    var orig = window.callApi;
    window.callApi = async function (payload) {
      var res = await orig(payload);
      var act = payload && payload.action;
      if (res && res.status === 'success' && (act === 'simpan_gangguan' || act === 'simpan_pengukuran')) {
        showInstantWaShareBar(buildWaReportText(act, payload.data || {}, Boolean(res.queuedOffline)));
      }
      return res;
    };
  }

  // Toggle Watermark Foto di Modal Pengaturan
  document.addEventListener('shown.bs.modal', function (ev) {
    if (ev.target && ev.target.id === 'historiSayaModal') injectHistoriSearchFilter();
    if (ev.target && ev.target.id === 'pfaCompactSettingsModal' && !document.getElementById('pfaSetWmBtn')) {
      var grp = ev.target.querySelector('.pfa-settings-group');
      if (grp) {
        var on = localStorage.getItem(WATERMARK_PREF_KEY) === '1';
        var b = document.createElement('button');
        b.type = 'button';
        b.id = 'pfaSetWmBtn';
        b.className = 'pfa-settings-row';
        b.innerHTML =
          '<span><i class="bi bi-camera-fill me-2 text-success"></i>Watermark Foto Otomatis</span>' +
          '<span class="badge ' + (on ? 'text-bg-success' : 'text-bg-secondary') + ' rounded-pill" id="pfaSetWmVal">' + (on ? 'AKTIF' : 'OFF') + '</span>';
        b.onclick = function () {
          var next = localStorage.getItem(WATERMARK_PREF_KEY) !== '1';
          try { localStorage.setItem(WATERMARK_PREF_KEY, next ? '1' : '0'); } catch (e) {}
          var v = document.getElementById('pfaSetWmVal');
          if (v) {
            v.textContent = next ? 'AKTIF' : 'OFF';
            v.className = 'badge ' + (next ? 'text-bg-success' : 'text-bg-secondary') + ' rounded-pill';
          }
        };
        grp.appendChild(b);
      }
    }
  });

  window.addEventListener('load', function () {
    ensureOfflineSessionEntry();
    hookWaShareOnSave();
    initPortalPullToRefresh();
    initStopwatchWakeLock();
    enhanceKctCopyTokens();
    setTimeout(enhanceGpsFields, 450);
    setTimeout(injectPengukuranQuickTools, 650);
    setTimeout(injectDilCopyButtons, 650);
    setTimeout(initPortalSearchHistoryAndValidation, 500);
    setTimeout(injectAdminPoskoKwhDashboard, 600);
    setTimeout(measureServerLatencyAndSummary, 1100);
  });
})();

/* ==========================================================================
   PFA v2.0.24 — UI DASHBOARD SALDO KWH METER POSKO YANTEK (MOCKUP EDITION)
   ========================================================================== */
(function () {
  'use strict';

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function upgradePoskoDashboardUi() {
    var panel = document.getElementById('admSubTab-posko');
    if (!panel || panel.getAttribute('data-pfa-v2110') === '1') return;
    panel.setAttribute('data-pfa-v2110', '1');

    panel.innerHTML =
      '<div class="card card-modern mb-3"><div class="card-body p-3">' +
        '<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">' +
          '<div>' +
            '<div class="section-title mb-0">Saldo kWh Meter Posko &amp; Tim P2TL</div>' +
            '<div class="small text-muted" style="font-size:0.72rem;">Sinkron STOCK KWH METER • Akun_Petugas (Regu) • Rekap_Gangguan</div>' +
          '</div>' +
          '<div class="d-flex gap-1">' +
            '<button type="button" id="pfaPkWaBtn215" class="btn btn-sm fw-bold" style="background:#ffd100;color:#091a32;"><i class="bi bi-whatsapp me-1"></i>Rekap WA</button>' +
            '<button type="button" id="pfaPkRefBtn215" class="btn btn-sm btn-primary fw-semibold"><i class="bi bi-arrow-clockwise"></i></button>' +
          '</div>' +
        '</div>' +

        '<div class="row g-2 mb-3 text-center">' +
          '<div class="col-3"><div class="p-2 rounded-3 bg-primary-subtle"><div class="fw-bold fs-6" id="pfa215Ambil">0</div><div class="small text-muted" style="font-size:0.66rem;">Ambil</div></div></div>' +
          '<div class="col-3"><div class="p-2 rounded-3 bg-info-subtle"><div class="fw-bold fs-6" id="pfa215Pakai">0</div><div class="small text-muted" style="font-size:0.66rem;">Pakai</div></div></div>' +
          '<div class="col-3"><div class="p-2 rounded-3 bg-warning-subtle"><div class="fw-bold fs-6" id="pfa215Retur">0</div><div class="small text-muted" style="font-size:0.66rem;">Retur</div></div></div>' +
          '<div class="col-3"><div class="p-2 rounded-3 bg-success-subtle"><div class="fw-bold fs-6" id="pfa215Sisa">0</div><div class="small text-muted" style="font-size:0.66rem;">Sisa</div></div></div>' +
        '</div>' +

        '<div class="d-flex gap-1 mb-3 flex-wrap" id="pfa215FilterWrap">' +
          '<button type="button" class="btn btn-sm btn-primary rounded-pill px-3 py-1" data-pkfilter="all" style="font-size:0.73rem;">Semua Posko</button>' +
          '<button type="button" class="btn btn-sm btn-outline-secondary rounded-pill px-3 py-1" data-pkfilter="low" style="font-size:0.73rem;">Stok Menipis</button>' +
          '<button type="button" class="btn btn-sm btn-outline-secondary rounded-pill px-3 py-1" data-pkfilter="anomali" id="pfa215AnomTabBtn" style="font-size:0.73rem;">Anomali (0)</button>' +
        '</div>' +

        '<div id="pfa215AnomBox" class="pfa-anomali-box d-none"></div>' +
        '<div id="pfa215CardsWrap"><div class="small text-muted text-center py-3">Memuat data STOCK KWH METER...</div></div>' +
      '</div></div>' +

      '<div class="card card-modern mb-3"><div class="card-body p-3">' +
        '<div class="section-title">Catat Drop ke Posko / Retur ke ULP</div>' +
        '<div class="btn-group w-100 mb-2" role="group">' +
          '<button type="button" id="pfa215ModeDrop" class="btn btn-sm btn-primary fw-semibold">Drop ke Posko</button>' +
          '<button type="button" id="pfa215ModeRetur" class="btn btn-sm btn-outline-secondary fw-semibold">Retur ke ULP</button>' +
        '</div>' +
        '<div class="row g-2">' +
          '<div class="col-12">' +
            '<div class="input-group input-group-sm">' +
              '<input type="text" id="pfa215NoMeter" class="form-control" placeholder="Scan / ketik No. Meter (11 digit)...">' +
              '<button type="button" id="pfa215ScanBtn" class="btn pfa-kct-scan-btn" title="Scan Barcode Meter"><i class="bi bi-qr-code-scan"></i></button>' +
            '</div>' +
          '</div>' +
          '<div class="col-6" id="pfa215DusWrap"><input type="text" id="pfa215NoDus" class="form-control form-control-sm" placeholder="No. Dus (opsional)"></div>' +
          '<div class="col-6" id="pfa215PoskoWrap">' +
            '<select id="pfa215PoskoSel" class="form-select form-select-sm">' +
              '<option value="">-- Pilih Posko / Regu --</option>' +
              '<option value="CIEMAS">CIEMAS</option>' +
              '<option value="JAMPANG">JAMPANG</option>' +
              '<option value="KELAT">KELAT</option>' +
              '<option value="KIARA">KIARA</option>' +
              '<option value="RATU">RATU</option>' +
              '<option value="SURADE">SURADE</option>' +
              '<option value="TAMAN">TAMAN</option>' +
            '</select>' +
          '</div>' +
          '<div class="col-12 d-grid">' +
            '<button type="button" id="pfa215SaveMutBtn" class="btn btn-primary btn-sm fw-bold py-2">Simpan Mutasi</button>' +
          '</div>' +
        '</div>' +
      '</div></div>';

    var currentData = null;
    var currentFilter = 'all';
    var mutMode = 'DROP_MASUK';

    function renderList() {
      var wrap = document.getElementById('pfa215CardsWrap');
      var anomBox = document.getElementById('pfa215AnomBox');
      if (!currentData || !wrap) return;

      var anoms = currentData.anomali || [];
      var anomBtn = document.getElementById('pfa215AnomTabBtn');
      if (anomBtn) anomBtn.textContent = 'Anomali (' + anoms.length + ')';

      if (anoms.length > 0 && (currentFilter === 'all' || currentFilter === 'anomali')) {
        anomBox.classList.remove('d-none');
        anomBox.innerHTML =
          '<div class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill text-warning me-1"></i>Deteksi Anomali (' + anoms.length + ')</div>' +
          '<ul class="mb-0 ps-3">' +
            anoms.slice(0, currentFilter === 'anomali' ? 20 : 3).map(function (a) {
              return '<li class="mb-1">' + esc(a.pesan) + '</li>';
            }).join('') +
          '</ul>';
      } else {
        anomBox.classList.add('d-none');
      }

      if (currentFilter === 'anomali') {
        wrap.innerHTML = anoms.length === 0
          ? '<div class="small text-success text-center py-2"><i class="bi bi-check-circle-fill me-1"></i>Tidak ada anomali meter terdeteksi.</div>'
          : '';
        return;
      }

      var list = (currentData.poskoList || []).filter(function (p) {
        return currentFilter === 'low' ? (p.sisa <= 10) : true;
      });

      if (!list.length) {
        wrap.innerHTML = '<div class="small text-muted text-center py-2">Tidak ada posko yang sesuai filter.</div>';
        return;
      }

      wrap.innerHTML = list.map(function (p) {
        var tot = Math.max(1, p.ambil || 1);
        var pctPakai = Math.round((p.terpakai / tot) * 100);
        var pctRetur = Math.round((p.retur / tot) * 100);
        var pctSisa = Math.max(0, 100 - pctPakai - pctRetur);
        var badgeCls = p.sisa <= 3 ? 'text-bg-danger' : (p.sisa <= 10 ? 'text-bg-warning' : 'text-bg-success');

        return (
          '<div class="pfa-posko-card">' +
            '<div class="pfa-posko-top">' +
              '<span class="pfa-posko-name">POSKO ' + esc(p.posko) + '</span>' +
              '<span class="badge ' + badgeCls + ' rounded-pill">Sisa ' + p.sisa + '</span>' +
            '</div>' +
            '<div class="pfa-posko-meta">Ambil <strong>' + p.ambil + '</strong> • Pakai <strong>' + p.terpakai + '</strong> • Retur <strong>' + p.retur + '</strong>' +
              (p.jumlahPetugas ? (' • ' + p.jumlahPetugas + ' Petugas') : '') +
            '</div>' +
            '<div class="pfa-posko-bar">' +
              '<div class="pfa-posko-bar-used" style="width:' + pctPakai + '%"></div>' +
              '<div class="pfa-posko-bar-retur" style="width:' + pctRetur + '%"></div>' +
              '<div class="pfa-posko-bar-sisa" style="width:' + pctSisa + '%"></div>' +
            '</div>' +
          '</div>'
        );
      }).join('');
    }

    function loadData() {
      var wrap = document.getElementById('pfa215CardsWrap');
      if (wrap) wrap.innerHTML = '<div class="small text-muted text-center py-3">Mengambil data STOCK KWH METER...</div>';
      window.callApi({ action: 'admin_get_saldo_kwh_posko' }).then(function (res) {
        if (!res || res.status !== 'success') {
          if (wrap) wrap.innerHTML = '<div class="alert alert-warning small py-2 mb-0">' + esc((res && res.message) || 'Gagal memuat data saldo posko.') + '</div>';
          return;
        }
        currentData = res;
        var t = res.totals || {};
        document.getElementById('pfa215Ambil').textContent = String(t.ambil || 0);
        document.getElementById('pfa215Pakai').textContent = String(t.terpakai || 0);
        document.getElementById('pfa215Retur').textContent = String(t.retur || 0);
        document.getElementById('pfa215Sisa').textContent = String(t.sisa || 0);
        renderList();
      }).catch(function (err) {
        if (wrap) wrap.innerHTML = '<div class="alert alert-danger small py-2 mb-0">' + esc(err.message || err) + '</div>';
      });
    }

    document.getElementById('pfaPkRefBtn215').onclick = loadData;
    var scBtn = document.getElementById('pfa215ScanBtn');
    if (scBtn) scBtn.onclick = function () { if (typeof window.openBarcodeScanner === 'function') window.openBarcodeScanner('pfa215NoMeter'); };
    document.getElementById('pfaPkWaBtn215').onclick = function () {
      if (!currentData) return;
      var t = currentData.totals || {};
      var lines = [
        '*SALDO KWH METER POSKO YANTEK — ULP PELABUHAN RATU*',
        'Total: Ambil ' + (t.ambil || 0) + ' | Pakai ' + (t.terpakai || 0) + ' | Retur ' + (t.retur || 0) + ' | *Sisa ' + (t.sisa || 0) + '*',
        ''
      ];
      (currentData.poskoList || []).forEach(function (p) {
        lines.push('• *POSKO ' + p.posko + '*: Sisa *' + p.sisa + '* (Ambil ' + p.ambil + ', Pakai ' + p.terpakai + ', Retur ' + p.retur + ')');
      });
      if ((currentData.anomali || []).length > 0) {
        lines.push('', '⚠ Anomali terdeteksi: ' + currentData.anomali.length + ' nomor meter');
      }
      window.open('https://wa.me/?text=' + encodeURIComponent(lines.join('\n')), '_blank');
    };

    document.querySelectorAll('#pfa215FilterWrap [data-pkfilter]').forEach(function (b) {
      b.onclick = function () {
        currentFilter = b.getAttribute('data-pkfilter');
        document.querySelectorAll('#pfa215FilterWrap [data-pkfilter]').forEach(function (x) {
          x.classList.toggle('btn-primary', x === b);
          x.classList.toggle('btn-outline-secondary', x !== b);
        });
        renderList();
      };
    });

    document.getElementById('pfa215ModeDrop').onclick = function () {
      mutMode = 'DROP_MASUK';
      this.className = 'btn btn-sm btn-primary fw-semibold';
      document.getElementById('pfa215ModeRetur').className = 'btn btn-sm btn-outline-secondary fw-semibold';
      document.getElementById('pfa215DusWrap').classList.remove('d-none');
      document.getElementById('pfa215PoskoWrap').classList.remove('d-none');
    };

    document.getElementById('pfa215ModeRetur').onclick = function () {
      mutMode = 'RETUR_KEMBALI';
      this.className = 'btn btn-sm btn-warning fw-semibold';
      document.getElementById('pfa215ModeDrop').className = 'btn btn-sm btn-outline-secondary fw-semibold';
      document.getElementById('pfa215DusWrap').classList.add('d-none');
      document.getElementById('pfa215PoskoWrap').classList.add('d-none');
    };

    document.getElementById('pfa215SaveMutBtn').onclick = function () {
      var noMeter = document.getElementById('pfa215NoMeter').value.trim();
      var noDus = document.getElementById('pfa215NoDus').value.trim();
      var posko = document.getElementById('pfa215PoskoSel').value;
      if (!noMeter) {
        if (typeof window.showToast === 'function') window.showToast('Scan atau ketik Nomor Meter dulu.', 'warning');
        return;
      }
      if (mutMode === 'DROP_MASUK' && !posko) {
        if (typeof window.showToast === 'function') window.showToast('Pilih Posko / Regu tujuan dulu.', 'warning');
        return;
      }
      window.callApi({
        action: 'admin_simpan_mutasi_kwh_posko',
        data: { jenis: mutMode, noMeter: noMeter, noDus: noDus || '-', posko: posko }
      }).then(function (r) {
        if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Tersimpan.', r && r.status === 'success' ? 'success' : 'danger');
        if (r && r.status === 'success') {
          document.getElementById('pfa215NoMeter').value = '';
          loadData();
        }
      });
    };

    var navBtn = document.getElementById('subnav-adm-posko');
    if (navBtn) {
      var origClick = navBtn.onclick;
      navBtn.onclick = function () {
        if (typeof origClick === 'function') origClick.apply(this, arguments);
        loadData();
      };
    }
  }

  window.addEventListener('load', function () {
    setTimeout(upgradePoskoDashboardUi, 850);
  });
})();

/* ==========================================================================
   PFA v2.0.24 — SERAH TERIMA KWH METER 2 ARAH (AI SCAN DUS, TTD+FOTO, PDF)
   Pengembang: JODI SETIAWAN — PLN ULP Pelabuhan Ratu
   ========================================================================== */
(function () {
  'use strict';

  var DROP_CART = []; // [{ noMeter, noDus }]

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function extractMetersFromQrText(rawText) {
    var txt = String(rawText || '');
    var matches = txt.match(/\b\d{11,12}\b/g) || [];
    var uniq = [];
    var seen = {};
    matches.forEach(function (m) {
      if (!seen[m]) { seen[m] = true; uniq.push(m); }
    });
    return uniq;
  }

  function addItemsToCart(meters, noDus) {
    var added = 0;
    var seen = {};
    DROP_CART.forEach(function (x) { seen[x.noMeter] = true; });
    (meters || []).forEach(function (m) {
      var clean = String(m || '').replace(/[^0-9A-Za-z]/g, '').toUpperCase();
      if (clean.length >= 10 && !seen[clean]) {
        seen[clean] = true;
        DROP_CART.push({ noMeter: clean, noDus: String(noDus || '-').trim() || '-' });
        added++;
      }
    });
    return added;
  }

  // --------------------------------------------------------------------------
  // A. UPGRADE PANEL ADMIN: DROPDOWN POSKO DINAMIS, AI SCAN DUS, KERANJANG, ANTREAN BA
  // --------------------------------------------------------------------------
  function upgradeAdminPoskoV217() {
    var panel = document.getElementById('admSubTab-posko');
    if (!panel || panel.getAttribute('data-pfa-v2110') === '1') return;
    panel.setAttribute('data-pfa-v2110', '1');

    var mutCard = panel.querySelectorAll('.card.card-modern')[1];
    if (!mutCard) return;

    mutCard.innerHTML =
      '<div class="card-body p-3">' +
        '<div class="section-title">Drop kWh Meter ke Posko (QR BOX / AI Scan Dus)</div>' +
        '<div class="btn-group w-100 mb-2" role="group">' +
          '<button type="button" id="pfa217TabDrop" class="btn btn-sm btn-primary fw-semibold">Drop ke Posko</button>' +
          '<button type="button" id="pfa217TabRetur" class="btn btn-sm btn-outline-secondary fw-semibold">Retur ke ULP</button>' +
        '</div>' +

        '<div id="pfa217DropBox">' +
          '<div class="d-flex gap-2 mb-2">' +
            '<button type="button" id="pfa217ScanQrBtn" class="btn btn-sm btn-outline-primary flex-fill fw-semibold"><i class="bi bi-qr-code-scan me-1"></i>Scan Beruntun</button>' +
            '<label class="btn btn-sm btn-primary flex-fill fw-semibold mb-0" style="cursor:pointer;">' +
              '<i class="bi bi-camera-fill me-1 text-warning"></i>Foto 1 Dus (AI Semua)' +
              '<input type="file" id="pfa217AiDusFile" accept="image/*" class="d-none">' +
            '</label>' +
          '</div>' +
          '<div class="input-group input-group-sm mb-2">' +
            '<input type="text" id="pfa217ManualMeter" class="form-control" placeholder="Atau ketik No. Meter manual...">' +
            '<input type="text" id="pfa217ManualDus" class="form-control" placeholder="No. Dus" style="max-width:110px;">' +
            '<button type="button" id="pfa217AddManualBtn" class="btn btn-outline-primary fw-bold">+</button>' +
          '</div>' +
          '<div id="pfa217CartBox" class="p-2 rounded-3 bg-light border mb-2 small">' +
            '<div class="text-muted text-center py-1">Keranjang kosong. Scan QR BOX atau foto label dus untuk mulai.</div>' +
          '</div>' +
          '<div class="row g-2 mb-2">' +
            '<div class="col-6"><select id="pfa217PoskoSel" class="form-select form-select-sm"><option value="">-- Pilih Posko / P2TL --</option><option value="CIEMAS">CIEMAS</option><option value="CIKELAT">CIKELAT</option><option value="JAMPANG">JAMPANG</option><option value="KIARA">KIARA</option><option value="P2TL">P2TL</option><option value="RATU">RATU</option><option value="SURADE">SURADE</option><option value="TAMAN JAYA">TAMAN JAYA</option></select></div>' +
            '<div class="col-6"><input type="text" id="pfa217CatatanInp" class="form-control form-control-sm" placeholder="Catatan (opsional)"></div>' +
          '</div>' +
          '<div class="d-grid">' +
            '<button type="button" id="pfa217SendDropBtn" class="btn btn-primary btn-sm fw-bold py-2"><i class="bi bi-send-check-fill me-1"></i>Kirim Drop ke Posko (0 Unit)</button>' +
          '</div>' +
        '</div>' +

        '<div id="pfa217ReturBox" class="d-none">' +
          '<div class="input-group input-group-sm mb-2">' +
            '<input type="text" id="pfa217ReturMeter" class="form-control" placeholder="Scan / ketik No. Meter retur...">' +
            '<button type="button" id="pfa217ReturScanBtn" class="btn pfa-kct-scan-btn"><i class="bi bi-qr-code-scan"></i></button>' +
          '</div>' +
          '<div class="row g-2">' +
            '<div class="col-7"><select id="pfa217ReturAlasan" class="form-select form-select-sm"><option value="Sisa Stok">Sisa Stok</option><option value="Rusak Pabrik">Rusak Pabrik</option><option value="Salah Drop">Salah Drop</option></select></div>' +
            '<div class="col-5 d-grid"><button type="button" id="pfa217ReturSaveBtn" class="btn btn-warning btn-sm fw-bold">Simpan Retur</button></div>' +
          '</div>' +
        '</div>' +
      '</div>';

    // Kartu Riwayat & Status Serah Terima (MENUNGGU TERIMA >24 Jam / DITERIMA + PDF / DITOLAK)
    var histCard = document.createElement('div');
    histCard.className = 'card card-modern mb-3';
    histCard.innerHTML =
      '<div class="card-body p-3">' +
        '<div class="section-title">Status Serah Terima &amp; Surat Jalan PDF</div>' +
        '<div id="pfa217SerahTerimaWrap" class="small text-muted text-center py-2">Memuat riwayat serah terima...</div>' +
      '</div>';
    panel.appendChild(histCard);

    function renderCart() {
      var box = document.getElementById('pfa217CartBox');
      var sendBtn = document.getElementById('pfa217SendDropBtn');
      if (sendBtn) sendBtn.innerHTML = '<i class="bi bi-send-check-fill me-1"></i>Kirim Drop ke Posko (' + DROP_CART.length + ' Unit)';
      if (!box) return;
      if (!DROP_CART.length) {
        box.innerHTML = '<div class="text-muted text-center py-1">Keranjang kosong. Scan QR BOX atau foto label dus untuk mulai.</div>';
        return;
      }
      box.innerHTML =
        '<div class="d-flex justify-content-between align-items-center mb-1">' +
          '<strong class="text-primary">' + DROP_CART.length + ' Nomor Meter (' + (function(){var m={};DROP_CART.forEach(function(x){m[x.noDus]=(m[x.noDus]||0)+1;});return Object.keys(m).map(function(k){return esc(k)+': '+m[k];}).join(' • ');})() + ')</strong>' +
          '<button type="button" id="pfa217ClearCart" class="btn btn-link btn-sm text-danger p-0 text-decoration-none" style="font-size:0.72rem;">Kosongkan</button>' +
        '</div>' +
        '<div class="d-flex flex-wrap gap-1" style="max-height:140px;overflow-y:auto;">' +
          DROP_CART.map(function (it, idx) {
            return '<span class="badge text-bg-light border d-inline-flex align-items-center gap-1" style="font-family:monospace;font-size:0.7rem;">' +
              esc(it.noMeter) +
              '<button type="button" class="btn-close" style="font-size:0.5rem;" data-rm-idx="' + idx + '"></button>' +
            '</span>';
          }).join('') +
        '</div>';
      var clr = document.getElementById('pfa217ClearCart');
      if (clr) clr.onclick = function () { DROP_CART = []; renderCart(); };
      box.querySelectorAll('[data-rm-idx]').forEach(function (b) {
        b.onclick = function () {
          DROP_CART.splice(Number(b.getAttribute('data-rm-idx')), 1);
          renderCart();
        };
      });
    }

    function renderSerahTerimaAdmin(list, poskoList) {
      // Isi dropdown Posko secara otomatis dari Spreadsheet!
      var sel = document.getElementById('pfa217PoskoSel');
      if (sel && Array.isArray(poskoList) && poskoList.length) {
        var prev = sel.value;
        sel.innerHTML = '<option value="">-- Pilih Posko / Regu --</option>' + poskoList.map(function (p) {
          return '<option value="' + esc(p.posko) + '">' + (p.posko === 'P2TL' ? 'P2TL' : ('POSKO ' + esc(p.posko))) + '</option>';
        }).join('');
        if (prev) sel.value = prev;
      }

      var wrap = document.getElementById('pfa217SerahTerimaWrap');
      if (!wrap) return;
      if (!Array.isArray(list) || !list.length) {
        wrap.innerHTML = '<div class="text-muted text-center py-2">Belum ada riwayat drop serah terima.</div>';
        return;
      }
      wrap.innerHTML = list.map(function (st) {
        var badge = st.status === 'DITERIMA' ? 'text-bg-success'
          : (st.status === 'MENUNGGU TERIMA' ? 'text-bg-warning' : 'text-bg-danger');
        var overdueTag = st.overdue24 ? ' <span class="badge text-bg-danger rounded-pill">&gt;24 Jam</span>' : '';
        var actions = '';
        if (st.status === 'MENUNGGU TERIMA') {
          actions = '<button type="button" class="btn btn-outline-danger btn-sm py-0 px-2 mt-1" style="font-size:0.7rem;" data-batal-ba="' + esc(st.noBa) + '">Batalkan Drop</button>';
        } else if (st.status === 'DITERIMA' && st.pdfUrl) {
          actions =
            '<div class="d-flex gap-1 mt-1">' +
              '<a href="' + esc(st.pdfUrl) + '" target="_blank" class="btn btn-primary btn-sm py-0 px-2" style="font-size:0.7rem;"><i class="bi bi-file-earmark-pdf-fill me-1"></i>Surat Jalan PDF</a>' +
              (st.fotoUrl ? ('<a href="' + esc(st.fotoUrl) + '" target="_blank" class="btn btn-outline-secondary btn-sm py-0 px-2" style="font-size:0.7rem;">Foto</a>') : '') +
            '</div>';
        }
        return (
          '<div class="p-2 border rounded-3 mb-2 text-start">' +
            '<div class="d-flex justify-content-between align-items-center gap-1">' +
              '<strong style="font-size:0.78rem;">' + esc(st.noBa) + ' • POSKO ' + esc(st.posko) + '</strong>' +
              '<span><span class="badge ' + badge + ' rounded-pill" style="font-size:0.64rem;">' + esc(st.status) + '</span>' + overdueTag + '</span>' +
            '</div>' +
            '<div class="text-muted" style="font-size:0.7rem;">' + st.jumlah + ' unit • Dus: ' + esc(st.daftarDus) + ' • Drop: ' + esc(st.waktuDrop) + '</div>' +
            (st.penerima ? ('<div class="text-success" style="font-size:0.7rem;">Diterima: <strong>' + esc(st.penerima) + '</strong> (' + esc(st.waktuTerima) + ')</div>') : '') +
            (st.catatan ? ('<div class="text-danger" style="font-size:0.7rem;">Catatan: ' + esc(st.catatan) + '</div>') : '') +
            actions +
          '</div>'
        );
      }).join('');

      wrap.querySelectorAll('[data-batal-ba]').forEach(function (b) {
        b.onclick = function () {
          var ba = b.getAttribute('data-batal-ba');
          if (!window.confirm('Batalkan kiriman ' + ba + '?')) return;
          window.callApi({ action: 'admin_batal_drop_posko', noBa: ba }).then(function (r) {
            if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Selesai.', r && r.status === 'success' ? 'success' : 'danger');
            var ref = document.getElementById('pfaPkRefBtn215');
            if (ref) ref.click();
          });
        };
      });
    }

    // Hook admin_get_saldo_kwh_posko response to populate dropdown & serah terima list
    if (typeof window.callApi === 'function' && !window._pfaV217AdminHooked) {
      window._pfaV217AdminHooked = true;
      var origApi = window.callApi;
      window.callApi = async function (payload) {
        var res = await origApi(payload);
        if (payload && payload.action === 'admin_get_saldo_kwh_posko' && res && res.status === 'success') {
          setTimeout(function () { renderSerahTerimaAdmin(res.serahTerimaList || [], res.poskoList || []); }, 50);
        }
        return res;
      };
    }

    // Tab toggle Drop vs Retur
    document.getElementById('pfa217TabDrop').onclick = function () {
      this.className = 'btn btn-sm btn-primary fw-semibold';
      document.getElementById('pfa217TabRetur').className = 'btn btn-sm btn-outline-secondary fw-semibold';
      document.getElementById('pfa217DropBox').classList.remove('d-none');
      document.getElementById('pfa217ReturBox').classList.add('d-none');
    };
    document.getElementById('pfa217TabRetur').onclick = function () {
      this.className = 'btn btn-sm btn-warning fw-semibold';
      document.getElementById('pfa217TabDrop').className = 'btn btn-sm btn-outline-secondary fw-semibold';
      document.getElementById('pfa217DropBox').classList.add('d-none');
      document.getElementById('pfa217ReturBox').classList.remove('d-none');
    };

    // Scan QR BOX / Barcode Beruntun -> auto parse multi-meter & lanjut scan lagi jika mau!
    var continuousScanActive = false;
    function startContinuousDropScan() {
      var hiddenTarget = document.getElementById('pfa217ManualMeter');
      if (typeof window.openBarcodeScanner !== 'function' || !hiddenTarget) return;
      continuousScanActive = true;
      var handled = false;
      var onScanFilled = function () {
        if (handled) return;
        var raw = String(hiddenTarget.value || '').trim();
        if (!raw) return;
        handled = true;
        var list = extractMetersFromQrText(raw);
        var dusVal = document.getElementById('pfa217ManualDus').value.trim() || '-';
        if (list.length > 0) {
          var n = addItemsToCart(list, dusVal);
          hiddenTarget.value = '';
          renderCart();
          if (typeof window.showToast === 'function') {
            window.showToast(n + ' meter masuk (' + DROP_CART.length + ' total). Scan berikutnya atau tekan Kembali untuk selesai.', 'success');
          }
          // Jika bukan QR BOX borongan (hanya 1 meter), otomatis buka kamera lagi dalam 550ms
          if (list.length === 1 && continuousScanActive) {
            setTimeout(function () {
              if (continuousScanActive) startContinuousDropScan();
            }, 550);
          } else {
            continuousScanActive = false;
          }
        } else {
          continuousScanActive = false;
        }
      };
      hiddenTarget.addEventListener('change', onScanFilled, { once: true });
      window.openBarcodeScanner('pfa217ManualMeter');
    }
    document.getElementById('pfa217ScanQrBtn').onclick = startContinuousDropScan;

    function compressImageForAiOrUpload(file, maxW, quality, boostContrast) {
      return new Promise(function (resolve, reject) {
        var reader = new FileReader();
        reader.onerror = reject;
        reader.onload = function (e) {
          var img = new Image();
          img.onerror = reject;
          img.onload = function () {
            var ratio = img.width > maxW ? (maxW / img.width) : 1;
            var cvs = document.createElement('canvas');
            cvs.width = Math.round(img.width * ratio);
            cvs.height = Math.round(img.height * ratio);
            var ctx = cvs.getContext('2d');
            if (boostContrast && ctx.filter !== undefined) {
              ctx.filter = 'contrast(1.22) brightness(1.03)';
            }
            ctx.drawImage(img, 0, 0, cvs.width, cvs.height);
            resolve(cvs.toDataURL('image/jpeg', quality));
          };
          img.src = e.target.result;
        };
        reader.readAsDataURL(file);
      });
    }

    function openAiDusPreviewModal(initDus, initMeters) {
      var mid = 'pfaAiDusPreviewModal';
      var old = document.getElementById(mid);
      if (old) old.remove();
      var wrap = document.createElement('div');
      wrap.innerHTML =
        '<div class="modal fade" id="' + mid + '" tabindex="-1" aria-hidden="true">' +
          '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
            '<div class="modal-content rounded-4 border-0 shadow">' +
              '<div class="modal-header border-0 pb-1">' +
                '<h6 class="modal-title fw-bold"><i class="bi bi-stars text-primary me-2"></i>Pratinjau Hasil Scan AI Dus</h6>' +
                '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
              '</div>' +
              '<div class="modal-body pt-2">' +
                '<label class="form-label small fw-bold">Nomor Dus</label>' +
                '<input type="text" id="pfaAiPrevDusInp" class="form-control form-control-sm mb-2" value="' + esc(initDus || '-') + '">' +
                '<label class="form-label small fw-bold">Daftar No. Meter (<span id="pfaAiPrevCount">' + initMeters.length + '</span> unit — 1 baris 1 nomor, bisa diedit)</label>' +
                '<textarea id="pfaAiPrevMetersTa" class="form-control form-control-sm mb-3" rows="7" style="font-family:monospace;font-size:0.82rem;">' + esc(initMeters.join('\n')) + '</textarea>' +
                '<div class="d-flex gap-2">' +
                  '<button type="button" id="pfaAiPrevAddMore" class="btn btn-outline-primary btn-sm flex-fill fw-semibold"><i class="bi bi-camera me-1"></i>Foto Dus Lainnya</button>' +
                  '<button type="button" id="pfaAiPrevCommit" class="btn btn-primary btn-sm flex-fill fw-bold">Masuk Keranjang</button>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';
      document.body.appendChild(wrap.firstElementChild);
      var mEl = document.getElementById(mid);
      var bsM = window.bootstrap && window.bootstrap.Modal ? window.bootstrap.Modal.getOrCreateInstance(mEl) : null;
      var ta = document.getElementById('pfaAiPrevMetersTa');
      ta.addEventListener('input', function () {
        var lines = ta.value.split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean);
        document.getElementById('pfaAiPrevCount').textContent = String(lines.length);
      });
      function commitCurrent() {
        var dus = document.getElementById('pfaAiPrevDusInp').value.trim() || '-';
        var lines = ta.value.split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean);
        var n = addItemsToCart(lines, dus);
        renderCart();
        return n;
      }
      document.getElementById('pfaAiPrevCommit').onclick = function () {
        var n = commitCurrent();
        if (bsM) bsM.hide();
        if (typeof window.showToast === 'function') window.showToast(n + ' meter masuk keranjang!', 'success');
      };
      document.getElementById('pfaAiPrevAddMore').onclick = function () {
        commitCurrent();
        if (bsM) bsM.hide();
        setTimeout(function () {
          var fi = document.getElementById('pfa217AiDusFile');
          if (fi) fi.click();
        }, 250);
      };
      if (bsM) bsM.show();
    }

    // Foto Label Dus (AI Vision) — Otomatis Kompres + Kontras + Pratinjau Edit
    document.getElementById('pfa217AiDusFile').addEventListener('change', function (ev) {
      var file = ev.target && ev.target.files && ev.target.files[0];
      if (!file) return;
      if (typeof window.showToast === 'function') window.showToast('Mengompres foto & membaca label dus dengan AI...', 'info');
      compressImageForAiOrUpload(file, 1600, 0.82, true).then(function (compressedDataUrl) {
        return window.callApi({ action: 'admin_scan_dus_ai', imageBase64: compressedDataUrl, _timeoutMs: 60000 });
      }).then(function (r) {
        if (r && r.status === 'success' && Array.isArray(r.meters) && r.meters.length) {
          openAiDusPreviewModal(r.noDus || '-', r.meters);
        } else {
          if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'AI gagal membaca label dus. Coba foto lebih fokus.', 'danger');
        }
      }).catch(function (err) {
        if (typeof window.showToast === 'function') window.showToast('Gagal baca AI: ' + (err.message || err), 'danger');
      });
      ev.target.value = '';
    });

    // Tambah manual
    document.getElementById('pfa217AddManualBtn').onclick = function () {
      var m = document.getElementById('pfa217ManualMeter').value.trim();
      var d = document.getElementById('pfa217ManualDus').value.trim() || '-';
      if (!m) return;
      addItemsToCart([m], d);
      document.getElementById('pfa217ManualMeter').value = '';
      renderCart();
    };

    // Kirim Drop ke Posko
    document.getElementById('pfa217SendDropBtn').onclick = function () {
      var posko = document.getElementById('pfa217PoskoSel').value;
      var catatan = document.getElementById('pfa217CatatanInp').value.trim();
      if (!DROP_CART.length) { if (typeof window.showToast === 'function') window.showToast('Keranjang nomor meter masih kosong.', 'warning'); return; }
      if (!posko) { if (typeof window.showToast === 'function') window.showToast('Pilih Posko / Regu tujuan terlebih dahulu.', 'warning'); return; }
      window.callApi({
        action: 'admin_buat_drop_posko',
        data: { posko: posko, items: DROP_CART, catatan: catatan }
      }).then(function (r) {
        if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Selesai.', r && r.status === 'success' ? 'success' : 'danger');
        if (r && r.status === 'success') {
          DROP_CART = [];
          renderCart();
          var ref = document.getElementById('pfaPkRefBtn215');
          if (ref) ref.click();
        }
      });
    };

    // Retur
    document.getElementById('pfa217ReturScanBtn').onclick = function () {
      if (typeof window.openBarcodeScanner === 'function') window.openBarcodeScanner('pfa217ReturMeter');
    };
    document.getElementById('pfa217ReturSaveBtn').onclick = function () {
      var nm = document.getElementById('pfa217ReturMeter').value.trim();
      var al = document.getElementById('pfa217ReturAlasan').value;
      if (!nm) return;
      window.callApi({ action: 'admin_simpan_mutasi_kwh_posko', data: { noMeter: nm, alasan: al } }).then(function (r) {
        if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Selesai.', r && r.status === 'success' ? 'success' : 'danger');
        if (r && r.status === 'success') {
          document.getElementById('pfa217ReturMeter').value = '';
          var ref = document.getElementById('pfaPkRefBtn215');
          if (ref) ref.click();
        }
      });
    };
  }

  // --------------------------------------------------------------------------
  // B. SISI PETUGAS YANTEK: LENCANA PORTAL + MODAL TERIMA KWH METER (FOTO + TTD + PDF)
  // --------------------------------------------------------------------------
  function openPoskoTerimaModal(kirimanData) {
    var mid = 'pfaPoskoTerimaModal';
    var old = document.getElementById(mid);
    if (old) old.remove();

    var items = (kirimanData && kirimanData.items) || [];
    var posko = (kirimanData && kirimanData.posko) || '-';

    var listHtml = !items.length
      ? '<div class="text-muted text-center py-3 small">Belum ada kiriman kWh meter untuk POSKO ' + esc(posko) + '.</div>'
      : items.map(function (it, idx) {
          var badge = it.status === 'DITERIMA' ? 'text-bg-success'
            : (it.status === 'MENUNGGU TERIMA' ? 'text-bg-warning' : 'text-bg-danger');
          var meterPreview = (it.meters || []).map(function (m) { return esc(m.noMeter || m); }).join(', ');
          var bodyExtra = '';
          if (it.status === 'MENUNGGU TERIMA') {
            bodyExtra =
              '<div class="mt-2 pt-2 border-top">' +
                '<div class="small fw-bold mb-1">1. Foto Fisik Serah Terima (Wajib)</div>' +
                '<input type="file" accept="image/*" capture="environment" class="form-control form-control-sm mb-2" id="pfaTrFoto_' + idx + '">' +
                '<div class="small fw-bold mb-1">2. Tanda Tangan Penerima (Wajib)</div>' +
                '<canvas id="pfaTrCanvas_' + idx + '" width="300" height="110" style="border:1.5px dashed #00a2e9;border-radius:10px;background:#ffffff;touch-action:none;width:100%;height:110px;"></canvas>' +
                '<div class="d-flex justify-content-end mb-2"><button type="button" class="btn btn-link btn-sm p-0 text-muted" style="font-size:0.7rem;" data-clr-sig="' + idx + '">Hapus TTD</button></div>' +
                '<div class="d-flex gap-2">' +
                  '<button type="button" class="btn btn-success btn-sm flex-fill fw-bold" data-acc-idx="' + idx + '" data-ba="' + esc(it.noBa) + '">Konfirmasi Terima</button>' +
                  '<button type="button" class="btn btn-outline-danger btn-sm fw-semibold" data-rej-ba="' + esc(it.noBa) + '">Tolak / Selisih</button>' +
                '</div>' +
              '</div>';
          } else if (it.status === 'DITERIMA' && it.pdfUrl) {
            bodyExtra =
              '<div class="mt-2">' +
                '<a href="' + esc(it.pdfUrl) + '" target="_blank" class="btn btn-primary btn-sm w-100 fw-semibold"><i class="bi bi-file-earmark-pdf-fill me-1"></i>Buka Surat Jalan PDF</a>' +
              '</div>';
          }
          return (
            '<div class="p-3 border rounded-4 mb-2">' +
              '<div class="d-flex justify-content-between align-items-center mb-1">' +
                '<strong class="small">' + esc(it.noBa) + '</strong>' +
                '<span class="badge ' + badge + ' rounded-pill" style="font-size:0.65rem;">' + esc(it.status) + '</span>' +
              '</div>' +
              '<div class="small text-muted mb-1">' + it.jumlah + ' unit • Dus: ' + esc(it.daftarDus) + ' • Drop: ' + esc(it.waktuDrop) + '</div>' +
              '<div class="p-2 rounded-3 bg-light small" style="font-family:monospace;font-size:0.7rem;max-height:70px;overflow-y:auto;">' + meterPreview + '</div>' +
              bodyExtra +
            '</div>'
          );
        }).join('');

    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="' + mid + '" tabindex="-1" aria-hidden="true">' +
        '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
          '<div class="modal-content rounded-4 border-0 shadow">' +
            '<div class="modal-header border-0 pb-1">' +
              '<h6 class="modal-title fw-bold"><i class="bi bi-box2-heart-fill me-2 text-primary"></i>kWh Meter POSKO ' + esc(posko) + '</h6>' +
              '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
            '</div>' +
            '<div class="modal-body pt-2">' + listHtml + '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(wrap.firstElementChild);
    var modalEl = document.getElementById(mid);

    // Init signature pads
    var sigHasInk = {};
    items.forEach(function (it, idx) {
      if (it.status !== 'MENUNGGU TERIMA') return;
      var cvs = document.getElementById('pfaTrCanvas_' + idx);
      if (!cvs) return;
      var ctx = cvs.getContext('2d');
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.2;
      ctx.lineCap = 'round';
      var drawing = false;
      function getPt(e) {
        var r = cvs.getBoundingClientRect();
        var t = e.touches ? e.touches[0] : e;
        return { x: (t.clientX - r.left) * (cvs.width / r.width), y: (t.clientY - r.top) * (cvs.height / r.height) };
      }
      function start(e) { drawing = true; sigHasInk[idx] = true; var p = getPt(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); }
      function move(e) { if (!drawing) return; e.preventDefault(); var p = getPt(e); ctx.lineTo(p.x, p.y); ctx.stroke(); }
      function end() { drawing = false; }
      cvs.addEventListener('mousedown', start); cvs.addEventListener('mousemove', move); window.addEventListener('mouseup', end);
      cvs.addEventListener('touchstart', start, { passive: false }); cvs.addEventListener('touchmove', move, { passive: false }); cvs.addEventListener('touchend', end);
    });

    modalEl.querySelectorAll('[data-clr-sig]').forEach(function (b) {
      b.onclick = function () {
        var idx = b.getAttribute('data-clr-sig');
        var cvs = document.getElementById('pfaTrCanvas_' + idx);
        if (cvs) { cvs.getContext('2d').clearRect(0, 0, cvs.width, cvs.height); sigHasInk[idx] = false; }
      };
    });

    modalEl.querySelectorAll('[data-acc-idx]').forEach(function (b) {
      b.onclick = function () {
        var idx = b.getAttribute('data-acc-idx');
        var ba = b.getAttribute('data-ba');
        var fInp = document.getElementById('pfaTrFoto_' + idx);
        var cvs = document.getElementById('pfaTrCanvas_' + idx);
        if (!fInp || !fInp.files || !fInp.files[0]) {
          if (typeof window.showToast === 'function') window.showToast('Foto fisik serah terima WAJIB diunggah.', 'warning');
          return;
        }
        if (!sigHasInk[idx]) {
          if (typeof window.showToast === 'function') window.showToast('Tanda tangan digital WAJIB diisi.', 'warning');
          return;
        }
        b.disabled = true;
        b.textContent = 'Memproses & Cetak PDF...';
        (function (fileObj) {
          var rdr = new FileReader();
          rdr.onload = function (e) {
            var im = new Image();
            im.onload = function () {
              var mw = 1280;
              var rt = im.width > mw ? (mw / im.width) : 1;
              var c2 = document.createElement('canvas');
              c2.width = Math.round(im.width * rt);
              c2.height = Math.round(im.height * rt);
              c2.getContext('2d').drawImage(im, 0, 0, c2.width, c2.height);
              var compressedFoto = c2.toDataURL('image/jpeg', 0.78);
              var ttdData = cvs.toDataURL('image/png');
              window.callApi({
                action: 'posko_konfirmasi_terima',
                noBa: ba,
                fotoBase64: compressedFoto,
                ttdBase64: ttdData
              }).then(function (r) {
            if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Selesai.', r && r.status === 'success' ? 'success' : 'danger');
            if (r && r.status === 'success') {
              if (window.bootstrap && window.bootstrap.Modal) window.bootstrap.Modal.getOrCreateInstance(modalEl).hide();
              if (r.pdfUrl) window.open(r.pdfUrl, '_blank');
              checkPoskoIncomingBanner();
            } else {
              b.disabled = false;
              b.textContent = 'Konfirmasi Terima';
            }
          }).catch(function (err) {
            b.disabled = false;
            b.textContent = 'Konfirmasi Terima';
            if (typeof window.showToast === 'function') window.showToast('Gagal konfirmasi: ' + (err.message || err), 'danger');
          });
            };
            im.src = e.target.result;
          };
          rdr.readAsDataURL(fileObj);
        })(fInp.files[0]);
      };
    });

    modalEl.querySelectorAll('[data-rej-ba]').forEach(function (b) {
      b.onclick = function () {
        var ba = b.getAttribute('data-rej-ba');
        var alasan = window.prompt('Masukkan alasan penolakan / selisih fisik untuk ' + ba + ':');
        if (!alasan || !alasan.trim()) return;
        window.callApi({ action: 'posko_tolak_drop', noBa: ba, alasan: alasan.trim() }).then(function (r) {
          if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Selesai.', r && r.status === 'success' ? 'warning' : 'danger');
          if (window.bootstrap && window.bootstrap.Modal) window.bootstrap.Modal.getOrCreateInstance(modalEl).hide();
          checkPoskoIncomingBanner();
        });
      };
    });

    if (window.bootstrap && window.bootstrap.Modal) window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
  }

  function getSessionUserV218() {
    try {
      var raw = localStorage.getItem('pfa_session_v1');
      if (!raw) return null;
      var p = JSON.parse(raw);
      return p && p.user ? p.user : p;
    } catch (e) { return null; }
  }

  function checkPoskoIncomingBanner() {
    if (navigator.onLine === false || typeof window.callApi !== 'function') return;
    var u = getSessionUserV218();
    if (!u) return;
    window.callApi({
      action: 'posko_get_kiriman',
      username: u.username || '',
      petugasNama: u.nama || '',
      userRole: u.role || ''
    }).then(function (res) {
      if (!res || res.status !== 'success' || !res.posko) return;
      var portal = document.getElementById('tab-portal');
      if (!portal) return;
      var old = document.getElementById('pfaPoskoIncomingBanner');
      if (old) old.remove();

      var b = document.createElement('div');
      b.id = 'pfaPoskoIncomingBanner';
      b.className = 'pfa-dil-summary-card mb-3';
      b.style.cursor = 'pointer';
      b.innerHTML =
        '<div class="pfa-dil-summary-top">' +
          '<div class="min-w-0">' +
            '<div class="pfa-dil-name"><i class="bi bi-box-seam-fill me-1 text-primary"></i>kWh Meter POSKO ' + esc(res.posko) + '</div>' +
            '<div class="pfa-dil-meta">' +
              (res.pendingCount > 0
                ? ('<strong class="text-danger">' + res.pendingCount + ' kiriman menunggu foto &amp; TTD terima!</strong>')
                : 'Lihat riwayat &amp; Surat Jalan PDF serah terima posko') +
            '</div>' +
          '</div>' +
          '<span class="badge ' + (res.pendingCount > 0 ? 'text-bg-danger' : 'text-bg-primary') + ' rounded-pill px-2 py-1">' +
            (res.pendingCount > 0 ? (res.pendingCount + ' Masuk') : 'Buka') +
          '</span>' +
        '</div>';
      b.onclick = function () { openPoskoTerimaModal(res); };

      var qs = portal.querySelector('.pfa-quick-search-wrap');
      if (qs && qs.nextSibling) portal.insertBefore(b, qs.nextSibling);
      else portal.insertBefore(b, portal.firstChild);
    }).catch(function () {});
  }

  // Hook login & switchTab('portal') agar kartu Terima kWh Posko selalu muncul di akun Petugas!
  function hookPoskoBannerTriggers() {
    if (typeof window.callApi === 'function' && !window._pfaV218LoginHooked) {
      window._pfaV218LoginHooked = true;
      var orig = window.callApi;
      window.callApi = async function (payload) {
        var r = await orig(payload);
        if (payload && payload.action === 'login' && r && r.status === 'success') {
          setTimeout(checkPoskoIncomingBanner, 650);
          setTimeout(upgradeAdminPoskoV217, 800);
        }
        return r;
      };
    }
    if (typeof window.switchTab === 'function' && !window._pfaV218TabHooked) {
      window._pfaV218TabHooked = true;
      var origSw = window.switchTab;
      window.switchTab = function (t) {
        var r = origSw.apply(this, arguments);
        if (t === 'portal') setTimeout(checkPoskoIncomingBanner, 250);
        return r;
      };
    }
  }

  window.addEventListener('load', function () {
    hookPoskoBannerTriggers();
    setTimeout(upgradeAdminPoskoV217, 1050);
    setTimeout(checkPoskoIncomingBanner, 1400);
  });
})();

/* ==========================================================================
   PFA v2.0.24 — LACAK CEPAT NO. METER / NO. DUS DI DASHBOARD ADMIN
   ========================================================================== */
(function () {
  'use strict';
  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function injectAdminMeterDusSearch() {
    var panel = document.getElementById('admSubTab-posko');
    if (!panel || document.getElementById('pfa219SearchCard')) return;
    var card = document.createElement('div');
    card.id = 'pfa219SearchCard';
    card.className = 'card card-modern mb-3';
    card.innerHTML =
      '<div class="card-body p-3">' +
        '<div class="section-title">Lacak Cepat No. Meter / No. Dus</div>' +
        '<div class="input-group input-group-sm mb-2">' +
          '<input type="text" id="pfa219SearchInp" class="form-control" placeholder="Ketik / scan No. Meter atau No. Dus...">' +
          '<button type="button" id="pfa219SearchScan" class="btn pfa-kct-scan-btn"><i class="bi bi-qr-code-scan"></i></button>' +
          '<button type="button" id="pfa219SearchGo" class="btn btn-primary fw-bold">Cari</button>' +
        '</div>' +
        '<div id="pfa219SearchRes" class="small"></div>' +
      '</div>';
    var firstCard = panel.querySelector('.card.card-modern');
    if (firstCard && firstCard.nextSibling) panel.insertBefore(card, firstCard.nextSibling);
    else panel.appendChild(card);

    function runSearch() {
      var kw = document.getElementById('pfa219SearchInp').value.trim();
      var resBox = document.getElementById('pfa219SearchRes');
      if (!kw) return;
      resBox.innerHTML = '<div class="text-muted text-center py-2">Mencari di STOCK KWH METER &amp; Rekap_Gangguan...</div>';
      window.callApi({ action: 'admin_cari_meter_atau_dus', keyword: kw }).then(function (r) {
        if (!r || r.status !== 'success') {
          resBox.innerHTML = '<div class="alert alert-warning py-2 mb-0">' + esc((r && r.message) || 'Gagal mencari.') + '</div>';
          return;
        }
        var items = r.items || [];
        if (!items.length) {
          resBox.innerHTML = '<div class="text-muted text-center py-2">Tidak ditemukan di STOCK KWH METER.</div>';
          return;
        }
        resBox.innerHTML = items.map(function (it) {
          var cls = it.status === 'TERSEDIA' ? 'text-bg-success' : (it.status === 'TERPAKAI' ? 'text-bg-primary' : 'text-bg-warning');
          return (
            '<div class="p-2 border rounded-3 mb-1">' +
              '<div class="d-flex justify-content-between align-items-center">' +
                '<strong style="font-family:monospace;">' + esc(it.noMeter) + '</strong>' +
                '<span class="badge ' + cls + ' rounded-pill" style="font-size:0.64rem;">' + esc(it.status) + '</span>' +
              '</div>' +
              '<div class="text-muted" style="font-size:0.7rem;">Posko: <strong>' + esc(it.posko) + '</strong> • Dus: ' + esc(it.noDus) + ' • Ambil: ' + esc(it.tglAmbil) + '</div>' +
              (it.status !== 'TERSEDIA' ? ('<div style="font-size:0.7rem;">' + esc(it.detail) + '</div>') : '') +
            '</div>'
          );
        }).join('');
      });
    }

    document.getElementById('pfa219SearchGo').onclick = runSearch;
    document.getElementById('pfa219SearchInp').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); runSearch(); }
    });
    document.getElementById('pfa219SearchScan').onclick = function () {
      if (typeof window.openBarcodeScanner === 'function') window.openBarcodeScanner('pfa219SearchInp');
    };
  }
  window.addEventListener('load', function () {
    setTimeout(injectAdminMeterDusSearch, 1200);
  });
})();

/* ==========================================================================
   PFA v2.0.24 — GLOBAL LOADING OVERLAY, HYBRID SUPABASE (<0.3s + FALLBACK),
                 & ADMIN CSV BATCH UPSERT (238.000+ BARIS)
   Pengembang: JODI SETIAWAN — PLN ULP Pelabuhan Ratu
   ========================================================================== */
(function () {
  'use strict';

  var SUPA_CFG_KEY = 'pfa_supabase_cfg_v1';
  var LOADING_MESSAGES = {
    admin_scan_dus_ai: 'Mengompres foto & membaca label dus dengan AI...',
    admin_buat_drop_posko: 'Mengirim drop kWh meter ke Posko...',
    admin_batal_drop_posko: 'Membatalkan kiriman drop Posko...',
    admin_simpan_mutasi_kwh_posko: 'Menyimpan data retur ke STOCK KWH METER...',
    posko_konfirmasi_terima: 'Mengunggah foto & TTD, lalu mencetak Surat Jalan PDF...',
    posko_tolak_drop: 'Mengirim laporan selisih ke Admin...',
    admin_cari_meter_atau_dus: 'Melacak nomor meter / dus...'
  };

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // --------------------------------------------------------------------------
  // 1. GLOBAL ACTION LOADING OVERLAY (untuk AI Dus, Drop, Terima PDF, Lacak)
  // --------------------------------------------------------------------------
  function showActionLoader(msg) {
    var el = document.getElementById('pfaV220ActionLoader');
    if (!el) {
      el = document.createElement('div');
      el.id = 'pfaV220ActionLoader';
      el.className = 'pfa-action-loader';
      el.innerHTML =
        '<div class="pfa-action-loader-card">' +
          '<div class="spinner-border text-primary mb-2" role="status" style="width:2.1rem;height:2.1rem;"></div>' +
          '<div class="fw-bold small" id="pfaV220LoaderMsg">Memproses...</div>' +
        '</div>';
      document.body.appendChild(el);
    }
    var msgEl = document.getElementById('pfaV220LoaderMsg');
    if (msgEl) msgEl.textContent = msg || 'Memproses...';
    el.classList.remove('d-none');
  }

  function hideActionLoader() {
    var el = document.getElementById('pfaV220ActionLoader');
    if (el) el.classList.add('d-none');
  }

  // --------------------------------------------------------------------------
  // 2. HYBRID SUPABASE FAST READ (<0.3s) + AUTO-FALLBACK KE GOOGLE SHEETS
  // --------------------------------------------------------------------------
  function getSupaCfg() {
    try {
      var raw = localStorage.getItem(SUPA_CFG_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }

  function refreshSupaCfgFromGas() {
    if (navigator.onLine === false || typeof window.callApi !== 'function') return;
    window.callApi({ action: 'get_supabase_config' }).then(function (r) {
      if (r && r.status === 'success' && r.enabled && r.url && r.anonKey) {
        try { localStorage.setItem(SUPA_CFG_KEY, JSON.stringify({ url: r.url, anonKey: r.anonKey })); } catch (e) {}
      }
    }).catch(function () {});
  }

  async function querySupabaseDilFast(keyword) {
    if (navigator.onLine === false) return null;
    var cfg = getSupaCfg();
    if ((!cfg || !cfg.url || !cfg.anonKey) && typeof window._pfaOrigCallApiForCfg === 'function') {
      try {
        var rCfg = await window._pfaOrigCallApiForCfg({ action: 'get_supabase_config' });
        if (rCfg && rCfg.status === 'success' && rCfg.enabled && rCfg.url && rCfg.anonKey) {
          cfg = { url: rCfg.url, anonKey: rCfg.anonKey };
          try { localStorage.setItem(SUPA_CFG_KEY, JSON.stringify(cfg)); } catch (eC) {}
        }
      } catch (eG) {}
    }
    if (!cfg || !cfg.url || !cfg.anonKey) {
      window._pfaLastSupaDiag = 'Config Supabase di HP kosong (cek Script Properties GAS)';
      return null;
    }
    var cleanKey = String(keyword || '').trim();
    if (!cleanKey) return null;

    var t0 = Date.now();
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 4500) : null;
    try {
      var enc = encodeURIComponent(cleanKey);
      var url = cfg.url.replace(/\/+$/, '') + '/rest/v1/master_dil?or=(id_pelanggan.eq.' + enc + ',no_meter_lama.eq.' + enc + ')&limit=1';
      var resp = await fetch(url, {
        method: 'GET',
        headers: (String(cfg.anonKey || '').indexOf('eyJ') === 0 ? { apikey: cfg.anonKey, Authorization: 'Bearer ' + cfg.anonKey } : { apikey: cfg.anonKey }),
        signal: ctrl ? ctrl.signal : undefined
      });
      if (timer) clearTimeout(timer);
      if (!resp.ok) {
        var errTxt = '';
        try { errTxt = await resp.text(); } catch (eT) {}
        window._pfaLastSupaDiag = 'Supabase HTTP ' + resp.status + ': ' + errTxt.slice(0, 80);
        return null;
      }
      var rows = await resp.json();
      if (Array.isArray(rows) && rows.length > 0) {
        var ms = Date.now() - t0;
        if (typeof window.showToast === 'function') {
          window.showToast('⚡ DIL ditemukan via Supabase (' + ms + ' ms)', 'success');
        }
        var r = rows[0];
        return {
          status: 'success',
          source: 'supabase_direct',
          data: {
            id_pelanggan: String(r.id_pelanggan || '').trim(),
            nama_pelanggan: String(r.nama_pelanggan || '').trim(),
            alamat: String(r.alamat || '').trim(),
            no_telepon: String(r.no_telepon || '').trim(),
            tarif: String(r.tarif || '').trim(),
            daya: String(r.daya || '').trim(),
            tipe_pengawatan: String(r.tipe_pengawatan || '').trim(),
            no_meter_lama: String(r.no_meter_lama || '').trim(),
            merk_meter: String(r.merk_meter || '').trim(),
            tipe_meter: String(r.tipe_meter || '').trim(),
            layanan: String(r.layanan || '').trim(),
            tahun_meter: String(r.tahun_meter || '').trim(),
            nama_gardu: String(r.nama_gardu || '').trim(),
            nomor_tiang: String(r.nomor_tiang || '').trim()
          }
        };
      }
    } catch (e) {
      if (timer) clearTimeout(timer);
    }
    return null;
  }

  async function querySupabaseKctFast(keyword, unitKey) {
    var cfg = getSupaCfg();
    if (!cfg || !cfg.url || !cfg.anonKey || navigator.onLine === false) return null;
    var cleanKey = String(keyword || '').trim();
    if (!cleanKey) return null;
    var unit = String(unitKey || 'SEMUA_ULP').trim();
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 4500) : null;
    try {
      var enc = encodeURIComponent(cleanKey);
      var unitFilter = (unit && unit !== 'SEMUA_ULP') ? ('unit_kode=eq.' + encodeURIComponent(unit) + '&') : '';
      var url = cfg.url.replace(/\/+$/, '') + '/rest/v1/master_kct?' + unitFilter +
        'or=(idpel.eq.' + enc + ',nomor_meter.eq.' + enc + ')&limit=1';
      var resp = await fetch(url, {
        method: 'GET',
        headers: (String(cfg.anonKey || '').indexOf('eyJ') === 0 ? { apikey: cfg.anonKey, Authorization: 'Bearer ' + cfg.anonKey } : { apikey: cfg.anonKey }),
        signal: ctrl ? ctrl.signal : undefined
      });
      if (timer) clearTimeout(timer);
      if (!resp.ok) return null;
      var rows = await resp.json();
      if (Array.isArray(rows) && rows.length > 0) {
        var row = rows[0];
        return {
          status: 'success',
          source: 'supabase_direct',
          data: {
            unit_kode: String(row.unit_kode || unit),
            unit_nama: String(row.unit_kode || unit).replace(/_/g, ' '),
            idpel: String(row.idpel || '').trim(),
            nama: String(row.nama || '').trim(),
            alamat: String(row.alamat || '').trim(),
            nomor_meter: String(row.nomor_meter || '').trim(),
            tarif_daya: String(row.tarif_daya || '').trim(),
            krn_vkrn: String(row.krn_vkrn || '').trim(),
            token_kct1a: String(row.token_kct1a || '').trim(),
            token_kct1b: String(row.token_kct1b || '').trim(),
            token_kct2a: String(row.token_kct2a || '').trim(),
            token_kct2b: String(row.token_kct2b || '').trim(),
            status_baca: String(row.status_baca || '').trim(),
            tgl_baca: String(row.tgl_baca || '').trim(),
            petugas_baca: String(row.petugas_baca || '').trim()
          }
        };
      }
    } catch (e) {
      if (timer) clearTimeout(timer);
    }
    return null;
  }

  function wrapCallApiV220() {
    if (typeof window.callApi !== 'function' || window._pfaV220Wrapped) return;
    window._pfaV220Wrapped = true;
    var orig = window.callApi;
    window._pfaOrigCallApiForCfg = orig;

    window.callApi = async function (payload) {
      var act = payload && payload.action ? String(payload.action).trim() : '';

      // 1. Direct Fast Read Supabase (<0.3s) + Auto-Fallback ke GAS/Sheets
      if (act === 'cari_pelanggan' && payload.keyword) {
        window._pfaLastSupaDiag = '';
        var fastDil = await querySupabaseDilFast(payload.keyword);
        if (fastDil) return fastDil;
        if (typeof window.showToast === 'function') {
          window.showToast('Fallback ke Sheets (' + (window._pfaLastSupaDiag || 'Data tidak ada di master_dil Supabase') + ')', 'info');
        }
      } else if (act === 'cek_kct' && payload.keyword) {
        var fastKct = await querySupabaseKctFast(payload.keyword, payload.unit);
        if (fastKct) return fastKct;
      }

      // 2. Global Loading Overlay untuk aksi berat Posko / AI Dus
      var loadMsg = LOADING_MESSAGES[act];
      if (loadMsg) showActionLoader(loadMsg);
      try {
        var res = await orig(payload);
        if (act === 'login' && res && res.status === 'success') {
          setTimeout(refreshSupaCfgFromGas, 400);
        }
        return res;
      } finally {
        if (loadMsg) hideActionLoader();
      }
    };
  }

  // --------------------------------------------------------------------------
  // 3. BACKOFFICE ADMIN: UPLOAD CSV BATCH UPSERT DIL & KCT (238.000+ BARIS)
  // --------------------------------------------------------------------------
  function parseCsvLine(line, delim) {
    var out = [];
    var cur = '';
    var inQ = false;
    for (var i = 0; i < line.length; i++) {
      var ch = line[i];
      if (ch === '"') {
        if (inQ && line[i + 1] === '"') { cur += '"'; i++; }
        else inQ = !inQ;
      } else if (ch === delim && !inQ) {
        out.push(cur.trim());
        cur = '';
      } else {
        cur += ch;
      }
    }
    out.push(cur.trim());
    return out;
  }

  function normalizeHeaderName(h) {
    return String(h || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  }

  function mapRowForDil(headersNorm, cols) {
    var raw = {};
    for (var i = 0; i < headersNorm.length; i++) {
      raw[headersNorm[i]] = String(cols[i] || '').trim();
    }
    var idpel = raw.idpelanggan || raw.idpel || '';
    if (!idpel) return null;
    return {
      id_pelanggan: idpel,
      nama_pelanggan: raw.namapelanggan || raw.nama || '',
      alamat: raw.alamat || '',
      no_telepon: raw.notelepon || raw.telepon || raw.nohp || raw.hp || '',
      tarif: raw.tarif || '',
      daya: raw.daya || '',
      tipe_pengawatan: raw.tipepengawatan || raw.pengawatan || '',
      no_meter_lama: raw.nometerlama || raw.nometer || raw.nomormeterkwh || raw.nomormeter || '',
      merk_meter: raw.merkmeter || raw.merk || '',
      tipe_meter: raw.tipemeter || '',
      layanan: raw.layanan || '',
      tahun_meter: raw.tahunmeter || raw.tahun || '',
      nama_gardu: raw.namagardu || raw.gardu || '',
      nomor_tiang: raw.nomortiang || raw.tiang || ''
    };
  }

  function mapRowForKct(headersNorm, cols, defaultUnit) {
    var raw = {};
    for (var i = 0; i < headersNorm.length; i++) {
      raw[headersNorm[i]] = String(cols[i] || '').trim();
    }
    var idpel = raw.idpel || raw.idpelanggan || '';
    if (!idpel) return null;
    return {
      unit_kode: raw.unitkode || defaultUnit || 'PELABUHAN_RATU',
      idpel: idpel,
      nama: raw.nama || raw.namapelanggan || '',
      alamat: raw.alamat || '',
      nomor_meter: raw.nomormeter || raw.nometer || raw.nometerlama || '',
      tarif_daya: raw.tarifdaya || ([raw.tarif, raw.daya].filter(Boolean).join('/')) || '',
      krn_vkrn: raw.krnvkrn || raw.krn || '',
      token_kct1a: raw.tokenkct1a || raw.kct1a || '',
      token_kct1b: raw.tokenkct1b || raw.kct1b || '',
      token_kct2a: raw.tokenkct2a || raw.kct2a || '',
      token_kct2b: raw.tokenkct2b || raw.kct2b || '',
      status_baca: raw.statusbaca || raw.status || '',
      tgl_baca: raw.tglbaca || raw.tanggalbaca || '',
      petugas_baca: raw.petugasbaca || raw.petugas || ''
    };
  }

  function injectAdminSupabaseUploadTab() {
    var admTab = document.getElementById('tab-admin');
    if (!admTab || document.getElementById('subnav-adm-supa')) return;
    var navWrap = admTab.querySelector('#subnav-adm-gangguan') && admTab.querySelector('#subnav-adm-gangguan').parentElement;
    if (!navWrap) return;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'subnav-adm-supa';
    btn.className = 'adm-nav-tile';
    btn.innerHTML = '<i class="bi bi-database-fill-up text-info"></i><span>DIL / KCT</span>';
    navWrap.appendChild(btn);

    var panel = document.createElement('div');
    panel.id = 'admSubTab-supa';
    panel.className = 'adm-subtab d-none';
    panel.innerHTML =
      '<div class="card card-modern mb-3"><div class="card-body p-3">' +
        '<div class="section-title">Update Database DIL / KCT (Supabase Mode Upsert)</div>' +
        '<p class="small text-muted mb-3">Unggah file <strong>CSV (UTF-8)</strong> dari Excel. Pelanggan lama yang berubah nama/no. meter otomatis diperbarui, dan pelanggan baru otomatis ditambahkan.</p>' +
        '<div class="row g-2 mb-2">' +
          '<div class="col-6">' +
            '<label class="form-label small fw-bold">Target Database</label>' +
            '<select id="pfaSupaTargetSel" class="form-select form-select-sm">' +
              '<option value="master_dil">Master DIL (Pelanggan)</option>' +
              '<option value="master_kct">Master KCT (Gabungan Semua ULP)</option>' +
              '<option value="stock_kwh_meter">Stok kWh Meter Posko</option>' +
              '<option value="knowledge_base_ai">Knowledge Base AI</option>' +
            '</select>' +
          '</div>' +
          '<div class="col-6 d-none" id="pfaSupaUnitWrap">' +
            '<label class="form-label small fw-bold">Unit KCT</label>' +
            '<select id="pfaSupaUnitSel" class="form-select form-select-sm">' +
              '<option value="SEMUA_ULP">Semua ULP (Gabungan)</option>' +
              '<option value="PELABUHAN_RATU">ULP Pelabuhan Ratu</option>' +
              '<option value="SUKABUMI_KOTA">ULP Sukabumi Kota</option>' +
              '<option value="CIKEMBAR">ULP Cikembar</option>' +
              '<option value="CICURUG">ULP Cicurug</option>' +
              '<option value="CIBADAK">ULP Cibadak</option>' +
              '<option value="SUKARAJA">ULP Sukaraja</option>' +
            '</select>' +
          '</div>' +
        '</div>' +
        '<div class="mb-3">' +
          '<label class="form-label small fw-bold">Pilih File CSV (.csv)</label>' +
          '<input type="file" id="pfaSupaCsvInput" accept=".csv,text/csv" class="form-control form-control-sm">' +
        '</div>' +
        '<div id="pfaSupaProgressWrap" class="d-none mb-3">' +
          '<div class="d-flex justify-content-between small fw-bold mb-1">' +
            '<span id="pfaSupaProgText">Menyiapkan data...</span>' +
            '<span id="pfaSupaProgPct">0%</span>' +
          '</div>' +
          '<div class="progress" style="height:10px;border-radius:999px;">' +
            '<div id="pfaSupaProgBar" class="progress-bar progress-bar-striped progress-bar-animated bg-primary" style="width:0%"></div>' +
          '</div>' +
        '</div>' +
        '<div class="d-flex gap-2">' +
          '<button type="button" id="pfaSupaStartBtn" class="btn btn-primary btn-sm flex-fill fw-bold py-2"><i class="bi bi-cloud-upload-fill me-1"></i>Mulai Upload &amp; Upsert</button>' +
          '<button type="button" id="pfaSupaStopBtn" class="btn btn-outline-danger btn-sm fw-semibold d-none">Hentikan</button>' +
        '</div>' +
        '<div id="pfaSupaLog" class="small text-muted mt-2"></div>' +
        '<hr class="my-3">' +
        '<div class="small fw-bold mb-2">Sinkronisasi 1-Klik dari Google Sheets → Supabase</div>' +
        '<div class="d-flex gap-2 flex-wrap">' +
          '<button type="button" id="pfaSyncStockBtn" class="btn btn-outline-primary btn-sm flex-fill fw-semibold"><i class="bi bi-arrow-repeat me-1"></i>Sinkron STOCK KWH METER</button>' +
          '<button type="button" id="pfaSyncKbBtn" class="btn btn-outline-success btn-sm flex-fill fw-semibold"><i class="bi bi-arrow-repeat me-1"></i>Sinkron Knowledge Base AI</button>' +
        '</div>' +
      '</div></div>';

    admTab.appendChild(panel);

    btn.onclick = function () {
      admTab.querySelectorAll('.adm-subtab, [id^="adm-sub-"]').forEach(function (s) { s.classList.add('d-none'); });
      navWrap.querySelectorAll('button').forEach(function (b) {
        b.classList.remove('btn-primary');
        b.classList.add('btn-outline-secondary');
      });
      btn.classList.remove('btn-outline-secondary');
      btn.classList.add('btn-primary');
      panel.classList.remove('d-none');
    };

    if (typeof window.switchAdminSubTab === 'function' && !window._pfaAdmSupaHooked) {
      window._pfaAdmSupaHooked = true;
      var origSw = window.switchAdminSubTab;
      window.switchAdminSubTab = function () {
        panel.classList.add('d-none');
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-secondary');
        return origSw.apply(this, arguments);
      };
    }

    document.getElementById('pfaSupaTargetSel').onchange = function () {
      document.getElementById('pfaSupaUnitWrap').classList.toggle('d-none', this.value !== 'master_kct');
    };

    var stopRequested = false;
    document.getElementById('pfaSupaStopBtn').onclick = function () { stopRequested = true; };

    
    function bindOneClickSync(btnId, tblName) {
      var b = document.getElementById(btnId);
      if (!b) return;
      b.onclick = function () {
        b.disabled = true;
        var origTxt = b.innerHTML;
        b.textContent = 'Menyinkronkan...';
        window.callApi({ action: 'admin_sync_sheets_to_supabase', tableName: tblName, _timeoutMs: 60000 }).then(function (r) {
          b.disabled = false;
          b.innerHTML = origTxt;
          if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Selesai.', r && r.status === 'success' ? 'success' : 'danger');
        }).catch(function (err) {
          b.disabled = false;
          b.innerHTML = origTxt;
          if (typeof window.showToast === 'function') window.showToast('Gagal sinkron: ' + (err.message || err), 'danger');
        });
      };
    }
    bindOneClickSync('pfaSyncStockBtn', 'stock_kwh_meter');
    bindOneClickSync('pfaSyncKbBtn', 'knowledge_base_ai');

    document.getElementById('pfaSupaStartBtn').onclick = async function () {
      var fi = document.getElementById('pfaSupaCsvInput');
      var file = fi && fi.files && fi.files[0];
      if (!file) {
        if (typeof window.showToast === 'function') window.showToast('Pilih file CSV terlebih dahulu.', 'warning');
        return;
      }
      var target = document.getElementById('pfaSupaTargetSel').value;
      var unitKct = document.getElementById('pfaSupaUnitSel').value;
      var progWrap = document.getElementById('pfaSupaProgressWrap');
      var progText = document.getElementById('pfaSupaProgText');
      var progPct = document.getElementById('pfaSupaProgPct');
      var progBar = document.getElementById('pfaSupaProgBar');
      var logEl = document.getElementById('pfaSupaLog');
      var startBtn = document.getElementById('pfaSupaStartBtn');
      var stopBtn = document.getElementById('pfaSupaStopBtn');

      stopRequested = false;
      startBtn.disabled = true;
      stopBtn.classList.remove('d-none');
      progWrap.classList.remove('d-none');
      progText.textContent = 'Membaca file CSV...';
      progBar.style.width = '0%';
      progPct.textContent = '0%';

      try {
        var text = await file.text();
        var lines = text.split(/\r?\n/).filter(function (l) { return l.trim().length > 0; });
        if (lines.length < 2) throw new Error('File CSV kosong atau tidak memiliki data.');

        var firstLine = lines[0];
        var delim = (firstLine.split(';').length > firstLine.split(',').length) ? ';' : ',';
        var headersNorm = parseCsvLine(firstLine, delim).map(normalizeHeaderName);

        var rowsMap = {};
        for (var i = 1; i < lines.length; i++) {
          var cols = parseCsvLine(lines[i], delim);
          var obj = null;
          if (target === 'master_dil') obj = mapRowForDil(headersNorm, cols);
          else if (target === 'master_kct') obj = mapRowForKct(headersNorm, cols, unitKct);
          else if (target === 'stock_kwh_meter') {
            var rMap = {};
            for (var hi = 0; hi < headersNorm.length; hi++) rMap[headersNorm[hi]] = String(cols[hi] || '').trim();
            var nm = String(rMap.nometer || rMap.nomormeter || '').replace(/[^0-9A-Za-z]/g, '').toUpperCase();
            var pk = String(rMap.posko || '').trim().toUpperCase();
            if (nm && pk) obj = { no_dus: rMap.nodus || '-', no_meter: nm, posko: pk, tanggal_pengambilan: rMap.tanggalpengambilan || '', status: rMap.status || '' };
          } else if (target === 'knowledge_base_ai') {
            var kMap = {};
            for (var kj = 0; kj < headersNorm.length; kj++) kMap[headersNorm[kj]] = String(cols[kj] || '').trim();
            if (kMap.idkb && kMap.judul) obj = { id_kb: kMap.idkb, tanggal: kMap.tanggal || '', kategori: kMap.kategori || '', judul: kMap.judul, ringkasan_teknis: kMap.ringkasanteknis || '', kata_kunci: kMap.katakunci || '', sumber_url: kMap.sumberurl || '', status: kMap.status || 'APPROVED', metode_riset: kMap.metoderiset || 'MANUAL' };
          }
          if (!obj) continue;
          var conflictKey = target === 'master_dil' ? obj.id_pelanggan : (target === 'master_kct' ? obj.idpel : (target === 'stock_kwh_meter' ? obj.no_meter : obj.id_kb));
          rowsMap[conflictKey] = obj;
        }
        var allRows = Object.keys(rowsMap).map(function (k) { return rowsMap[k]; });
        if (!allRows.length) throw new Error('Kolom id_pelanggan / idpel tidak ditemukan pada header CSV.');

        var BATCH_SIZE = 1500;
        var uploaded = 0;
        for (var start = 0; start < allRows.length; start += BATCH_SIZE) {
          if (stopRequested) {
            logEl.innerHTML = '<span class="text-warning">Dihentikan oleh Admin di baris ke-' + uploaded + '.</span>';
            break;
          }
          var chunk = allRows.slice(start, start + BATCH_SIZE);
          var res = await window.callApi({
            action: 'admin_upsert_supabase_batch',
            tableName: target,
            rows: chunk,
            _timeoutMs: 60000
          });
          if (!res || res.status !== 'success') {
            throw new Error((res && res.message) || 'Gagal mengirim batch ke Supabase.');
          }
          uploaded += chunk.length;
          var pct = Math.round((uploaded / allRows.length) * 100);
          progText.textContent = 'Mengunggah ' + uploaded.toLocaleString('id-ID') + ' / ' + allRows.length.toLocaleString('id-ID') + ' baris...';
          progPct.textContent = pct + '%';
          progBar.style.width = pct + '%';
        }
        if (!stopRequested) {
          logEl.innerHTML = '<span class="text-success fw-bold">Selesai! ' + uploaded.toLocaleString('id-ID') + ' baris berhasil di-upsert ke ' + target + '.</span>';
          if (typeof window.showToast === 'function') window.showToast('Update ' + target + ' selesai (' + uploaded + ' baris)!', 'success');
        }
      } catch (err) {
        logEl.innerHTML = '<span class="text-danger">Error: ' + esc(err.message || err) + '</span>';
      } finally {
        startBtn.disabled = false;
        stopBtn.classList.add('d-none');
      }
    };
  }

  window.addEventListener('load', function () {
    wrapCallApiV220();
    setTimeout(refreshSupaCfgFromGas, 900);
    setTimeout(injectAdminSupabaseUploadTab, 1250);
  });
})();

/* ==========================================================================
   PFA v2.0.24 — FILTER HARI INI & EKSPOR CSV REKAP ADMIN (GANGGUAN & UKUR)
   ========================================================================== */
(function () {
  'use strict';

  function exportContainerToCsv(containerId, filenamePrefix) {
    var box = document.getElementById(containerId);
    if (!box) return;
    var rows = [];
    var tbl = box.querySelector('table');
    if (tbl) {
      tbl.querySelectorAll('tr').forEach(function (tr) {
        if (tr.style.display === 'none') return;
        var cols = [];
        tr.querySelectorAll('th, td').forEach(function (c) {
          cols.push('"' + String(c.textContent || '').replace(/\s+/g, ' ').trim().replace(/"/g, '""') + '"');
        });
        if (cols.length) rows.push(cols.join(','));
      });
    } else {
      box.querySelectorAll('.card, .border.rounded-3').forEach(function (card) {
        if (card.style.display === 'none') return;
        var txt = String(card.textContent || '').replace(/\s+/g, ' ').trim().replace(/"/g, '""');
        if (txt) rows.push('"' + txt + '"');
      });
    }
    if (!rows.length) {
      if (typeof window.showToast === 'function') window.showToast('Belum ada data rekap untuk diekspor.', 'warning');
      return;
    }
    var blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filenamePrefix + '_' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    if (typeof window.showToast === 'function') window.showToast('File CSV berhasil diunduh!', 'success');
  }

  function injectAdminRekapQuickTools() {
    [
      { subId: 'adm-sub-gangguan', contId: 'adminRekapContainer', prefix: 'Rekap_Gangguan' },
      { subId: 'adm-sub-pengukuran', contId: 'adminRekapPengukuranContainer', prefix: 'Rekap_Pengukuran' }
    ].forEach(function (cfg) {
      var sub = document.getElementById(cfg.subId);
      var cont = document.getElementById(cfg.contId);
      if (!sub || !cont || sub.querySelector('[data-pfa-rekap-tools="' + cfg.subId + '"]')) return;

      var bar = document.createElement('div');
      bar.setAttribute('data-pfa-rekap-tools', cfg.subId);
      bar.className = 'd-flex gap-2 mb-2 flex-wrap';
      bar.innerHTML =
        '<button type="button" class="btn btn-sm btn-outline-primary fw-semibold" data-today-btn><i class="bi bi-calendar-check me-1"></i>Hari Ini</button>' +
        '<button type="button" class="btn btn-sm btn-outline-success fw-semibold" data-csv-btn><i class="bi bi-file-earmark-spreadsheet me-1"></i>Ekspor CSV</button>';
      cont.parentNode.insertBefore(bar, cont);

      var onlyToday = false;
      bar.querySelector('[data-today-btn]').onclick = function () {
        onlyToday = !onlyToday;
        this.classList.toggle('btn-primary', onlyToday);
        this.classList.toggle('btn-outline-primary', !onlyToday);
        var todayIso = new Date().toISOString().slice(0, 10);
        cont.querySelectorAll('.card, tr').forEach(function (el) {
          if (el.querySelector('th')) return;
          var txt = String(el.textContent || '');
          el.style.display = (!onlyToday || txt.indexOf(todayIso) !== -1) ? '' : 'none';
        });
      };

      bar.querySelector('[data-csv-btn]').onclick = function () {
        exportContainerToCsv(cfg.contId, cfg.prefix);
      };
    });
  }

  window.addEventListener('load', function () {
    setTimeout(injectAdminRekapQuickTools, 1100);
  });
})();


// ============================================================================
// PFA v2.0.25: Bridge Scanner QR Dual-Mode Material + Filter & Ekspor CSV Admin Material
// ============================================================================
(function () {
  window.pfaOpenBarcodeScanner = function (onScanned) {
    if (typeof window.openBarcodeScanner !== 'function') {
      var manual = prompt('Masukkan Kode Normalisasi / URL QR Rak:');
      if (manual && typeof onScanned === 'function') onScanned(manual);
      return;
    }
    var inp = document.getElementById('pfaMatQrBridgeInput');
    if (!inp) {
      inp = document.createElement('input');
      inp.type = 'hidden';
      inp.id = 'pfaMatQrBridgeInput';
      document.body.appendChild(inp);
    }
    inp.value = '';
    var fired = false;
    var handler = function () {
      if (fired) return;
      var val = String(inp.value || '').trim();
      if (!val) return;
      fired = true;
      inp.removeEventListener('input', handler);
      inp.removeEventListener('change', handler);
      if (typeof onScanned === 'function') onScanned(val);
    };
    inp.addEventListener('input', handler);
    inp.addEventListener('change', handler);
    window.openBarcodeScanner('pfaMatQrBridgeInput');
  };

  function injectAdminMaterialFilterCsv() {
    var sub = document.getElementById('adm-sub-material');
    if (!sub || sub.querySelector('[data-pfa-mat-adm-tools]')) return;
    var body = sub.querySelector('.card-body');
    if (!body) return;
    var bar = document.createElement('div');
    bar.setAttribute('data-pfa-mat-adm-tools', '1');
    bar.className = 'd-flex gap-2 mb-2 flex-wrap align-items-center';
    bar.innerHTML =
      '<input type="text" class="form-control form-control-sm" style="max-width:240px;" data-mat-adm-search placeholder="Filter tabel material / status / tujuan...">' +
      '<button type="button" class="btn btn-sm btn-outline-success fw-semibold" data-mat-adm-csv><i class="bi bi-file-earmark-spreadsheet me-1"></i>Ekspor CSV Material</button>';
    var firstChild = body.children[1] || body.firstChild;
    body.insertBefore(bar, firstChild);

    bar.querySelector('[data-mat-adm-search]').addEventListener('input', function () {
      var kw = String(this.value || '').trim().toLowerCase();
      sub.querySelectorAll('tbody tr').forEach(function (tr) {
        tr.style.display = (!kw || String(tr.textContent || '').toLowerCase().indexOf(kw) !== -1) ? '' : 'none';
      });
    });

    bar.querySelector('[data-mat-adm-csv]').addEventListener('click', function () {
      var tables = sub.querySelectorAll('table');
      var rows = [];
      tables.forEach(function (tbl) {
        tbl.querySelectorAll('tr').forEach(function (tr) {
          if (tr.style.display === 'none') return;
          var cols = Array.from(tr.querySelectorAll('th,td')).map(function (c) {
            return '"' + String(c.innerText || c.textContent || '').replace(/\s+/g, ' ').trim().replace(/"/g, '""') + '"';
          });
          if (cols.length) rows.push(cols.join(','));
        });
      });
      if (!rows.length) {
        if (typeof window.showToast === 'function') window.showToast('Muat data monitoring material terlebih dahulu.', 'warning');
        return;
      }
      var blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'Monitoring_Material_' + new Date().toISOString().slice(0, 10) + '.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
      if (typeof window.showToast === 'function') window.showToast('CSV Monitoring Material berhasil diunduh!', 'success');
    });
  }

  window.addEventListener('load', function () {
    setTimeout(injectAdminMaterialFilterCsv, 1200);
  });
})();


// ============================================================================
// PFA v2.0.26: Hapus Cache Basi Material + Direct Supabase Fast-Path (<0.2 detik)
// ============================================================================
(function () {
  try { localStorage.removeItem('pfa_ttl_cache_v1_get_master_material'); } catch (e) {}

  var MAT_GROUP_ORDER_226 = [
    'KABEL', 'kWh METER', 'MCB', 'CT', 'PT', 'TRAFO',
    'ISOLATOR & PROTEKSI', 'PHBTR & KUBIKEL', 'TIANG', 'BOX APP', 'AKSESORIS', 'LAINNYA'
  ];

  function getSupaCfg226() {
    try {
      var raw = localStorage.getItem('pfa_supabase_cfg_v1');
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed && parsed.url && parsed.anonKey) return parsed;
      }
    } catch (e) {}
    return null;
  }

  function buildSupaHeaders226(key) {
    var k = String(key || '').trim();
    var h = { apikey: k, Accept: 'application/json' };
    if (k.indexOf('eyJ') === 0) h.Authorization = 'Bearer ' + k;
    return h;
  }

  function getWebAppUrl226() {
    return (window.PFA_CONFIG && window.PFA_CONFIG.GAS_API_URL) ? String(window.PFA_CONFIG.GAS_API_URL).trim() : '';
  }

  async function supaGetJson226(path) {
    var cfg = getSupaCfg226();
    if (!cfg || navigator.onLine === false) return null;
    var r = await fetch(cfg.url.replace(/\/+$/, '') + '/rest/v1/' + path, {
      method: 'GET',
      headers: buildSupaHeaders226(cfg.anonKey)
    });
    if (!r.ok) return null;
    return await r.json();
  }

  function groupRank226(g) {
    var u = String(g || 'LAINNYA').trim().toUpperCase();
    for (var i = 0; i < MAT_GROUP_ORDER_226.length; i++) {
      if (MAT_GROUP_ORDER_226[i].toUpperCase() === u) return i;
    }
    return 99;
  }

  function installMaterialSupabaseFastPath() {
    if (window._pfaV226MatSupaWrapped || typeof window.callApi !== 'function') return;
    window._pfaV226MatSupaWrapped = true;
    var origCallApi = window.callApi;

    window.callApi = async function (payload) {
      var action = payload && payload.action ? String(payload.action).trim() : '';
      try {
        if (action === 'get_master_material') {
          var rows = await supaGetJson226('master_material?select=*&limit=1000');
          if (Array.isArray(rows) && rows.length > 0) {
            var list = rows.map(function (r) {
              return {
                kategori: r.kategori || '',
                kode: r.kode || '',
                nama: r.nama || '',
                satuan: r.satuan || 'BH',
                stok: Number(r.stok) || 0,
                keterangan: r.keterangan || '',
                kelompok: r.kelompok || 'LAINNYA',
                urutan: Number(r.urutan) || 99,
                stok_min: r.stok_min != null ? Number(r.stok_min) : 5,
                lokasi_rak: r.lokasi_rak || ''
              };
            });
            list.sort(function (a, b) {
              var ga = groupRank226(a.kelompok), gb = groupRank226(b.kelompok);
              if (ga !== gb) return ga - gb;
              if (a.urutan !== b.urutan) return a.urutan - b.urutan;
              return String(a.nama).localeCompare(String(b.nama));
            });
            return { status: 'success', data: list, groups: MAT_GROUP_ORDER_226, webAppUrl: getWebAppUrl226(), source: 'supabase' };
          }
        }

        if (action === 'get_antrean_material') {
          var rRows = await supaGetJson226('rekap_material?select=*&order=id.desc&limit=100');
          if (Array.isArray(rRows) && rRows.length > 0) {
            var wSec = 0, wAdm = 0;
            var aList = rRows.map(function (r) {
              if (r.status === 'MENUNGGU_SECURITY') wSec++;
              else if (r.status === 'MENUNGGU_ADMIN_GUDANG') wAdm++;
              var parsedItems = [];
              try { parsedItems = JSON.parse(r.items_json || '[]'); } catch (e) {}
              return {
                timestamp: r.timestamp || '', no_surat: r.no_surat || '', jenis: r.jenis || 'KELUAR',
                tanggal: r.tanggal || '', asal_tujuan: r.asal_tujuan || '', no_ref: r.no_ref || '',
                items: parsedItems, ringkasan: r.ringkasan || '', status: r.status || '',
                op_nama: r.op_nama || '', op_waktu: r.op_waktu || '', op_ttd: r.op_ttd || '',
                sec_nama: r.sec_nama || '', sec_waktu: r.sec_waktu || '', sec_catatan: r.sec_catatan || '', sec_ttd: r.sec_ttd || '',
                adm_nama: r.adm_nama || '', adm_waktu: r.adm_waktu || '', adm_catatan: r.adm_catatan || '', adm_ttd: r.adm_ttd || '',
                stok_terupdate: r.stok_terupdate || '', foto_pengajuan: r.foto_pengajuan || '', foto_security: r.foto_security || '',
                pdf_url: r.pdf_url || ''
              };
            });
            return { status: 'success', data: aList, counts: { waitingSecurity: wSec, waitingAdmin: wAdm }, webAppUrl: getWebAppUrl226(), source: 'supabase' };
          }
        }

        if (action === 'get_kartu_gantung' && payload.kode) {
          var kodeQ = String(payload.kode).trim().toUpperCase();
          var mRes = await supaGetJson226('master_material?kode=eq.' + encodeURIComponent(kodeQ) + '&limit=1');
          if (Array.isArray(mRes) && mRes.length > 0) {
            var it = mRes[0];
            var itemObj = {
              kategori: it.kategori || '', kode: it.kode, nama: it.nama, satuan: it.satuan || 'BH',
              stok: Number(it.stok) || 0, keterangan: it.keterangan || '', kelompok: it.kelompok || 'LAINNYA',
              urutan: Number(it.urutan) || 1, stok_min: it.stok_min != null ? Number(it.stok_min) : 5, lokasi_rak: it.lokasi_rak || ''
            };
            var rawMut = [];
            var rAll = await supaGetJson226('rekap_material?status=eq.DISETUJUI&select=no_surat,jenis,tanggal,asal_tujuan,no_ref,items_json,op_nama,adm_waktu&limit=500');
            if (Array.isArray(rAll)) {
              rAll.forEach(function (rr) {
                var arr = [];
                try { arr = JSON.parse(rr.items_json || '[]'); } catch (e) {}
                arr.forEach(function (x) {
                  if ((x.kode && String(x.kode).toUpperCase() === kodeQ) || String(x.nama || '').toLowerCase() === String(itemObj.nama).toLowerCase()) {
                    var q = Number(x.qty) || 0;
                    var jn = String(rr.jenis || 'KELUAR').toUpperCase();
                    rawMut.push({
                      waktu: rr.adm_waktu || rr.tanggal || '', tanggal: rr.tanggal || '',
                      no_ref: rr.no_surat || '', jenis: jn,
                      masuk: jn === 'MASUK' ? q : 0, keluar: jn === 'KELUAR' ? q : 0,
                      petugas: rr.asal_tujuan || rr.op_nama || '-', catatan: x.ket || rr.no_ref || ''
                    });
                  }
                });
              });
            }
            var lAll = await supaGetJson226('log_kartu_gantung?kode=eq.' + encodeURIComponent(kodeQ) + '&select=*&limit=300');
            if (Array.isArray(lAll)) {
              lAll.forEach(function (lr) {
                rawMut.push({
                  waktu: lr.timestamp || '', tanggal: String(lr.timestamp || '').slice(0, 10),
                  no_ref: lr.no_ref || 'ADJ-MANUAL', jenis: lr.jenis || 'PENYESUAIAN_MANUAL',
                  masuk: Number(lr.masuk) || 0, keluar: Number(lr.keluar) || 0,
                  petugas: lr.petugas || 'Admin Gudang', catatan: lr.catatan || ''
                });
              });
            }
            rawMut.sort(function (a, b) { return String(a.waktu || a.tanggal).localeCompare(String(b.waktu || b.tanggal)); });
            var net = 0;
            rawMut.forEach(function (m) { net += (m.masuk - m.keluar); });
            var sAwal = itemObj.stok - net;
            var mutFinal = [];
            var run = 0;
            if (sAwal !== 0 || rawMut.length === 0) {
              run = sAwal;
              mutFinal.push({ tanggal: '-', no_ref: 'SALDO-AWAL', jenis: 'SALDO AWAL', masuk: sAwal > 0 ? sAwal : 0, keluar: sAwal < 0 ? Math.abs(sAwal) : 0, saldo: run, petugas: 'Sistem Gudang', catatan: 'Saldo awal / penyesuaian sebelumnya' });
            }
            rawMut.forEach(function (rm) {
              run += (rm.masuk - rm.keluar);
              mutFinal.push({ tanggal: rm.tanggal, no_ref: rm.no_ref, jenis: rm.jenis, masuk: rm.masuk, keluar: rm.keluar, saldo: run, petugas: rm.petugas, catatan: rm.catatan });
            });
            var baseUrl = getWebAppUrl226();
            return {
              status: 'success', item: itemObj, mutasi: mutFinal,
              publicQrUrl: 'https://josetstwn-tech.github.io/pfa-backoffice/kartu.html?kode=' + encodeURIComponent(kodeQ),
              webAppUrl: baseUrl, source: 'supabase'
            };
          }
        }
      } catch (eSupa) {}
      return origCallApi(payload);
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { setTimeout(installMaterialSupabaseFastPath, 300); });
  } else {
    setTimeout(installMaterialSupabaseFastPath, 300);
  }
})();


// ============================================================================
// PFA v2.0.27: Cache DIL untuk Handoff Pengukuran->P2TL + Deep Link pfa://kartu
// ============================================================================
(function () {
  var pendingDeepLinkKode = '';

  function isPfaUserLoggedIn228() {
    try { if (typeof currentUser !== 'undefined' && currentUser) return true; } catch (e) {}
    if (window.currentUser) return true;
    var loginSec = document.getElementById('loginSection') || document.getElementById('login-section');
    if (loginSec && loginSec.classList.contains('d-none')) return true;
    var appMain = document.getElementById('appMain') || document.getElementById('mainApp');
    if (appMain && !appMain.classList.contains('d-none')) return true;
    return false;
  }

  function openKartuByDeepLink(kode, retryCount) {
    var clean = String(kode || '').trim().toUpperCase();
    if (!clean) return;
    var tries = Number(retryCount || 0);

    if (!isPfaUserLoggedIn228() || typeof window.openKartuGantungModal !== 'function') {
      if (tries < 12) {
        setTimeout(function () { openKartuByDeepLink(clean, tries + 1); }, 300);
        return;
      }
      pendingDeepLinkKode = clean;
      if (typeof window.showToast === 'function') {
        window.showToast('Login terlebih dahulu untuk membuka Kartu Gantung ' + clean + '.', 'info');
      }
      return;
    }

    pendingDeepLinkKode = '';
    try {
      if (typeof window.switchTab === 'function') window.switchTab('material');
      setTimeout(function () {
        if (typeof window.switchMatSubTab === 'function') window.switchMatSubTab('stok');
        setTimeout(function () {
          if (typeof window.openKartuGantungModal === 'function') window.openKartuGantungModal(clean);
        }, 200);
      }, 250);
    } catch (eDl) {}
  }

  function handleDeepLinkUrl(urlStr) {
    var u = String(urlStr || '').trim();
    if (!u) return;
    var m = u.match(/[?&]kode=([^&#]+)/i);
    if (m && m[1]) openKartuByDeepLink(decodeURIComponent(m[1]));
  }

  // Listener Deep Link Capacitor (aktif setelah AndroidManifest.xml didaftarkan scheme pfa://)
  function initPfaDeepLinkListener() {
    try {
      var CapApp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
      if (CapApp && typeof CapApp.addListener === 'function') {
        CapApp.addListener('appUrlOpen', function (ev) {
          if (ev && ev.url) handleDeepLinkUrl(ev.url);
        });
      }
      if (CapApp && typeof CapApp.getLaunchUrl === 'function') {
        CapApp.getLaunchUrl().then(function (r) {
          if (r && r.url) handleDeepLinkUrl(r.url);
        }).catch(function () {});
      }
    } catch (e) {}
  }

  // Tangkap hasil cari_pelanggan agar Pengukuran -> P2TL selalu membawa data DIL lengkap
  function wrapCariPelangganCache227() {
    if (window._pfaV227DilCacheWrapped || typeof window.callApi !== 'function') return;
    window._pfaV227DilCacheWrapped = true;
    var orig = window.callApi;
    window.callApi = async function (payload) {
      var res = await orig(payload);
      if (payload && payload.action === 'cari_pelanggan' && res && res.status === 'success' && res.data) {
        window._pfaLastDilData = res.data;
      }
      if (payload && payload.action === 'login' && res && res.status === 'success' && pendingDeepLinkKode) {
        setTimeout(function () { openKartuByDeepLink(pendingDeepLinkKode); }, 900);
      }
      return res;
    };
  }

  initPfaDeepLinkListener();
  window.addEventListener('load', function () {
    setTimeout(wrapCariPelangganCache227, 450);
  });
})();


// ============================================================================
// PFA v2.0.31: Redesain Compact Pengukuran, Auto-DIL OCR, Locked AI/P2TL/Ggn,
//              & Validasi Anti-Duplikat + Offline untuk Pengukuran & P2TL
// ============================================================================
(function () {
  var V231_READY = false;

  function pickDayaKvaFromVa(vaRaw) {
    var va = parseFloat(String(vaRaw || '').replace(/[^0-9.]/g, '')) || 0;
    if (!va) return null;
    if (va <= 41500) return 'NON_CT';
    var kva = Math.round((va / 1000) * 10) / 10;
    var sel = document.getElementById('u_daya_kva');
    if (!sel) return null;
    var best = null, minDiff = 999999;
    for (var i = 0; i < sel.options.length; i++) {
      var v = parseFloat(sel.options[i].value);
      if (!isNaN(v)) {
        var diff = Math.abs(v - kva);
        if (diff < minDiff) { minDiff = diff; best = sel.options[i].value; }
      }
    }
    return (best && minDiff <= 15) ? best : null;
  }

  function applyDilToPengukuranUI(d) {
    if (!d) return;
    window._pfaLastDilData = d;
    if (document.getElementById('u_idpel')) document.getElementById('u_idpel').value = d.id_pelanggan || '';
    if (document.getElementById('u_nama')) document.getElementById('u_nama').value = d.nama_pelanggan || '';
    if (document.getElementById('u_alamat')) document.getElementById('u_alamat').value = d.alamat || '';
    if (document.getElementById('u_tarif_daya')) document.getElementById('u_tarif_daya').value = [d.tarif, d.daya].filter(Boolean).join(' / ');

    var optVal = pickDayaKvaFromVa(d.daya);
    var selDaya = document.getElementById('u_daya_kva');
    if (optVal && selDaya) {
      selDaya.value = optVal;
      if (typeof window.onDayaKvaChange === 'function') window.onDayaKvaChange('kwh');
    }
    setUkurDilReadonly232(true);
    renderCompactPelangganStrip();
  }

  function setUkurDilReadonly232(locked) {
    ['u_idpel', 'u_nama', 'u_tarif_daya', 'u_alamat'].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      el.readOnly = Boolean(locked);
      el.classList.toggle('bg-light', Boolean(locked));
    });
  }

  function renderCompactPelangganStrip() {
    var strip = document.getElementById('pfaUkurPelStrip');
    var formRow = document.getElementById('pfaUkurPelSearchRow');
    if (!strip || !formRow) return;
    var idp = (document.getElementById('u_idpel') && document.getElementById('u_idpel').value.trim()) || '';
    var nama = (document.getElementById('u_nama') && document.getElementById('u_nama').value.trim()) || '';
    var td = (document.getElementById('u_tarif_daya') && document.getElementById('u_tarif_daya').value.trim()) || '';
    var fkm = (document.getElementById('badge_fkm_live') && document.getElementById('badge_fkm_live').textContent.trim()) || 'FKM: 1x';
    if (idp || nama) {
      strip.classList.remove('d-none');
      formRow.classList.add('d-none');
      var txt = document.getElementById('pfaUkurPelStripText');
      if (txt) txt.innerHTML = '<strong>' + (idp || '-') + '</strong> • ' + (nama || '-') + (td ? (' • ' + td) : '') + ' • <span class="badge text-bg-primary">' + fkm + '</span>';
    } else {
      strip.classList.add('d-none');
      formRow.classList.remove('d-none');
    }
  }

  function hasValidUkurPercent() {
    var kwhTxt = (document.getElementById('hdr_dev_kwh') && document.getElementById('hdr_dev_kwh').textContent.trim()) || '-';
    var ctTxt = (document.getElementById('hdr_dev_ct') && document.getElementById('hdr_dev_ct').textContent.trim()) || '-';
    return (kwhTxt !== '-' && kwhTxt !== '' && kwhTxt.indexOf('%') !== -1) || (ctTxt !== '-' && ctTxt !== '' && ctTxt.indexOf('%') !== -1);
  }

  function syncUkurActionButtonsLock() {
    var ready = hasValidUkurPercent();
    var aiBtn = document.getElementById('pfaBtnAiInsightUkur');
    var p2tlBtn = document.getElementById('pfaUkurToP2tlBtn');
    var ggnBtn = document.getElementById('pfaUkurToGgnBtn');
    [aiBtn, p2tlBtn, ggnBtn].forEach(function (b) {
      if (!b) return;
      b.disabled = !ready;
      b.style.opacity = ready ? '1' : '0.52';
    });
    if (aiBtn) {
      aiBtn.innerHTML = ready
        ? '<i class="bi bi-lightning-charge-fill text-warning me-1"></i>Analisa AI'
        : '<i class="bi bi-lock-fill me-1"></i>Analisa AI';
    }
    renderCompactPelangganStrip();
  }

  function runUkurAiAnalysis231() {
    if (!hasValidUkurPercent()) {
      if (typeof window.showToast === 'function') window.showToast('Hitung deviasi kWh atau CT terlebih dahulu.', 'warning');
      return;
    }
    var idp = (document.getElementById('u_idpel') && document.getElementById('u_idpel').value.trim()) || '-';
    var nama = (document.getElementById('u_nama') && document.getElementById('u_nama').value.trim()) || '-';
    var td = (document.getElementById('u_tarif_daya') && document.getElementById('u_tarif_daya').value.trim()) || '-';
    var fkm = (document.getElementById('badge_fkm_live') && document.getElementById('badge_fkm_live').textContent.trim()) || 'FKM: 1x';
    var p1 = (document.getElementById('simpan_p1') && document.getElementById('simpan_p1').textContent.trim()) || '-';
    var p2 = (document.getElementById('simpan_p2') && document.getElementById('simpan_p2').textContent.trim()) || '-';
    var devKwh = (document.getElementById('hdr_dev_kwh') && document.getElementById('hdr_dev_kwh').textContent.trim()) || '-';
    var avgCt = (document.getElementById('hdr_dev_ct') && document.getElementById('hdr_dev_ct').textContent.trim()) || '-';

    var promptText = 'Analisa hasil uji pengukuran lapangan sesuai SPLN & Perdir P2TL: ' +
      'IDPEL ' + idp + ' (' + nama + ', ' + td + ', ' + fkm + '), ' +
      'P1 = ' + p1 + ', P2 = ' + p2 + ', Deviasi kWh = ' + devKwh + ', Avg Error CT = ' + avgCt + '. ' +
      'Apakah masuk kategori Kelainan (K2), Meter Rusak, atau normal? Berikan langkah tindak lanjut lapangannya.';

    if (typeof window.switchTab === 'function') window.switchTab('chatbot');
    setTimeout(function () {
      var inp = document.getElementById('chatInput') || document.querySelector('#tab-chatbot textarea, #tab-chatbot input[type="text"]');
      if (inp) {
        inp.value = promptText;
        inp.dispatchEvent(new Event('input', { bubbles: true }));
      }
      if (typeof window.kirimPesanAi === 'function') window.kirimPesanAi();
      else {
        var sendBtn = document.querySelector('#tab-chatbot button[type="submit"], #btnSendChat');
        if (sendBtn) sendBtn.click();
      }
    }, 300);
  }

  function runUkurToP2tl231() {
    if (typeof window.kirimPengukuranKeP2tl === 'function') window.kirimPengukuranKeP2tl();
    setTimeout(function () {
      // Otomatis pilih Kelainan (K2)
      var radKel = document.getElementById('radP2tlKelainan');
      if (radKel) { radKel.checked = true; }
      var golEl = document.getElementById('p2tl_golongan');
      if (golEl) { golEl.value = 'K2'; }
      if (typeof window.onP2tlGolonganChange === 'function') window.onP2tlGolonganChange();

      // Jika data DIL belum lengkap tapi ada IDPEL, otomatis cari DIL!
      var idp = (document.getElementById('p2tl_idpel') && document.getElementById('p2tl_idpel').value.trim()) || '';
      var daya = (document.getElementById('p2tl_daya_va') && document.getElementById('p2tl_daya_va').value.trim()) || '';
      if (idp && !daya && typeof window.cariPelangganP2tl === 'function') {
        var cInp = document.getElementById('p2tlCariInput');
        if (cInp) cInp.value = idp;
        window.cariPelangganP2tl();
      }
    }, 220);
  }

  function runUkurToMeterRusak231() {
    var idp = (document.getElementById('u_idpel') && document.getElementById('u_idpel').value.trim()) || '';
    var nom = (window._pfaLastDilData && window._pfaLastDilData.no_meter_lama) || '';
    var q = idp || nom;
    if (typeof window.switchTab === 'function') window.switchTab('gangguan');
    setTimeout(function () {
      var cari = document.getElementById('cariInput') || document.getElementById('searchInput');
      if (cari && q) {
        cari.value = q;
        if (typeof window.cariPelanggan === 'function') window.cariPelanggan();
      } else if (typeof window.showToast === 'function') {
        window.showToast('Masukkan IDPEL di tab Gangguan untuk mencari DIL.', 'info');
      }
    }, 250);
  }

  function resetPelangganPengukuran231() {
    ['u_idpel', 'u_nama', 'u_alamat', 'u_tarif_daya', 'u_gps'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.value = '';
    });
    var qTop = document.getElementById('pfaUkurTopSearch');
    if (qTop) qTop.value = '';
    if (typeof window.resetPengukuranKwh === 'function') try { window.resetPengukuranKwh(); } catch (e) {}
    if (typeof window.resetPengukuranCt === 'function') try { window.resetPengukuranCt(); } catch (e2) {}
    if (document.getElementById('hdr_dev_kwh')) document.getElementById('hdr_dev_kwh').textContent = '-';
    if (document.getElementById('hdr_dev_ct')) document.getElementById('hdr_dev_ct').textContent = '-';
    setUkurDilReadonly232(false);
    syncUkurActionButtonsLock();
    if (typeof window.showToast === 'function') window.showToast('Data pelanggan & hasil ukur direset.', 'info');
  }

  function setupCompactPengukuranUI() {
    var tab = document.getElementById('tab-pengukuran');
    if (!tab || V231_READY) return;
    V231_READY = true;

    // 1. Rapikan header biru: sembunyikan angka duplikat di header, pindah tombol Tabel MCB/CT ke header
    var topbar = tab.querySelector('.topbar-pln');
    if (topbar) {
      var dupBadges = topbar.querySelector('.d-flex.gap-2.flex-wrap');
      if (dupBadges) {
        dupBadges.classList.add('d-none');
        var btnTbl = document.createElement('button');
        btnTbl.type = 'button';
        btnTbl.className = 'btn btn-sm btn-outline-light rounded-pill px-2 py-0';
        btnTbl.style.fontSize = '0.72rem';
        btnTbl.innerHTML = '<i class="bi bi-table me-1"></i>Tabel MCB/CT';
        btnTbl.onclick = function () {
          var oldRef = document.getElementById('pfaUkurRefSplnBtn');
          if (oldRef) oldRef.click();
        };
        dupBadges.parentNode.appendChild(btnTbl);
      }
    }

    // 2. Sisipkan 1 Kartu Ringkas "Pelanggan & AI OCR" di atas stepper
    var mainCard = tab.querySelector('.card.card-modern');
    if (mainCard && !document.getElementById('pfaUkurUnifiedCard')) {
      var uCard = document.createElement('div');
      uCard.id = 'pfaUkurUnifiedCard';
      uCard.className = 'card card-modern mb-2';
      uCard.innerHTML =
        '<div class="card-body p-2">' +
          '<div id="pfaUkurPelSearchRow">' +
            '<div class="small fw-bold text-primary mb-1"><i class="bi bi-person-badge me-1"></i>Pelanggan &amp; AI OCR (Auto-DIL &amp; FKM)</div>' +
            '<div class="d-flex gap-1 align-items-center">' +
              '<div class="input-group input-group-sm flex-grow-1">' +
                '<input type="text" id="pfaUkurTopSearch" class="form-control" placeholder="Cari IDPEL / No. Meter...">' +
                '<button type="button" class="btn btn-outline-secondary" id="pfaUkurTopScan" title="Scan Barcode"><i class="bi bi-qr-code-scan"></i></button>' +
                '<button type="button" class="btn btn-primary" style="background:var(--pln-blue);border-color:var(--pln-blue);" id="pfaUkurTopCari"><i class="bi bi-search"></i></button>' +
              '</div>' +
              '<button type="button" id="pfaBtnToggleOcrBar" class="btn btn-sm btn-info text-white fw-semibold text-nowrap"><i class="bi bi-stars me-1"></i>AI OCR</button>' +
            '</div>' +
            '<div id="pfaUkurOcrInlineBar" class="d-none d-flex gap-2 mt-2 pt-2 border-top">' +
              '<label class="btn btn-sm btn-primary flex-fill mb-0 fw-semibold" style="cursor:pointer;background:var(--pln-blue);border-color:var(--pln-blue);"><i class="bi bi-camera-fill me-1"></i>Kamera OCR<input type="file" accept="image/*" capture="environment" class="d-none" onchange="scanFotoOcrPengukuran(this); var b=document.getElementById(\'pfaUkurOcrInlineBar\'); if(b)b.classList.add(\'d-none\');"></label>' +
              '<label class="btn btn-sm btn-outline-primary flex-fill mb-0 fw-semibold" style="cursor:pointer;"><i class="bi bi-images me-1"></i>Galeri OCR<input type="file" accept="image/*" class="d-none" onchange="scanFotoOcrPengukuran(this); var b=document.getElementById(\'pfaUkurOcrInlineBar\'); if(b)b.classList.add(\'d-none\');"></label>' +
            '</div>' +
          '</div>' +
          '<div id="pfaUkurPelStrip" class="d-none d-flex justify-content-between align-items-center gap-2 bg-success-subtle border border-success-subtle rounded-3 px-2 py-1">' +
            '<div class="small text-dark" id="pfaUkurPelStripText" style="font-size:0.74rem;line-height:1.3;"></div>' +
            '<button type="button" class="btn btn-sm btn-outline-secondary py-0 px-2 text-nowrap" style="font-size:0.68rem;" id="pfaUkurResetPelBtn">Ganti</button>' +
          '</div>' +
        '</div>';
      mainCard.parentNode.insertBefore(uCard, mainCard);

      var doTopCari = function () {
        var kw = (document.getElementById('pfaUkurTopSearch').value || '').trim();
        if (!kw) return;
        if (typeof window.setLoading === 'function') window.setLoading(true, 'Mencari DIL...');
        window.callApi({ action: 'cari_pelanggan', keyword: kw }).then(function (res) {
          if (typeof window.setLoading === 'function') window.setLoading(false);
          if (res && res.status === 'success' && res.data) {
            applyDilToPengukuranUI(res.data);
            if (typeof window.showToast === 'function') window.showToast('Data DIL & FKM otomatis terisi!', 'success');
          } else if (typeof window.showToast === 'function') {
            window.showToast((res && res.message) || 'Tidak ditemukan di DIL.', 'warning');
          }
        }).catch(function () { if (typeof window.setLoading === 'function') window.setLoading(false); });
      };
      document.getElementById('pfaUkurTopCari').onclick = doTopCari;
      document.getElementById('pfaUkurTopSearch').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); doTopCari(); } });
      document.getElementById('pfaUkurTopScan').onclick = function () {
        if (typeof window.openBarcodeScanner === 'function') window.openBarcodeScanner('pfaUkurTopSearch');
      };
      document.getElementById('pfaUkurResetPelBtn').onclick = resetPelangganPengukuran231;
      var btnOcrTgl = document.getElementById('pfaBtnToggleOcrBar');
      if (btnOcrTgl) {
        btnOcrTgl.onclick = function () {
          var bar = document.getElementById('pfaUkurOcrInlineBar');
          if (bar) bar.classList.toggle('d-none');
        };
      }
      // Sembunyikan baris pencarian DIL duplikat di tab 3. Simpan (cukup pakai yang paling atas)
      var simpanSub = document.getElementById('ukur-sub-simpan');
      if (simpanSub) {
        var dupCariBtn = simpanSub.querySelector('button[onclick*="cariPelangganUkur"]');
        if (dupCariBtn) {
          var dupRow = dupCariBtn.closest('.row, .input-group, .mb-3, .mb-2');
          if (dupRow) dupRow.classList.add('d-none');
        }
      }
    }

    // 3. Sembunyikan kartu OCR besar lama agar halaman jauh lebih compact (tetap biarkan ocrResultBox terlihat di atas jika ada hasil)
    var oldOcrCard = tab.querySelector('#ocrResultBox') && tab.querySelector('#ocrResultBox').closest('.card');
    if (oldOcrCard) oldOcrCard.classList.add('d-none');

    // 4. Gabungkan tombol Analisa AI + Lanjut P2TL (K2) + Meter Rusak dalam 1 baris rapi di bawah KPI
    var toolsBar = document.getElementById('pfaUkurQuickToolsBar');
    var oldAiBtn = document.getElementById('pfaBtnAiInsightUkur');
    var oldTblBtn = document.getElementById('pfaUkurRefSplnBtn');
    if (oldTblBtn) oldTblBtn.classList.add('d-none');

    if (toolsBar && oldAiBtn) {
      oldAiBtn.className = 'btn btn-sm btn-primary fw-semibold flex-fill';
      oldAiBtn.style.cssText = 'font-size:0.72rem;background:var(--pln-blue);border-color:var(--pln-blue);';
      var cloneAi = oldAiBtn.cloneNode(true);
      oldAiBtn.remove();
      cloneAi.onclick = runUkurAiAnalysis231;
      toolsBar.insertBefore(cloneAi, toolsBar.firstChild);
    }
    var p2tlBtn = document.getElementById('pfaUkurToP2tlBtn');
    if (p2tlBtn) {
      p2tlBtn.className = 'btn btn-sm btn-outline-danger fw-semibold flex-fill';
      p2tlBtn.innerHTML = '<i class="bi bi-arrow-right-circle me-1"></i>P2TL (K2)';
      p2tlBtn.onclick = runUkurToP2tl231;
    }
    var ggnBtn = document.getElementById('pfaUkurToGgnBtn');
    if (ggnBtn) {
      ggnBtn.className = 'btn btn-sm btn-outline-info fw-semibold flex-fill';
      ggnBtn.innerHTML = '<i class="bi bi-tools me-1"></i>Meter Rusak';
      ggnBtn.onclick = runUkurToMeterRusak231;
    }

    // 5. Pantau perubahan nilai Deviasi kWh & Avg CT untuk auto-unlock tombol AI/P2TL/Meter Rusak
    ['hdr_dev_kwh', 'hdr_dev_ct'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el && typeof MutationObserver !== 'undefined') {
        new MutationObserver(syncUkurActionButtonsLock).observe(el, { childList: true, characterData: true, subtree: true });
      }
    });
    syncUkurActionButtonsLock();
  }

  // Intercept OCR + Online Duplicate Guard untuk Pengukuran & P2TL
  function wrapV231ApiHooks() {
    if (window._pfaV231Wrapped || typeof window.callApi !== 'function') return;
    window._pfaV231Wrapped = true;
    var orig = window.callApi;

    window.callApi = async function (payload) {
      var res = await orig(payload);
      var act = payload && payload.action ? String(payload.action).trim() : '';

      // Auto-DIL & Auto-FKM setelah AI OCR membaca No. Meter / IDPEL!
      if (act === 'ocr_foto_meter_ct' && res && res.status === 'success' && res.data) {
        var od = res.data;
        var candidate = String(od.no_meter || od.id_pelanggan || od.serial_number || '').replace(/[^0-9]/g, '');
        if (!candidate && od.ringkasan) {
          var m = String(od.ringkasan).match(/\b\d{9,12}\b/);
          if (m) candidate = m[0];
        }
        if (candidate) {
          setTimeout(function () {
            orig({ action: 'cari_pelanggan', keyword: candidate }).then(function (dilRes) {
              if (dilRes && dilRes.status === 'success' && dilRes.data) {
                applyDilToPengukuranUI(dilRes.data);
                if (typeof window.showToast === 'function') {
                  window.showToast('OCR cocok dengan DIL (' + dilRes.data.nama_pelanggan + ') — Daya & FKM terisi otomatis!', 'success');
                }
              }
            }).catch(function () {});
          }, 250);
        }
      }

      // Sinkron strip pelanggan bila cari_pelanggan dipanggil dari tab 3. Simpan
      if (act === 'cari_pelanggan' && res && res.status === 'success' && res.data) {
        setTimeout(renderCompactPelangganStrip, 250);
      }

      // Validasi Anti-Duplikat Online untuk Pengukuran & P2TL
      if ((act === 'simpan_pengukuran' || act === 'simpan_p2tl') && res && res.status === 'duplicate') {
        var latest = (res.duplicate && res.duplicate.latest) || {};
        var msg = 'IDPEL ' + (latest.idpel || (payload.data && payload.data.id_pelanggan) || '-') +
          ' sudah pernah diinput pada ' + (latest.tanggal || '-') +
          ' oleh ' + (latest.petugas || '-') + ' (' + (latest.keterangan || '-') + ').\n\nTetap kirim data baru (duplikat)?';
        if (confirm(msg)) {
          var retryPayload = Object.assign({}, payload, { allowDuplicate: true });
          return await orig(retryPayload);
        }
        return { status: 'error', message: 'Pengiriman dibatalkan karena data duplikat.' };
      }

      return res;
    };
  }

  window.addEventListener('load', function () {
    setTimeout(setupCompactPengukuranUI, 1400);
    setTimeout(wrapV231ApiHooks, 600);
  });
})();


// ============================================================================
// PFA v2.0.34: PFA AI Pro Compact UI, SVG Fasor 3 Fasa, Agentic Autofill,
//              Human-in-the-Loop Koreksi KB, Client-Side PDF RAG, & Portal Saya|Posko
// ============================================================================
(function () {
  function isAdminRole234() {
    var r = '';
    try { r = String((typeof currentUser !== 'undefined' && currentUser && currentUser.role) || '').toUpperCase(); } catch (e) {}
    return r.indexOf('ADMIN') !== -1;
  }

  function renderSvgPhasor234(tagStr) {
    var vals = { Vr: 220, Vs: 220, Vt: 220, Ir: 10, Is: 10, It: 10 };
    tagStr.split(',').forEach(function (kv) {
      var pts = kv.split('=');
      if (pts.length === 2) vals[pts[0].trim()] = parseFloat(pts[1]) || 0;
    });
    var cx = 90, cy = 85, rV = 62, rI = 44;
    var degToPt = function (deg, rad) {
      var a = (deg - 90) * Math.PI / 180;
      return { x: (cx + rad * Math.cos(a)).toFixed(1), y: (cy + rad * Math.sin(a)).toFixed(1) };
    };
    var vecs = [
      { lbl: 'R', deg: 0, iVal: vals.Ir, col: '#eab308' },
      { lbl: 'S', deg: 120, iVal: vals.Is, col: '#dc2626' },
      { lbl: 'T', deg: 240, iVal: vals.It, col: '#2563eb' }
    ];
    var lines = '';
    vecs.forEach(function (v) {
      var pv = degToPt(v.deg, rV);
      var iDeg = v.iVal < 0 ? (v.deg + 180) : v.deg;
      var pi = degToPt(iDeg, Math.min(rI, Math.max(20, Math.abs(v.iVal) * 2.5)));
      lines += '<line x1="' + cx + '" y1="' + cy + '" x2="' + pv.x + '" y2="' + pv.y + '" stroke="' + v.col + '" stroke-width="2.4" stroke-linecap="round"/>';
      lines += '<text x="' + pv.x + '" y="' + pv.y + '" font-size="10" font-weight="800" fill="' + v.col + '" dx="3" dy="-2">V' + v.lbl + '</text>';
      if (v.iVal !== 0) {
        lines += '<line x1="' + cx + '" y1="' + cy + '" x2="' + pi.x + '" y2="' + pi.y + '" stroke="' + v.col + '" stroke-width="1.8" stroke-dasharray="4,2"/>';
        lines += '<circle cx="' + pi.x + '" cy="' + pi.y + '" r="2.8" fill="' + v.col + '"/>';
      }
    });
    return '<div class="border rounded-3 bg-light p-2 my-2 text-center">' +
      '<div class="small fw-bold text-primary mb-1" style="font-size:0.7rem;">Diagram Fasor 3 Fasa (Garis Penuh = V, Putus = I)</div>' +
      '<svg width="180" height="170" viewBox="0 0 180 170" style="max-width:100%;height:auto;">' +
        '<circle cx="' + cx + '" cy="' + cy + '" r="62" fill="#fff" stroke="#cbd5e1" stroke-width="1"/>' +
        '<circle cx="' + cx + '" cy="' + cy + '" r="36" fill="none" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="3,3"/>' +
        '<line x1="20" y1="' + cy + '" x2="160" y2="' + cy + '" stroke="#e2e8f0" stroke-width="1"/>' +
        '<line x1="' + cx + '" y1="15" x2="' + cx + '" y2="155" stroke="#e2e8f0" stroke-width="1"/>' +
        lines +
      '</svg>' +
      '<div class="text-muted" style="font-size:0.66rem;">Ir=' + vals.Ir + 'A • Is=' + vals.Is + 'A • It=' + vals.It + 'A</div>' +
    '</div>';
  }

  window.pfaRunAiAutofill234 = function (rawPayload) {
    var pts = String(rawPayload || '').split('|');
    var mod = (pts[0] || '').trim().toLowerCase();
    var kv = {};
    pts.slice(1).forEach(function (p) {
      var ix = p.indexOf('=');
      if (ix > 0) kv[p.slice(0, ix).trim().toLowerCase()] = p.slice(ix + 1).trim();
    });
    if (mod === 'gangguan') {
      if (typeof window.switchTab === 'function') window.switchTab('gangguan');
      setTimeout(function () {
        if (kv.idpel) {
          var c = document.getElementById('cariInput') || document.getElementById('searchInput');
          if (c) c.value = kv.idpel;
          if (typeof window.cariPelanggan === 'function') window.cariPelanggan();
        }
        if (kv.sisa_kwh && document.getElementById('sisa_kwh')) document.getElementById('sisa_kwh').value = kv.sisa_kwh;
        if (kv.ket && document.getElementById('keterangan')) document.getElementById('keterangan').value = kv.ket;
        if (typeof window.showToast === 'function') window.showToast('Form Gangguan diisi otomatis oleh PFA AI!', 'success');
      }, 280);
    } else if (mod === 'p2tl') {
      if (typeof window.switchTab === 'function') window.switchTab('p2tl');
      setTimeout(function () {
        if (kv.idpel) {
          var cp = document.getElementById('p2tlCariInput');
          if (cp) cp.value = kv.idpel;
          if (typeof window.cariPelangganP2tl === 'function') window.cariPelangganP2tl();
        }
        if (kv.gol && document.getElementById('p2tl_golongan')) {
          document.getElementById('p2tl_golongan').value = kv.gol.toUpperCase();
          if (typeof window.onP2tlGolonganChange === 'function') window.onP2tlGolonganChange();
        }
        if (kv.uraian && document.getElementById('p2tl_uraian')) document.getElementById('p2tl_uraian').value = kv.uraian;
        if (typeof window.showToast === 'function') window.showToast('Form P2TL diisi otomatis oleh PFA AI!', 'success');
      }, 280);
    }
  };

  function enhanceAiBubbles234() {
    var box = document.getElementById('chatAiBox');
    if (!box) return;
    box.querySelectorAll('.pfa-ai-msg, .bg-white.border, .alert').forEach(function (el) {
      if (el.getAttribute('data-v234-done')) return;
      var txt = el.innerText || '';
      if (!txt || txt.length < 25) return;
      el.setAttribute('data-v234-done', '1');

      // 1. Render inline SVG Phasor Diagram jika ada tag [FASOR:...]
      var html = el.innerHTML;
      var mFas = html.match(/\[FASOR:([^\]]+)\]/i);
      if (mFas) {
        html = html.replace(mFas[0], renderSvgPhasor234(mFas[1]));
      }
      // 2. Render tombol Agentic Autofill jika ada tag [AUTOFILL:...]
      var mAf = html.match(/\[AUTOFILL:([^\]]+)\]/i);
      if (mAf) {
        var cleanAf = mAf[1].replace(/'/g, '');
        html = html.replace(mAf[0], '<div class="mt-2"><button type="button" class="btn btn-sm btn-primary rounded-pill px-3 py-1 fw-semibold" style="font-size:0.74rem;background:var(--pln-blue);border-color:var(--pln-blue);" onclick="pfaRunAiAutofill234(\'' + cleanAf + '\')"><i class="bi bi-lightning-charge-fill text-warning me-1"></i>Isi Form Otomatis</button></div>');
      }
      if (mFas || mAf) el.innerHTML = html;

      // 3. Tambahkan bar kompak [Memori] & [Koreksi KB (Admin)]
      if (!el.querySelector('.pfa-ai-pro-bar')) {
        var bar = document.createElement('div');
        bar.className = 'pfa-ai-pro-bar d-flex flex-wrap gap-1 mt-2 pt-2 border-top';
        var memBtn = '<button type="button" class="btn btn-outline-primary py-0 px-2 rounded-pill" style="font-size:0.68rem;" data-ai-mem><i class="bi bi-bookmark-plus me-1"></i>Simpan Memori</button>';
        var korBtn = isAdminRole234() ? '<button type="button" class="btn btn-outline-warning text-dark py-0 px-2 rounded-pill" style="font-size:0.68rem;" data-ai-kor><i class="bi bi-pencil-square me-1"></i>Koreksi KB</button>' : '';
        bar.innerHTML = memBtn + korBtn;
        el.appendChild(bar);

        bar.querySelector('[data-ai-mem]').onclick = function () {
          var idMatch = txt.match(/\b\d{9,12}\b/);
          var ent = prompt('Simpan diagnosa ini ke Memori Teknis AI untuk IDPEL / Kode Gardu:', idMatch ? idMatch[0] : '');
          if (!ent) return;
          var pet = '';
          try { pet = (typeof currentUser !== 'undefined' && currentUser && (currentUser.nama || currentUser.username)) || 'Petugas'; } catch (e) {}
          window.callApi({ action: 'save_ai_engineering_memory', entitasId: ent, tipe: /^\d+$/.test(ent) ? 'IDPEL' : 'GARDU', ringkasan: txt.slice(0, 700), petugas: pet })
            .then(function (r) { if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Tersimpan ke Memori AI.', r && r.status === 'success' ? 'success' : 'warning'); });
        };

        var kbEl = bar.querySelector('[data-ai-kor]');
        if (kbEl) {
          kbEl.onclick = function () {
            var jdl = prompt('Judul aturan / koreksi KB (misal: Aturan Segel UP3 Sukabumi):');
            if (!jdl) return;
            var isi = prompt('Masukkan aturan / jawaban yang benar agar PFA AI mengingatnya:');
            if (!isi) return;
            window.callApi({ action: 'admin_save_ai_correction', judul: jdl, koreksi: isi, kategori: 'KOREKSI_ADMIN' })
              .then(function (r) { if (typeof window.showToast === 'function') window.showToast((r && r.message) || 'Koreksi tersimpan ke KB!', r && r.status === 'success' ? 'success' : 'danger'); });
          };
        }
      }
    });
  }

  function setupCompactChatbotUI234() {
    var tab = document.getElementById('tab-chatbot');
    if (!tab || document.getElementById('pfaAiProQuickBar')) return;
    var box = document.getElementById('chatAiBox');
    if (!box) return;

    // 1. Tambah lencana "Supabase + KB Live" di header chatbot
    var hdr = tab.querySelector('.topbar-pln, .card-header');
    if (hdr && !hdr.querySelector('.pfa-ai-live-pill')) {
      var pill = document.createElement('span');
      pill.className = 'pfa-ai-live-pill badge rounded-pill text-bg-success ms-2';
      pill.style.fontSize = '0.66rem';
      pill.innerHTML = '<i class="bi bi-database-check me-1"></i>Supabase + KB Live';
      var hTitle = hdr.querySelector('h6, .fw-bold');
      if (hTitle) hTitle.appendChild(pill);
    }

    // 2. Tambah 1 baris pil pintasan kompak di atas chat box
    var qBar = document.createElement('div');
    qBar.id = 'pfaAiProQuickBar';
    qBar.className = 'd-flex gap-1 overflow-auto pb-2 mb-2';
    qBar.style.scrollbarWidth = 'none';
    var chips = [
      { lbl: '☀️ Briefing Pagi', prompt: 'Berikan Briefing Pagi operasional hari ini: cek antrean Surat Jalan Material, stok material kritis, saldo kWh posko yang menipis, dan ringkasan rekap terbaru!' },
      { lbl: '📊 Tanya Data', prompt: 'Berapa total rekap gangguan, pengukuran, estimasi Rupiah TS P2TL, dan daftar stok material kritis saat ini dari Supabase?' },
      { lbl: '📐 Fasor 3 Fasa', prompt: 'Analisa fasor 3 fasa: Vr=220V, Vs=220V, Vt=220V, Ir=12A, Is=-12A, It=12A. Apa kesalahan wiring CT-nya dan berapa % energi yang hilang?' },
      { lbl: '⚖️ Audit P2TL', prompt: 'Saya ingin audit forensik berkas P2TL sebelum keberatan pelanggan. Apa saja 5 poin bukti wajib agar kuat sesuai Perdir 0028.P/DIR/2023 dan P3TL 2025?' },
      { lbl: '🗣️ Skrip Pelanggan', prompt: 'Buatkan kalimat penjelasan yang sopan, tenang, dan tegas berbasis Perdir PLN untuk pelanggan P2TL yang keberatan menandatangani BA.' }
    ];
    qBar.innerHTML = chips.map(function (c, i) {
      return '<button type="button" class="btn btn-sm btn-outline-primary rounded-pill text-nowrap py-0 px-2 bg-white" style="font-size:0.72rem;" data-ai-chip="' + i + '">' + c.lbl + '</button>';
    }).join('');
    box.parentNode.insertBefore(qBar, box);

    qBar.querySelectorAll('[data-ai-chip]').forEach(function (b) {
      b.onclick = function () {
        var c = chips[Number(this.getAttribute('data-ai-chip'))];
        var inp = document.getElementById('chatAiInput');
        if (inp && c) {
          inp.value = c.prompt;
          inp.focus();
          if (typeof window.kirimPesanAi === 'function') window.kirimPesanAi();
          else {
            var sendBtn = tab.querySelector('button[onclick*="kirimPesanAi"], button[onclick*="sendChat"]');
            if (sendBtn) sendBtn.click();
          }
        }
      };
    });

    if (typeof MutationObserver !== 'undefined') {
      new MutationObserver(enhanceAiBubbles234).observe(box, { childList: true, subtree: true });
    }
  }

  // ==========================================================================
  // CLIENT-SIDE PDF RAG UPLOADER (ZERO LIMIT 429, ZERO 8 MB CAP!)
  // ==========================================================================
  function extractRawPdfTextFallback(arrayBuf) {
    var bytes = new Uint8Array(arrayBuf);
    var dec = '';
    for (var i = 0; i < bytes.length; i++) {
      var ch = bytes[i];
      dec += (ch >= 32 && ch <= 126) || ch === 10 || ch === 13 ? String.fromCharCode(ch) : ' ';
    }
    var parts = [];
    var m;
    var re = /\(([^()]{3,300})\)\s*Tj/g;
    while ((m = re.exec(dec)) !== null) {
      parts.push(m[1].replace(/\\([()\\])/g, '$1'));
    }
    return parts.join(' ').replace(/\s+/g, ' ').trim();
  }

  async function extractPdfTextClientSide(file) {
    var buf = await file.arrayBuffer();
    if (window.pdfjsLib && window.pdfjsLib.getDocument) {
      try {
        var pdf = await window.pdfjsLib.getDocument({ data: buf }).promise;
        var pages = [];
        for (var p = 1; p <= pdf.numPages; p++) {
          var page = await pdf.getPage(p);
          var tc = await page.getTextContent();
          var line = tc.items.map(function (it) { return it.str; }).join(' ').replace(/\s+/g, ' ').trim();
          if (line) pages.push('[Hal. ' + p + '] ' + line);
        }
        if (pages.length) return pages.join('\n\n');
      } catch (ePdf) {}
    }
    return extractRawPdfTextFallback(buf);
  }

  function chunkTextForRag(fullText, fileName, kategori) {
    var clean = String(fullText || '').replace(/\s+/g, ' ').trim();
    var baseTitle = String(fileName || 'Dokumen').replace(/\.pdf$/i, '');
    var chunks = [];
    var size = 1600;
    var step = 1450;
    for (var i = 0, idx = 1; i < clean.length; i += step, idx++) {
      var slice = clean.slice(i, i + size).trim();
      if (slice.length < 40) continue;
      chunks.push({
        id_kb: 'RAG_' + baseTitle.replace(/[^a-zA-Z0-9]/g, '').slice(0, 14) + '_' + idx + '_' + String(Date.now()).slice(-4),
        kategori: kategori || 'REGULASI',
        judul: baseTitle + ' (Bagian ' + idx + ')',
        ringkasan_teknis: slice,
        kata_kunci: (baseTitle + ' ' + kategori).toLowerCase(),
        metode_riset: 'PDF_RAG'
      });
    }
    return chunks;
  }

  function installClientPdfRagUploader234() {
    var origUpload = window.uploadKbDocumentAdmin;
    window.uploadKbDocumentAdmin = async function () {
      var inp = document.getElementById('kbDocFileInput');
      var file = inp && inp.files && inp.files[0];
      if (!file || !String(file.name || '').toLowerCase().endsWith('.pdf')) {
        if (typeof origUpload === 'function') return origUpload();
        return;
      }
      var kat = (document.getElementById('kbDocKategori') && document.getElementById('kbDocKategori').value) || 'REGULASI';
      try {
        if (typeof window.setLoading === 'function') window.setLoading(true, 'Mengekstrak teks PDF lokal (bebas limit)...');
        var text = await extractPdfTextClientSide(file);
        if (!text || text.length < 60) {
          if (typeof window.setLoading === 'function') window.setLoading(false);
          if (typeof window.showToast === 'function') window.showToast('PDF ini berupa gambar scan (tanpa teks). Silakan gunakan file PDF berbasis teks atau paste ringkasannya di input manual KB.', 'warning');
          return;
        }
        var chunks = chunkTextForRag(text, file.name, kat);
        var savedTotal = 0;
        for (var b = 0; b < chunks.length; b += 25) {
          var batch = chunks.slice(b, b + 25);
          if (typeof window.setLoading === 'function') window.setLoading(true, 'Menyimpan RAG ke Supabase (' + Math.min(b + 25, chunks.length) + '/' + chunks.length + ' bagian)...');
          var r = await window.callApi({ action: 'admin_batch_upsert_kb_chunks', chunks: batch });
          if (r && r.status === 'success') savedTotal += (r.saved || batch.length);
        }
        if (typeof window.setLoading === 'function') window.setLoading(false);
        inp.value = '';
        if (typeof window.showToast === 'function') window.showToast('Sukses! ' + savedTotal + ' bagian PDF tersimpan ke Knowledge Base AI (Supabase) tanpa kena limit!', 'success');
      } catch (err) {
        if (typeof window.setLoading === 'function') window.setLoading(false);
        if (typeof window.showToast === 'function') window.showToast('Gagal proses PDF: ' + ((err && err.message) || err), 'danger');
      }
    };
  }

  // ==========================================================================
  // PORTAL COMPACT TAB: SAYA | POSKO (DI KARTU AKTIVITAS TERAKHIR)
  // ==========================================================================
  function injectPortalSayaPoskoTab234() {
    var listEl = document.getElementById('portalRecentList');
    if (!listEl || document.getElementById('pfaPortalActToggle')) return;
    var card = listEl.closest('.card, .card-body');
    if (!card) return;
    var hdrRow = card.querySelector('.d-flex, .section-title');
    if (!hdrRow) return;

    var wrap = document.createElement('div');
    wrap.id = 'pfaPortalActToggle';
    wrap.className = 'btn-group btn-group-sm ms-auto';
    wrap.innerHTML =
      '<button type="button" class="btn btn-primary py-0 px-2" style="font-size:0.68rem;background:var(--pln-blue);border-color:var(--pln-blue);" data-act-mode="saya">Saya</button>' +
      '<button type="button" class="btn btn-outline-secondary py-0 px-2" style="font-size:0.68rem;" data-act-mode="posko">Posko</button>';

    if (hdrRow.classList.contains('d-flex')) hdrRow.appendChild(wrap);
    else {
      var bar = document.createElement('div');
      bar.className = 'd-flex justify-content-between align-items-center mb-2';
      hdrRow.parentNode.insertBefore(bar, hdrRow);
      bar.appendChild(hdrRow);
      bar.appendChild(wrap);
    }

    var savedSayaHtml = '';
    wrap.querySelectorAll('[data-act-mode]').forEach(function (btn) {
      btn.onclick = function () {
        var mode = this.getAttribute('data-act-mode');
        wrap.querySelectorAll('[data-act-mode]').forEach(function (x) {
          var on = x.getAttribute('data-act-mode') === mode;
          x.className = on ? 'btn btn-primary py-0 px-2' : 'btn btn-outline-secondary py-0 px-2';
          x.style.cssText = on ? 'font-size:0.68rem;background:var(--pln-blue);border-color:var(--pln-blue);' : 'font-size:0.68rem;';
        });
        if (mode === 'saya') {
          if (savedSayaHtml) listEl.innerHTML = savedSayaHtml;
          return;
        }
        savedSayaHtml = listEl.innerHTML;
        listEl.innerHTML = '<div class="small text-muted py-2 text-center">Memuat aktivitas tim posko hari ini...</div>';
        var posko = '';
        try { posko = (typeof currentUser !== 'undefined' && currentUser && (currentUser.regu || currentUser.role)) || ''; } catch (e) {}
        window.callApi({ action: 'get_portal_posko_activity', posko: posko }).then(function (r) {
          if (!r || r.status !== 'success' || !Array.isArray(r.data) || !r.data.length) {
            listEl.innerHTML = '<div class="small text-muted py-2 text-center">Belum ada laporan tim posko hari ini di Supabase.</div>';
            return;
          }
          listEl.innerHTML = r.data.slice(0, 12).map(function (it) {
            return '<div class="d-flex justify-content-between align-items-center border-bottom py-1 small">' +
              '<div><span class="badge text-bg-light border text-dark me-1" style="font-size:0.64rem;">' + (it.modul || '-') + '</span><strong>' + (it.idpel || '-') + '</strong> <span class="text-muted">' + (it.nama || '') + '</span><div class="text-muted" style="font-size:0.68rem;">' + (it.petugas || '-') + ' • ' + (it.info || '-') + '</div></div>' +
              '<span class="badge text-bg-primary-subtle text-primary" style="font-size:0.64rem;">' + (it.posko || '-') + '</span>' +
            '</div>';
          }).join('');
        }).catch(function () {
          listEl.innerHTML = '<div class="small text-muted py-2 text-center">Gagal memuat aktivitas posko.</div>';
        });
      };
    });
  }

  window.addEventListener('load', function () {
    setTimeout(setupCompactChatbotUI234, 1500);
    setTimeout(installClientPdfRagUploader234, 1200);
    setTimeout(injectPortalSayaPoskoTab234, 1700);
  });
})();


/* ==========================================================================
   PFA v2.1.11 — MINI STEPPER -> FLOATING PILL, PROFIL 360°, CAPAIAN & BELL
   ========================================================================== */
(function () {
  'use strict';

  window.pfaShowStepperPill = function (state, text) {
    var pill = document.getElementById('pfaFloatingStepperPill');
    if (state === 'hide') {
      if (pill) pill.remove();
      return;
    }
    if (!pill) {
      pill = document.createElement('div');
      pill.id = 'pfaFloatingStepperPill';
      pill.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:9999;min-width:260px;max-width:90vw;border-radius:999px;padding:12px 20px;font-size:0.84rem;font-weight:700;box-shadow:0 16px 40px rgba(15,23,42,0.42);border:2px solid rgba(255,255,255,0.25);display:flex;align-items:center;justify-content:center;gap:10px;transition:all 0.25s;';
      document.body.appendChild(pill);
    }
    if (state === 'done') {
      pill.style.background = '#047857';
      pill.style.color = '#ffffff';
      pill.innerHTML = '<i class="bi bi-check-circle-fill"></i><span>' + (text || 'Tersimpan!') + '</span>';
      setTimeout(function () { var p = document.getElementById('pfaFloatingStepperPill'); if (p) p.remove(); }, 2600);
    } else if (state === 'step2') {
      pill.style.background = '#003b73';
      pill.style.color = '#ffffff';
      pill.innerHTML = '<span class="spinner-border spinner-border-sm text-warning"></span><span>2/2 • ' + (text || 'Mengarsipkan ke Drive & Supabase...') + '</span>';
    } else {
      pill.style.background = '#0f172a';
      pill.style.color = '#ffffff';
      pill.innerHTML = '<span class="spinner-border spinner-border-sm text-info"></span><span>1/2 • ' + (text || 'Menyusun Foto Grid & PDF...') + '</span>';
    }
  };

  window.openPfaNotifCenter = function () {
    var d = window._pfaLastNotifSummary || { totalAlerts: 0, slaMeterDummy: [], slaPotensiP2tl: [], summaryToday: {} };
    var old = document.getElementById('pfaNotifCenterModal');
    if (old) old.remove();
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="modal fade" id="pfaNotifCenterModal" tabindex="-1">' +
        '<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">' +
          '<div class="modal-content rounded-4 border-0 shadow-lg">' +
            '<div class="modal-header bg-primary text-white py-2">' +
              '<h6 class="modal-title fw-bold mb-0"><i class="bi bi-bell-fill me-1"></i>Pusat Notifikasi PFA v2.1.11</h6>' +
              '<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>' +
            '</div>' +
            '<div class="modal-body small">' +
              '<div class="list-group list-group-flush">' +
                '<div class="list-group-item px-0 d-flex justify-content-between"><span>⚠️ Meter Dummy/Sementara ≥3 hari</span><strong class="text-danger">' + (d.slaMeterDummy ? d.slaMeterDummy.length : 0) + '</strong></div>' +
                '<div class="list-group-item px-0 d-flex justify-content-between"><span>🟡 Potensi P2TL ≥7 hari belum Realisasi</span><strong class="text-warning-emphasis">' + (d.slaPotensiP2tl ? d.slaPotensiP2tl.length : 0) + '</strong></div>' +
                '<div class="list-group-item px-0 d-flex justify-content-between"><span>📦 Antrean Approval Material</span><strong class="text-primary">' + ((d.summaryToday && d.summaryToday.pendingMaterial) || 0) + '</strong></div>' +
              '</div>' +
            '</div>' +
            '<div class="modal-footer py-2">' +
              '<button type="button" class="btn btn-sm btn-primary rounded-pill px-3" data-bs-dismiss="modal" onclick="if(typeof switchTab===\'function\'){switchTab(\'admin\');setTimeout(function(){if(typeof switchAdminSubTab===\'function\')switchAdminSubTab(\'sla\');},180);}">Buka Radar SLA</button>' +
              '<button type="button" class="btn btn-sm btn-light rounded-pill px-3" data-bs-dismiss="modal">Tutup</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(wrap.firstChild);
    var el = document.getElementById('pfaNotifCenterModal');
    if (el && typeof bootstrap !== 'undefined') bootstrap.Modal.getOrCreateInstance(el).show();
  };

  function runProfil360Lookup(kw) {
    var clean = String(kw || '').trim();
    if (!clean || typeof window.callApi !== 'function') return;
    var box = document.getElementById('pfaProfil360Box');
    var body = document.getElementById('pfaProfil360Body');
    if (!box || !body) return;
    box.classList.remove('d-none');
    body.innerHTML = '<div class="pfa-skel mb-1" style="height:14px;width:55%;"></div><div class="pfa-skel" style="height:11px;width:85%;"></div>';
    window.callApi({ action: 'get_profil_pelanggan_360', keyword: clean }).then(function (res) {
      if (!res || res.status !== 'success' || !res.found) {
        body.innerHTML = '<div class="text-muted">Data pelanggan tidak ditemukan untuk <strong>' + clean + '</strong>.</div>';
        return;
      }
      var p = res.pelanggan || {};
      var idp = res.idpel || p.idpel || clean;
      var nm = p.nama || '-';
      var td = [p.tarif, p.daya].filter(Boolean).join(' / ') || '-';
      var gCnt = (res.gangguan || []).length;
      var uCnt = (res.pengukuran || []).length;
      var p2Cnt = (res.p2tl || []).length;
      body.innerHTML =
        '<div class="fw-bold text-dark">' + idp + ' — ' + nm + '</div>' +
        '<div class="text-muted mb-2" style="font-size:0.72rem;">Tarif/Daya: <strong>' + td + '</strong> • Meter: ' + (p.no_meter || '-') + '</div>' +
        '<div class="d-flex flex-wrap gap-1 mb-2">' +
          '<span class="badge bg-success-subtle text-success border border-success-subtle">DIL Aktif</span>' +
          '<span class="badge bg-info-subtle text-info-emphasis border">KCT: ' + (res.kctCount || 0) + '</span>' +
          '<span class="badge bg-warning-subtle text-warning-emphasis border">Ganti Meter: ' + gCnt + 'x</span>' +
          '<span class="badge bg-primary-subtle text-primary border">Ukur: ' + uCnt + 'x</span>' +
          '<span class="badge bg-danger-subtle text-danger border">P2TL: ' + p2Cnt + 'x</span>' +
        '</div>' +
        '<div class="d-flex gap-1">' +
          '<button type="button" class="btn btn-xs btn-outline-primary flex-fill py-1" style="font-size:0.7rem;" onclick="switchTab(\'gangguan\'); var x=document.getElementById(\'cariPelangganInput\'); if(x){x.value=\'' + idp + '\'; if(typeof cariPelanggan===\'function\') cariPelanggan();}">Ganti Meter</button>' +
          '<button type="button" class="btn btn-xs btn-outline-info flex-fill py-1" style="font-size:0.7rem;" onclick="switchTab(\'pengukuran\'); var x=document.getElementById(\'u_cari_pelanggan\'); if(x){x.value=\'' + idp + '\'; if(typeof cariPelangganPengukuran===\'function\') cariPelangganPengukuran();}">Ukur</button>' +
          '<button type="button" class="btn btn-xs btn-outline-warning text-dark flex-fill py-1" style="font-size:0.7rem;" onclick="switchTab(\'p2tl\'); var x=document.getElementById(\'p2tlCariInput\'); if(x){x.value=\'' + idp + '\'; if(typeof cariPelangganP2tl===\'function\') cariPelangganP2tl();}">P2TL</button>' +
        '</div>';
    }).catch(function () {
      body.innerHTML = '<div class="text-danger">Gagal memuat Profil 360°.</div>';
    });
  }

  function pfaSyncPortalPimpinanCard(res) {
    if (!res || res.status !== 'success') return;
    window._pfaLastNotifSummary = res;
    var bell = document.getElementById('pfaNotifBellCount');
    if (bell) {
      bell.textContent = String(res.totalAlerts || 0);
      bell.classList.toggle('d-none', !(res.totalAlerts > 0));
    }
    var ms = document.getElementById('pfaPimpinanMiniStats');
    var st = res.summaryToday || {};
    if (ms) {
      ms.innerHTML =
        '<div class="pfa-pimp-cell"><div class="fw-bold text-primary">' + (st.gangguan || 0) + '</div><div class="text-muted" style="font-size:0.64rem;">Ganti Meter</div></div>' +
        '<div class="pfa-pimp-cell"><div class="fw-bold text-success">' + (st.p2tlPotensi || 0) + ' / ' + (st.p2tlRealisasi || 0) + '</div><div class="text-muted" style="font-size:0.64rem;">Pot / Real</div></div>' +
        '<div class="pfa-pimp-cell"><div class="fw-bold text-danger">' + (res.totalAlerts || 0) + '</div><div class="text-muted" style="font-size:0.64rem;">Alert SLA</div></div>';
    }
  }
  window.pfaSyncPortalPimpinanCard = pfaSyncPortalPimpinanCard;

  function fetchPortalPimpinanWithRetry_(u, attempt) {
    var ms = document.getElementById('pfaPimpinanMiniStats');
    var tok = (typeof currentSessionToken !== 'undefined' && currentSessionToken) ? currentSessionToken : (u.role || '');
    window.callApi({ action: 'get_radar_sla_pimpinan', adminRole: u.role, sessionToken: tok }).then(function (res) {
      if (res && res.status === 'success') {
        pfaSyncPortalPimpinanCard(res);
      } else if (attempt < 2) {
        setTimeout(function () { fetchPortalPimpinanWithRetry_(u, attempt + 1); }, 2200);
      } else if (ms) {
        ms.innerHTML = '<div class="pfa-pimp-cell" style="grid-column:span 3; cursor:pointer;" onclick="window.pfaReloadPortalWidgets && window.pfaReloadPortalWidgets()"><span class="text-primary fw-semibold" style="font-size:0.72rem;"><i class="bi bi-arrow-clockwise me-1"></i>Ketuk untuk muat ulang</span></div>';
      }
    }).catch(function () {
      if (attempt < 2) {
        setTimeout(function () { fetchPortalPimpinanWithRetry_(u, attempt + 1); }, 2200);
      } else if (ms) {
        ms.innerHTML = '<div class="pfa-pimp-cell" style="grid-column:span 3; cursor:pointer;" onclick="window.pfaReloadPortalWidgets && window.pfaReloadPortalWidgets()"><span class="text-primary fw-semibold" style="font-size:0.72rem;"><i class="bi bi-arrow-clockwise me-1"></i>Ketuk untuk muat ulang</span></div>';
      }
    });
  }

  function loadPortalV210Widgets() {
    if (typeof window.callApi !== 'function') return;
    var u = (typeof currentUser !== 'undefined' && currentUser) ? currentUser : null;
    if (!u) return;

    // 1. Capaian Bulan Ini (Admin/Manajer = Total ULP, Petugas = Capaian Pribadi)
    window.callApi({
      action: 'get_capaian_petugas_bulan_ini',
      petugas: u.nama || '',
      username: u.username || '',
      role: u.role || ''
    }).then(function (res) {
      if (!res || res.status !== 'success') return;
      var elT = document.getElementById('pfaCapaianTitleLbl');
      var elB = document.getElementById('pfaCapaianBulanLbl');
      var elG = document.getElementById('pfaCapGgn');
      var elU = document.getElementById('pfaCapUkur');
      var elP = document.getElementById('pfaCapP2tl');
      if (elT && res.label) elT.textContent = res.label;
      if (elB) elB.textContent = res.bulan || '';
      if (elG) elG.textContent = String(res.gangguan || 0);
      if (elU) elU.textContent = String(res.pengukuran || 0);
      if (elP) elP.textContent = String(res.p2tl || 0);
    }).catch(function () {});

    // 2. Mode Pimpinan & Notification Bell (untuk ADMIN / MANAJER / SPV)
    var roleUp = String(u.role || '').toUpperCase();
    if (roleUp === 'ADMIN' || roleUp.indexOf('MANAJER') !== -1 || roleUp.indexOf('SPV') !== -1) {
      var pCard = document.getElementById('pfaPimpinanHeroCard');
      if (pCard) pCard.classList.remove('d-none');
      if (window._pfaLastNotifSummary && window._pfaLastNotifSummary.status === 'success') {
        pfaSyncPortalPimpinanCard(window._pfaLastNotifSummary);
      } else {
        fetchPortalPimpinanWithRetry_(u, 0);
      }
    }
  }
  window.pfaReloadPortalWidgets = loadPortalV210Widgets;

  window.addEventListener('load', function () {
    // Hook Quick Search button on Portal to show Profil 360°
    var goBtn = document.getElementById('pfaPortalQuickSearchGo');
    var qsInp = document.getElementById('pfaPortalQuickSearch');
    if (goBtn && qsInp) {
      goBtn.addEventListener('click', function () { runProfil360Lookup(qsInp.value); });
      qsInp.addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ev.preventDefault(); runProfil360Lookup(qsInp.value); } });
    }
    // Load Portal v2.1.11 widgets once user logs in
    var poll = setInterval(function () {
      if (typeof currentUser !== 'undefined' && currentUser) {
        clearInterval(poll);
        setTimeout(loadPortalV210Widgets, 700);
      }
    }, 1000);
  });
})();
